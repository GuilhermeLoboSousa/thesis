import inspect
from abc import abstractmethod
from typing import List, Any, Dict, Union, TYPE_CHECKING

from omnia.generics.array import np
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter, EstimatedParameter
from omnia.generics.utils.keywords import kwargs_only
from ._serializer import SerializerMixIn
from ._utils import fit_status
from omnia.generics.setup import register_estimator
from ..validation.boolean_operators.base_validator import BaseValidator
from ..validation.boolean_operators.operand_holders import OperandHolder
from ..validation.validation_properties.validation_property import ValidationProperty

if TYPE_CHECKING:
    from omnia.generics.transformation.transformer import Transformer


class Estimator(SerializerMixIn):
    """
    Estimator class for all estimators.
    This is the base class for all estimators.

    An estimator is an object that can be used to fit input data.

    The following docstring is an example of how to use this class!!!
    Please overwrite this docstring with your own docstring.

    Parameters
    ----------

    Attributes
    ----------
    name : str
        Name of the estimator.
    features : list
        List of features that are used for the estimation.
    validation_property : list
        Validation property that are used for the estimation.
    """

    # public attributes, you must set these to a real value during fit.
    features: Union[List[str], List[int], np.ndarray, pd.Series] = EstimatedParameter()
    validation_property: ValidationProperty = ValidationProperty()

    # TODO: maybe replace this by a metaclass and verify if the abstract methods are implemented.
    def __init_subclass__(cls, name: str = None, category: str = None, register: bool = True, **kwargs):
        """
        Internal method to register the estimator in the pipeline base class.
        This method also sets the name of the estimator.
        This method also lists the descriptors of the estimator's parameters and estimated parameters at the class-level
        and registers them in the class.

        Parameters
        ----------
        name : str, optional
            The name of the estimator.
        category : str, optional
            The category of the estimator.
        register : bool, optional
            True if the estimator should be registered, False otherwise.
        kwargs
            Other kwargs.
        """
        if name is None:
            cls.name = kwargs.pop('name', cls.__name__)
        else:
            cls.name = name

        if register:
            register_estimator(cls)

        super().__init_subclass__(**kwargs)

    @kwargs_only(has_self=True)
    def __init__(self, **kwargs):
        """
        The initializer of the estimator.

        Parameters
        ----------
        kwargs
            The parameters of the model.

        """
        self._fitted = False
        self._set_parameters(**kwargs)

    @property
    def fitted(self) -> bool:
        """
        Returns
        -------
        fitted : bool
            True if the model is fitted, False otherwise.
        """
        return self._fitted

    @property
    def parameters(self) -> Dict[str, Any]:
        """
        Returns
        -------
        parameters : dict
            The parameters of the model.
        """
        descriptors = self._get_parameters()
        return {name: getattr(self, name) for name in descriptors}

    @property
    def estimated_parameters(self) -> Dict[str, Any]:
        """
        Returns
        -------
        estimated_parameters : dict
            The estimated parameters of the model.
        """
        descriptors = self._get_estimated_parameters()
        return {name: getattr(self, name) for name in descriptors}

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        It validates if the data can be fitted by the estimator.

        Parameters
        ----------
        x : Any, optional
            The data used to fit the model.
        y : Any, optional
            The target used to fit the model.

        Returns
        -------
        valid : bool
            True if the model is valid, False otherwise.

        """
        if x is None and y is None:
            raise ValueError('Either x or y must be provided.')

        if not self.validation_property.input_tag:
            return True

        return self.validation_property.validate_input(x, y)

    def is_tag_compatible(self, previous_output: Union[OperandHolder, BaseValidator]) -> bool:
        """
        Check if tag is compatible with input tag

        Parameters
        ----------
        previous_output: OperandHolder | BaseValidator

        Returns
        -------
        bool
            Whether the tag is compatible with input tag.
        """
        return self.validation_property.input_is_equivalent(previous_output=previous_output)

    @abstractmethod
    def _fit(self, x: Any, y: Any = None) -> 'Estimator':
        """
        It fits the estimator to the data.
        This is an abstract method which should be overwritten by the subclasses.
        The concrete implementation of this method should perform parameter validation.
        Then, the concrete implementation should set the estimated parameters of the estimator.
        If the estimator cannot be fitted, it should raise an exception.

        Parameters
        ----------
        x : Any
            The input data.
        y : Any, optional
            The target data.

        Returns
        -------
        self : Estimator
            The estimator.

        # TODO: raise a custom FitError?
        Raises
        ------
        ValueError
            If the estimator is already fitted.
        """
        pass

    @fit_status
    def fit(self,
            x: Any,
            y: Any = None) -> Union['Estimator', 'Transformer']:
        """
        It fits the estimator to the data.
        During fit the estimator will try to infer the estimated parameters from the input data.
        The fit method will set the estimated parameters in the estimator.

        During fit, no reference should be kept to the input data. Thus, a copy of the input data should be made.
        In short, the fit method should not modify the input data.

        Only the following verifications should be performed:
            - n_samples in X and Y must be the same. Otherwise, a ValueError should be raised.
            - Y might be ignored in the case of unsupervised learning

        When the fit method is called, any previous call to fit will be ignored.
        In general, calling estimator.fit(x_1) and then estimator.fit(x_2),
        will be the same as calling estimator.fit(x_2). Hence, warm start is not supported for now.

        If the fit fails, the estimator will not be fitted. This can be checked by the `fitted` property.
        Note that, an exception will not be raised if the fit fails.
        The fit method will NOT check if the input data is valid.
        This operation is usually performed in a pipeline.

        Parameters
        ----------
        x : Any
            The data to fit the model to.
        y : Any, optional
            The target data to fit the model to.
            If not provided, the model will be fitted to the data without a target.

        Returns
        -------
        self : Estimator or Transformer
            The fitted model.
        """

        self._fit(x, y)
        return self

    @classmethod
    def _get_parameters(cls) -> Dict[str, Parameter]:
        """
        Method to return the parameters descriptors of the estimator.

        Returns
        -------
        parameters_descriptors : dict
            The parameters descriptors for the estimator.
        """
        return {name: descriptor
                for name, descriptor in inspect.getmembers(cls)
                if isinstance(descriptor, Parameter)}

    def _set_parameters(self, **kwargs):
        """
        The internal initializer of the estimator.
        It sets the parameters of the estimator using the kwargs and data descriptors.

        Parameters
        ----------
        kwargs : dict
            The parameters of the estimator.
        """
        descriptors = self._get_parameters()

        for name, descriptor in descriptors.items():
            value = kwargs.pop(name, descriptor.default)
            setattr(self, name, value)

        if kwargs:
            cls_name = self.__class__.__name__
            raise TypeError(f'{cls_name} got unexpect keyword arguments: {kwargs.keys()}')

    @classmethod
    def _get_estimated_parameters(cls) -> Dict[str, EstimatedParameter]:
        """
        Method to return the estimated parameters descriptors of the estimator.

        Returns
        -------
        parameters_defaults : dict
            The estimated parameters descriptors for the estimator.
        """
        return {name: descriptor
                for name, descriptor in inspect.getmembers(cls)
                if isinstance(descriptor, EstimatedParameter)}
