from pathlib import Path
from typing import TYPE_CHECKING, Union, Type, Dict, Any

from omnia.generics.io import read_pickle, write_pickle, write_json, read_json

if TYPE_CHECKING:
    from .estimator import Estimator


class SerializerMixIn:
    """
    MixIn class that provides the API for serializing estimator objects into pickle files.
    """

    # ------------------------------------------------------------------------------------------------------------------
    # Pickle serialization methods
    # ------------------------------------------------------------------------------------------------------------------
    def __getstate__(self: Union['Estimator', 'SerializerMixIn']) -> Dict[str, Any]:
        """
        Returns the state of the object.

        Returns
        -------
        state : Dict[str, Any]
            The state of the object.
        """
        parameters = self._get_parameters()
        estimated_parameters = self._get_estimated_parameters()

        state = self.__dict__.copy()
        for name, parameter in parameters.items():
            value = parameter.serialize(self)
            state[name] = value

        if self.fitted:
            for name, estimated_parameter in estimated_parameters.items():
                value = estimated_parameter.serialize(self)
                state[name] = value

        return state

    def __setstate__(self: Union['Estimator', 'SerializerMixIn'], state):
        """
        Sets the state of the object.

        Parameters
        ----------
        state : dict
            The state of the object.
        """
        is_fitted = state.get('_fitted', False)

        self.__dict__.update(state)

        parameters = self._get_parameters()
        estimated_parameters = self._get_estimated_parameters()

        for name, parameter in parameters.items():
            value = state[name]
            parameter.deserialize(self, value)

        self._fitted = is_fitted

        if self.fitted:
            for name, estimated_parameter in estimated_parameters.items():
                value = state[name]
                estimated_parameter.deserialize(self, value)

    @classmethod
    def from_pickle(cls: Union[Type['Estimator'], Type['SerializerMixIn']],
                    file_path: Union[str, Path]) -> Union['Estimator', 'SerializerMixIn']:
        """
        Loads an estimator object from a pickle file.

        Parameters
        ----------
        file_path : Union[str, Path, IO[AnyStr], TextIO]
            Path to the pickle file.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        obj = read_pickle(file_path)
        return obj

    def to_pickle(self: Union['Estimator', 'SerializerMixIn'],
                  file_path: Union[str, Path]) -> bool:
        """
        Saves an estimator object into a pickle file.

        Parameters
        ----------
        file_path : Union[str, Path, IO[AnyStr], TextIO]
            Path to the pickle file.

        Returns
        -------
        success : bool
            True if the operation was successful, False otherwise.
        """
        return write_pickle(file_path, item=self)

    def to_dict(self: Union['Estimator', 'SerializerMixIn']):
        """
        Saves an estimator object into a dict.

        NOTE!!!
        This method saves all estimators, models and predictors into a dict together
        with the corresponding parameters. It does not save, however, estimated parameters and model weights
        This dict object can be used to recreate a new fresh estimator or model with the same configuration.
        To save these objects, one can use the `to_pickle` or `save` methods.

        Returns
        -------
        estimator : dict
            The estimator object as a dict.
        """
        parameters = self._get_parameters()

        state = {'name': self.name, 'parameters': {}}
        for name, parameter in parameters.items():
            value = parameter.serialize(self)
            state['parameters'][name] = value

        return state

    @classmethod
    def from_dict(cls: Union[Type['Estimator'], Type['SerializerMixIn']],
                  state: dict) -> Union['Estimator', 'SerializerMixIn']:
        """
        It loads a new fresh estimator, model or predictor object from a dict.

        Parameters
        ----------
        state : dict
            The estimator object as a dict.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        parameters = state['parameters']
        obj = cls(**parameters)
        return obj

    def to_json(self: Union['Estimator', 'SerializerMixIn'],
                file_path: str):
        """
        Saves an estimator object into a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        success : bool
            True if the operation was successful, False otherwise.
        """
        state = self.to_dict()
        return write_json(file_path, state)

    @classmethod
    def from_json(cls: Union[Type['Estimator'], Type['SerializerMixIn']],
                  file_path: str) -> Union['Estimator', 'SerializerMixIn']:
        """
        Loads an estimator object from a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        state = read_json(file_path)
        return cls.from_dict(state)
