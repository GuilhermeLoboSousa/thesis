from abc import abstractmethod
from typing import Tuple, Any

from omnia.generics import Estimator
from omnia.generics.utils import CacheSingleton


class Transformer(Estimator,
                  register=False):
    """
    Transformer class for all transformers.
    This is the base class for all transformers.

    A transformer is an object that must fit the data first and then can transform it.

    The following docstring is an example of how to use this class!!!
    Please overwrite this docstring with your own docstring.

    Parameters
    ----------
    The same parameters as the Estimator class.

    Attributes
    -----------
    The same attributes as the Estimator class.
    """
    _cache = CacheSingleton()

    @abstractmethod
    def _transform(self, x: Any, y: Any = None) -> Tuple[Any, Any]:
        pass

    def transform(self,
                  x: Any,
                  y: Any = None) -> Tuple[Any, Any]:
        """
        Transform the input data (x, y) based on the estimated parameters during the transformer fit.

        Note that, if the transformer has not been fitted, an error will be raised.

        Parameters
        ----------
        x : Any
            The data to transform.
        y : Any
            The target variable to try to predict in the case of supervised learning.

        Returns
        -------
        transformed_x : Any
            The transformed data.
        transformed_y : Any
            The transformed target variable.
        """
        if not self.fitted:
            raise ValueError("The transformer is not fitted yet. "
                             "Please call the fit method first or use fit_transform.")

        return self._transform(x, y)

    def fit_transform(self, x: Any, y: Any = None) -> Tuple[Any, Any]:
        """
        Fit the transformer and transform the input data (x, y) based on the estimated parameters.

        This method is equivalent to calling fit and then transform.

        Parameters
        ----------
        x : Any
            The data to transform.
        y : Any, optional
            The target variable to try to predict in the case of supervised learning.

        Returns
        -------
        transformed_x : Any
            The transformed data.
        transformed_y : Any, optional
            The transformed target variable.
        """
        return self.fit(x, y).transform(x, y)
