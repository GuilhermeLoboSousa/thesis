from typing import Tuple, Dict, Union, Type, Any

from .transformer import Transformer
from omnia.generics.dataframe._utils import series_to_dataframe
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter


class SklearnWrapper(Transformer):
    """
    Wrapper class for sklearn transformers. It encapsulates of any sklearn estimator within the omnia compatible
    interface, overwriting the necessary Estimator methods.

    Parameters
    ----------
    sklearn_instance: object
        The sklearn transformer instance
    kwargs: dict
        The parameters of the sklearn instance

    Attributes
    -----------
    The same attributes as the Estimator class.
    """

    def __init__(self, sklearn_instance: object, **kwargs):
        """
        Initialize the class.
        """
        self.sklearn_instance = None
        self.set_sklearn_instance(sklearn_instance, **kwargs)
        super().__init__()

    def set_sklearn_instance(self, sklearn_instance: Union[str, callable], **kwargs):
        """
        Set the sklearn instance. If the sklearn_instance is a string, it will be imported and instantiated.

        Parameters
        ----------
        sklearn_instance: Union[str, callable]
            The sklearn transformer instance
        kwargs: dict
            The parameters of the sklearn instance

        Returns
        -------
        SklearnWrapper
            The sklearn wrapper instance.
        """
        if isinstance(sklearn_instance, str):
            module_name = '.'.join(sklearn_instance.split(".")[:-1])
            class_name = sklearn_instance.split(".")[-1]
            mod = __import__(module_name, fromlist=[class_name])
            sklearn_instance = getattr(mod, class_name)(**kwargs)
        self.sklearn_instance = sklearn_instance
        return self

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        Validate the input data

        Parameters
        ----------
        x: Any
            The input data
        y: Any
            The target data

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        return True

    def _fit(self, x: Any, y: Any = None, problem_type: str = None) -> 'SklearnWrapper':
        """
        Fit the sklearn transformer.

        Parameters
        ----------
        x: Any
            The input data
        y: Any
            The target data
        problem_type: str
            NOT USED IN Sklearn Wrapper!
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        SklearnWrapper
            The fitted sklearn transformer.
        """
        _x = series_to_dataframe(x)

        if y is not None:
            if x.shape[0] != y.shape[0]:
                raise ValueError("X and Y must have the same number of samples.")

            _y = y

        else:
            _y = None

        self.sklearn_instance.fit(_x, _y)
        # deal with feature selection changing the features
        if hasattr(self.sklearn_instance, "get_support"):
            self.features = _x.columns[self.sklearn_instance.get_support()].tolist()
        else:
            self.features = list(_x.columns)
        self.instances = list(_x.index)
        return self

    def _transform(self, x: Any, y: Any = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the data.

        Parameters
        ----------
        x: Any
            The input data
        y: Any
            The target data

        Returns
        -------
        Tuple[pd.DataFrame, pd.DataFrame]
            The transformed data.
        """
        _x = series_to_dataframe(x)

        if y is not None:
            if x.shape[0] != y.shape[0]:
                raise ValueError("X and Y must have the same number of samples.")

            _y = y

        else:
            _y = None
        _x = pd.DataFrame(self.sklearn_instance.transform(_x), columns=self.features, index=_x.index)
        return _x, _y

    def _get_parameters(self) -> Dict[str, 'Parameter']:
        """
        Get the parameters of the estimator

        Returns
        -------
        Dict[str, 'Parameter']
            The parameters of the estimator
        """
        sklearn_params = self.sklearn_instance.get_params()
        omnia_params = {"sklearn_instance_name": Parameter(
            str(self.sklearn_instance.__class__.__module__ + "." + self.sklearn_instance.__class__.__name__))}
        omnia_params["sklearn_instance_name"].name = "sklearn_instance_name"
        for key, value in sklearn_params.items():
            omnia_params[key] = Parameter(value)
            omnia_params[key].name = key
        return omnia_params

    @classmethod
    def from_dict(cls: Union[Type['Estimator'], Type['SerializerMixIn']],
                  state: dict) -> Union['Estimator', 'SerializerMixIn']:
        """
        Create a sklearn estimator from a dict.

        Parameters
        ----------
        state : dict
            The estimator object as a dict.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        parameters = {key: value for key, value in state['parameters'].items() if key != "sklearn_instance_name"}
        obj = cls(state['parameters']["sklearn_instance_name"], **parameters)
        return obj
