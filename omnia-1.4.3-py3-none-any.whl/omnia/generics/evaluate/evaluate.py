from typing import Any, Callable, Dict, List, Union
from omnia.generics.utils.constants import BINARY, REGRESSION
from omnia.generics.utils.metrics import get_metric
from omnia.generics.metrics import Metric
from omnia.generics.utils import to_numpy
from omnia.generics import pd


class Evaluator(object):
    """Class that evaluates a model on a given dataset.

    The evaluator class is used to evaluate a `omnia.generics.Model` class.
    """

    def __init__(self, model, x: Any, y: Any, w: Any = None):
        """Initialize this evaluator

        Parameters
        ----------
        model: Model
            Model to evaluate. Note that this must be a regression or
            classification model and not a generative model.
        x: Any
            Features to evaluate the model on.
        y: Any
            Labels to evaluate the model on.
        w: Any, optional
            An ArrayLike containing weights for each datapoint. If
            specified,  must be of shape `(N, n_tasks)`.
        """

        self.model = model
        self.x = x
        self.y = to_numpy(y)
        self.w = w if w is None else to_numpy(w)

        problem_type = self.model.problem_type

        # TODO: will raise issues when y is a different problem type for each task
        self.n_classes = None
        if problem_type != REGRESSION:
            if problem_type == BINARY:
                self.n_classes = 2
            else:
                if hasattr(model, 'n_classes'):
                    self.n_classes = model.n_classes
                else:
                    self.n_classes = len(pd.Series(self.y.flatten()).unique())

    def compute_model_performance(self, metrics: Union[str, Callable, List[Union[str, Callable]]],
                                  per_task_metrics: bool = False, **kwargs) -> Dict[str, Union[float, List[float]]]:
        """
        Computes statistics of model on test data.

        Parameters
        ----------
        metrics: Metric / List[Metric] / function
            The set of metrics provided to evaluate the model on.
        per_task_metrics: bool, optional
            If true, return computed metric for each task on multitask dataset.

        Returns
        -------
        scores: dict
            Dictionary mapping names of metrics to metric scores. If
            per_task_metrics is True, each metric will map to a list of
            scores, one for each task.
        """
        if not isinstance(metrics, list):
            metrics = [metrics]

        metrics = [Metric(metric=get_metric(metric) if isinstance(metric, str) else metric,
                          name=metric if isinstance(metric, str) else None, **kwargs) for metric in metrics]

        y = self.y
        if self.model.can_predict_proba:
            y_pred = self.model.predict_proba(self.x)

            if len(y_pred.shape) == 3:  # multiclass
                self.n_classes = max(y_pred.shape[2], self.n_classes)
        else:
            y_pred = self.model.predict(self.x)
        n_tasks = 1 if len(y.shape) == 1 else y.shape[1]

        multitask_scores = {}
        all_task_scores = {}

        # Compute multitask metrics
        for metric in metrics:
            results = metric.compute_metric(y, y_pred, n_tasks=n_tasks, n_classes=self.n_classes, w=self.w,
                                            per_task_metrics=per_task_metrics, **kwargs)
            if per_task_metrics:
                _, computed_metrics = results
                all_task_scores[metric.name] = computed_metrics
            else:
                multitask_scores[metric.name] = results

        return all_task_scores if per_task_metrics else multitask_scores
