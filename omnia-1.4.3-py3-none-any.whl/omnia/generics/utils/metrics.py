from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score, log_loss, \
    mean_squared_error, mean_absolute_error, r2_score, mean_absolute_percentage_error, mean_squared_log_error, \
    median_absolute_error, balanced_accuracy_score, jaccard_score, matthews_corrcoef, cohen_kappa_score, \
    precision_recall_curve, root_mean_squared_error
from scipy.stats import pearsonr

_METRICS = {
    "accuracy": accuracy_score,
    "balanced_accuracy": balanced_accuracy_score,
    "f1": f1_score,
    "precision": precision_score,
    "recall": recall_score,
    "roc_auc": roc_auc_score,
    "precision_recall_curve": precision_recall_curve,
    "matthews_corrcoef": matthews_corrcoef,
    "cohen_kappa_score": cohen_kappa_score,
    "jaccard_score": jaccard_score,
    "log_loss": log_loss,
    "mean_squared_error": mean_squared_error,
    "mse": mean_squared_error,  # Alias for "mean_squared_error"
    "mean_absolute_error": mean_absolute_error,
    "mae": mean_absolute_error,  # Alias for "mean_absolute_error"
    "r2": r2_score,
    "root_mean_squared_error": root_mean_squared_error,
    "rmse": root_mean_squared_error,  # Alias for "root_mean_squared_error
    "mean_absolute_percentage_error": mean_absolute_percentage_error,
    "mean_squared_log_error": mean_squared_log_error,
    "median_absolute_error": median_absolute_error,
    "pearson": pearsonr
}


def get_metric(name: str) -> callable:
    """
    Get a metric function based on its name.

    Parameters
    ----------
    name: str
        The name of the metric.

    Returns
    -------
    metric: callable
        The metric function from the scikit-learn library.
    """
    return _METRICS[name]


def compute_metric(metric: str, y_true, y_pred, threshold=0.5, **kwargs) -> float:
    """
    Compute a metric on the given data.

    Parameters
    ----------
    metric: str
        The metric to compute.
    y_true: Any
        The true target variable.
    y_pred: Any
        The predicted target variable.
    threshold: float
        The threshold to use for binary classification metrics.

    Returns
    -------
    score: float
        The value of the computed metric.
    """
    if metric in ["accuracy", "balanced_accuracy", "f1", "precision", "recall", "jaccard_score"]:
        y_pred = (y_pred > threshold).astype(int)
    metric = get_metric(metric)
    return metric(y_true, y_pred, **kwargs)
