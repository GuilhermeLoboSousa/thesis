def singleton(cls):
    """
    A decorator that makes a class a singleton.
    Note: A singleton is a class that can only have one instance.

    Parameters
    ----------
    cls: class
        The class to be decorated.

    Returns
    -------
    cls: class
        The decorated class.
    """
    instances = {}

    def get_instance():
        if cls not in instances:
            instances[cls] = cls()
        return instances[cls]

    return get_instance()
