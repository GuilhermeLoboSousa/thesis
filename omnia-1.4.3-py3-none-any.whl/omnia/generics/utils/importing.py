import importlib
from typing import Type


def import_class(module_name: str, class_name: str) -> Type:
    """
    Import a class from a module.

    Parameters
    ----------
    module_name : str
        name of the module
    class_name : str
        name of the class

    Returns
    -------
    c : class
        class object
    """
    m = importlib.import_module(module_name)
    c = getattr(m, class_name)
    return c


def get_class(fqn: str) -> Type:
    """
    Get a class from a fully qualified name.

    Parameters
    ----------
    fqn : str
        fully qualified name of the class

    Returns
    -------
    c : class
        class object
    """
    class_data = fqn.split(".")
    module_path = ".".join(class_data[:-1])
    class_name = class_data[-1]
    return import_class(module_path, class_name)
