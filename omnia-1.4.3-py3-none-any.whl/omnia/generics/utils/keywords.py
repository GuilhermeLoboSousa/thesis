from functools import wraps


def kwargs_only(has_self: bool = True):
    """
    Decorator to ensure that the decorated function only accepts keyword arguments.

    Parameters
    ----------
    has_self : bool
        Whether the decorated function has a self argument.

    Returns
    -------
    function
        The decorated function.
    """
    def decorator(func):
        if has_self:

            @wraps(func)
            def wrapper(self, *args, **kwargs):
                if args:
                    raise TypeError("args passed")
                else:
                    return func(self, **kwargs)

        else:

            @wraps(func)
            def wrapper(*args, **kwargs):
                if args:
                    raise TypeError("args passed")
                else:
                    return func(**kwargs)

        return wrapper

    return decorator
