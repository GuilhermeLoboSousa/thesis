from typing import Any


def identity_fn(x: Any, y: Any, *args, **kwargs) -> Any:
    """
    Identity function.

    Parameters
    ----------
    x : any
        Input value.

    args : any
        Additional arguments.

    kwargs : any
        Additional keyword arguments.

    Returns
    -------
    any
        Input value.

    """
    return x, y
