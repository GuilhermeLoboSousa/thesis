from omnia.generics import pd, np
from typing import Any
from omnia.generics.utils.constants import (
    BINARY,
    MULTICLASS,
    REGRESSION,
    MULTICLASS_UPPER_LIMIT,
    LARGE_DATA_THRESHOLD,
    REGRESS_THRESHOLD_LARGE_DATA,
    REGRESS_THRESHOLD_SMALL_DATA,
)
import warnings


def infer_problem_type(y: Any) -> str:
    """
    Infer the problem type based on the target column. Problem types are either "binary", "multiclass", or "regression".

    Parameters
    ----------
    y : pd.DataFrame
        The target column.

    Returns
    -------
    str
        The problem type.

    Example:
        >>> infer_problem_type(pd.DataFrame([1, 2, 3]))
    """
    if isinstance(y, pd.DataFrame):
        y = y.values
    if isinstance(y, np.ndarray):
        # TODO: Update this when multitask problems can be of various types i.e. multiclass and regression together
        y = pd.Series(y.flatten())

    # treat None, NaN, INF, NINF as NA
    y = y.replace([np.inf, -np.inf], np.nan, inplace=False)
    y = y.dropna()
    num_rows = len(y)

    if num_rows < 50:
        warnings.warn(
            "Warning: The number of rows is less than 50. Inference accuracy may be compromised."
            + " Specify `problem_type` explicitly in the `fit` function to avoid this warning.", UserWarning)

    if num_rows == 0:
        raise ValueError("Label column cannot have 0 valid values")

    unique_values = y.unique()

    if num_rows > LARGE_DATA_THRESHOLD:
        regression_threshold = (
            # if the unique-ratio is less than this, we assume multiclass classification, even when labels are integers
            REGRESS_THRESHOLD_LARGE_DATA
        )
    else:
        regression_threshold = REGRESS_THRESHOLD_SMALL_DATA

    unique_count = len(unique_values)
    if unique_count == 2:
        problem_type = BINARY
    elif y.dtype.name in ["object", "category", "string"]:
        problem_type = MULTICLASS
    elif np.issubdtype(y.dtype, np.floating):
        unique_ratio = unique_count / float(num_rows)
        if (unique_ratio <= regression_threshold) and (unique_count <= MULTICLASS_UPPER_LIMIT):
            try:
                can_convert_to_int = np.array_equal(y, y.astype(int))
                if can_convert_to_int:
                    problem_type = MULTICLASS
                else:
                    problem_type = REGRESSION
            except:
                problem_type = REGRESSION
        else:
            problem_type = REGRESSION
    elif np.issubdtype(y.dtype, np.integer):
        unique_ratio = unique_count / float(num_rows)
        if (unique_ratio <= regression_threshold) and (unique_count <= MULTICLASS_UPPER_LIMIT):
            # TODO: Check if integers are from 0 to n-1 for n unique values, if they have a wide spread, it could still be regression
            problem_type = MULTICLASS
        else:
            problem_type = REGRESSION
    else:
        raise NotImplementedError(f"label dtype {y.dtype} not supported!")
    warnings.warn(f"Problem type inferred as '{problem_type}'. If this is incorrect, specify `problem_type` "
                  f"explicitly in the `fit` function.", UserWarning,)
    return problem_type
