import warnings
from typing import Tuple, Callable, Dict

import numpy as np

from omnia.generics.transformation import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from omnia.generics.utils.identity_fn import identity_fn
from omnia.generics.validation import TagsProperty
from omnia.generics.utils.importing import get_class


class FunctionTransformer(Transformer,
                          name='FunctionTransformer',
                          category='utils',
                          register=False):
    """
    The FunctionTransformer can be used to convert a given function into a functional transformer.
    It takes a function and the corresponding args and kwargs.
    The function can be a lambda function or a function from the standard library.
    It then applies the function to the dataframe during the transform method.
    It should be used internally by the pipeline.

    Parameters
    ----------
    function : Callable, default=identity_fn
        The function to be applied to the dataframe.
        By default, the identity function is used.

    args : list or tuple
        The arguments to be passed to the function.

    kwargs : dict
        The keyword arguments to be passed to the function.

    Examples
    --------
    >>> from omnia.generics.transformation import FunctionTransformer
    >>> from omnia.generics.dataframe import pd
    >>> ft = FunctionTransformer()
    >>> x, y = pd.DataFrame([[1, 2], [3, 4]]), pd.DataFrame([[1, 2], [3, 4]])
    >>> ft.validate(x, y)
    >>> ft.fit(x, y)
    >>> ft.features
    >>> ft.instances
    >>> ft.transform(pd.DataFrame([[1, 2], [3, 4]]))[0].shape
    """
    function: Callable = Parameter(default=identity_fn, tunable=False)
    args: list or tuple = Parameter(default=None, tunable=False)
    kwargs: dict = Parameter(default=None, tunable=False)

    tags = TagsProperty([])

    def validate(self, x: pd.DataFrame = None, y: pd.DataFrame = None) -> bool:
        """
        The validation method performs fast and straightforward checks to the data.
        It returns a boolean value indicating whether the data is valid or not.
        Parameters
        ----------
        x : pd.DataFrame, optional
            The data used to fit the model.
        y : pd.DataFrame, optional
            The target used to fit the model.

        Returns
        -------
        bool
            True if the value is valid, False otherwise.
        """
        return True

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'FunctionTransformer':
        """
        Method to fit the Transformer.

        Parameters
        ----------
        x: pd.DataFrame
            dataframe with the data to fit the transformers

        y: pd.DataFrame
            dataframe with the labels to fit the transformers

        Returns
        -------
        FunctionTransformer
            self
        """
        if self.function is None:
            raise ValueError("The function must be specified.")

        if self.args is None:
            self.args = ()

        if self.kwargs is None:
            self.kwargs = {}

        if isinstance(x, pd.DataFrame) or isinstance(x, pd.Series):
            self.features = list(x.columns)
            self.instances = list(x.index)
        else:
            self.features = None
            self.instances = None

        return self

    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Method to transform data using the function together with args and kwargs.

        Parameters
        ----------
        x: pd.DataFrame
            dataframe with the data to be transformed

        y: pd.DataFrame, optional
            dataframe with the labels to be transformed

        Returns
        -------
        transformed_x: pd.DataFrame
            transformed dataframe

        transformed_y: pd.DataFrame
            transformed dataframe
        """
        x, y = self.function(x, y, *self.args, **self.kwargs)
        return x, y

    # TODO: The serialization of a function is not supported yet.
    def to_dict(self):
        """
        Method to convert the object to a dictionary.
        """
        warnings.warn(
            "The serialization of a function is not supported yet.",
        )
        return {
            'name': self.name,
            'parameters': {'function': self.function.__module__ + '.' + self.function.__name__,
                           'args': self.args,
                           'kwargs': self.kwargs}
        }

    @classmethod
    def from_dict(cls, state: Dict) -> 'FunctionTransformer':
        """
        Method to create an object from a dictionary.
        """
        function = get_class(state['parameters']['function'])
        args = state['parameters']['args']
        kwargs = state['parameters']['kwargs']
        return cls(function=function, args=args, kwargs=kwargs)


class PassthroughTransformer(FunctionTransformer,
                             name='passthrough',
                             category='utils',
                             register=False):
    """
    The PassthroughTransformer is a transformer that does not transform the data.
    It is useful to use it as a placeholder for the data that is not going to be transformed.
    """
    pass


if __name__ == '__main__':
    ft = FunctionTransformer()
    x, y = pd.DataFrame([[1, 2], [3, 4]]), pd.DataFrame([[1, 2], [3, 4]])
    print(ft.validate(x, y))
    print(ft.fit(x, y))
    print(ft.features)
    print(ft.instances)
    print(ft.transform(pd.DataFrame([[1, 2], [3, 4]]))[0].shape)
