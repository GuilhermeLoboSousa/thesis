# Supported problem types
BINARY = 'binary'
MULTICLASS = 'multiclass'
REGRESSION = 'regression'

# infer problem constants
# assume regression if dtype is numeric and unique label count is above this limit
MULTICLASS_UPPER_LIMIT = 1000
LARGE_DATA_THRESHOLD = 1000
REGRESS_THRESHOLD_LARGE_DATA = 0.05
REGRESS_THRESHOLD_SMALL_DATA = 0.1

PROBLEM_TYPES = [BINARY, MULTICLASS, REGRESSION]
