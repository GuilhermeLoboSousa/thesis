from typing import Type, Dict


class RegistryMixIn:
    """
    A dictionary-like object that maps estimator, model and predictor names to the corresponding classes.
    It can be used to look up estimator, model and predictor classes by their name.

    More importantly, it can be used in the factory pattern to create new objects from these classes.
    """
    def __init__(self):
        """
        Initializes the registry.
        """
        self._registry = {}

    def register(self, cls: Type):
        """
        Registers a class in the registry.

        Parameters
        ----------
        cls : Type
            The class to be registered.

        """
        if cls.name in self._registry:
            raise KeyError(f'The name {cls.name} is already registered.')

        self._registry[cls.name] = cls

    def get(self, name: str, default=None):
        """
        Returns the class corresponding to the given name.
        If the name is not registered, the default value is returned.
        Parameters
        ----------
        name : str
            The name of the class.

        default : Type
            The default value to be returned.

        Returns
        -------
        cls
            The class corresponding to the given name.
        """
        return self._registry.get(name, default)

    def all(self) -> Dict[str, Type]:
        """
        Returns all the registered classes.

        Returns
        -------
        all : Dict[str, Type]
            All the registered classes.
        """
        return self._registry.copy()

    def keys(self):
        """
        Returns the keys of the registry.
        Python dictionary-like interface.

        Returns
        -------
        keys : iterator
            The keys of the registry.
        """
        return self._registry.keys()

    def values(self):
        """
        Returns the values of the registry.
        Python dictionary-like interface.

        Returns
        -------
        values : iterator
            The values of the registry.
        """
        return self._registry.values()

    def items(self):
        """
        Returns the items of the registry.
        Python dictionary-like interface.

        Returns
        -------
        items : iterator
            The items of the registry.
        """
        return self._registry.items()

    def __iter__(self):
        return iter(self._registry)

    def __len__(self):
        return len(self._registry)

    def __contains__(self, item):
        return item in self._registry

    def __getitem__(self, item):
        return self._registry[item]

    def __setitem__(self, key, value):
        self._registry[key] = value

    def __delitem__(self, key):
        del self._registry[key]

    def __str__(self):
        return str(self._registry)

    def __repr__(self):
        return repr(self._registry)
