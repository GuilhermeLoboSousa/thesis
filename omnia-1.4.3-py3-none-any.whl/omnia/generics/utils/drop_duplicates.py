from typing import Tuple

from omnia.generics import pd


def drop_duplicates(x: pd.DataFrame, y: pd.DataFrame, *args, **kwargs) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Drop duplicates from x and y.

    Parameters
    ----------
    x : pd.DataFrame
        Input dataframe.
    y : pd.DataFrame
        Target dataframe.
    args : any
        Additional arguments.
    kwargs : any
        Additional keyword arguments.

    Returns
    -------
    pd.DataFrame
        Input dataframe without duplicates.
    """
    # concatenate x and y
    x = x.reset_index(drop=True)
    if y is not None:
        y = y.reset_index(drop=True)
        df = pd.concat([x, y], axis=1)
        # drop duplicates
        df = df.drop_duplicates(*args, **kwargs)
        # split back into x and y
        x = df[x.columns]
        y = df[y.columns]
        return x, y
    else:
        df = x
        df = df.drop_duplicates(*args, **kwargs)
        return df, y
