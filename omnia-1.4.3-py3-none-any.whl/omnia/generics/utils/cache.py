import atexit
import hashlib
import json
import os
import pickle
from functools import wraps
from pathlib import Path
from threading import Lock
from typing import Tuple, Optional, Any, Callable

import pandas as pd


def cache_transform(method: Callable) -> Callable:
    """
    Decorator to cache the result of a transformation method.

    Parameters
    ----------
    method: Callable
        The method to decorate.

    Returns
    -------
    wrapper: Callable
        The decorated method.
    """
    @wraps(method)
    def wrapper(self, x: Any, y: Any = None) -> Tuple[Any, Any]:
        """
        Wrapper for the transformation method.

        Parameters
        ----------
        self: Any
            The object to transform.
        x: Any
            The data to transform.
        y: Any
            The labels to transform.

        Returns
        -------
        x_transformed: Any
            The transformed data (either computed or loaded from cache).
        """
        if getattr(self, 'skip_cache', False):
            return method(self, x, y)
        params = self.parameters
        params['name'] = self.name
        cached_result, cache_key = check_cache(self._cache, x, params)
        if cached_result is not None:
            return cached_result, y

        # Call the actual transformation method
        x_transformed, y_transformed = method(self, x, y)

        # Save the result to the cache
        self._cache.save_to_cache(cache_key, x_transformed)

        return x_transformed, y_transformed

    return wrapper

def check_cache(cache, data: Any, params: dict) -> Tuple[Optional[Any], str]:
    """
    Check if the result is in the cache.

    Parameters
    ----------
    cache: CacheSingleton
        The cache object.
    data: Any
        The data to check.
    params:
        The parameters to check.

    Returns
    -------
    cached_result: Tuple[Optional[Any], str]
        The cached result and the cache key.
    """
    cache_key = cache._generate_cache_key(data, params)
    cached_result = cache.load_from_cache(cache_key)
    if cached_result is not None:
        return cached_result, cache_key
    return None, cache_key


class CacheSingleton:
    """
    Singleton class to manage the cache.
    The cache is a directory where the results of the transformations are stored.
    If the result is already in the cache, it is loaded from there instead of recomputing it.
    """
    _instance = None
    _lock = Lock()
    _cache_dir = './cache'

    def __new__(cls, *args, **kwargs):
        """
        Create a new instance of the CacheSingleton class.
        """
        with cls._lock:
            if not cls._instance:
                cls._instance = super(CacheSingleton, cls).__new__(cls)
                cls._instance._initialize_cache()
                atexit.register(cls._instance.clear_cache)  # Registering cache clearing at exit
        return cls._instance

    def _initialize_cache(self):
        """
        Initialize the cache directory.
        It creates the cache directory if it does not exist.
        """
        os.makedirs(self._cache_dir, exist_ok=True)

    @staticmethod
    def _generate_cache_key(data: Any, params: dict) -> str:
        """
        Generate a cache key from the data and the parameters.

        Parameters
        ----------
        data: Any
            The data to cache.
        params: dict
            The parameters to cache

        Returns
        -------
        cache_key: str
            The cache key.
        """
        data_hash = hashlib.md5(pd.util.hash_pandas_object(data).values).hexdigest()
        params_hash = hashlib.md5(json.dumps(params, sort_keys=True).encode()).hexdigest()
        return f"{data_hash}_{params_hash}"

    def load_from_cache(self, cache_key: str) -> Any:
        """
        Load the result from the cache.

        Parameters
        ----------
        cache_key: str
            The cache key.

        Returns
        -------
        result: Any
            The cached result.
        """
        cache_path = os.path.join(self._cache_dir, f"{cache_key}.pkl")
        if os.path.exists(cache_path):
            with open(cache_path, 'rb') as f:
                return pickle.load(f)
        return None

    def save_to_cache(self, cache_key: str, result):
        """
        Save the result to the cache.

        Parameters
        ----------
        cache_key: str
            The cache key.
        result: Any
            The result to cache.
        """
        if not os.path.exists(self._cache_dir):
            os.makedirs(self._cache_dir)
        cache_path = os.path.join(self._cache_dir, f"{cache_key}.pkl")
        with open(cache_path, 'wb') as f:
            pickle.dump(result, f)

    def clear_cache(self):
        """
        Clears the cache.
        """
        cache_dir = Path(self._cache_dir)
        for file_path in cache_dir.glob("*.pkl"):
            try:
                file_path.unlink()
            except Exception as e:
                raise ValueError(f"Error deleting file {file_path}: {e}")
        # deleting cache folder if empty
        if os.path.isdir(cache_dir) and not any(cache_dir.iterdir()):
            cache_dir.rmdir()
