from omnia.generics import pd, np
import torch
from typing import Any


def to_numpy(data: Any) -> np.ndarray:
    """
    Converts data to a NumPy array.

    Parameters
    ----------
    data: Any
        The data to convert to a NumPy array.
    Returns
    -------
    array: np.ndarray
        The NumPy array.
    """
    if isinstance(data, np.ndarray):
        return data
    elif isinstance(data, pd.DataFrame) or isinstance(data, pd.Series):
        return data.values
    elif isinstance(data, torch.Tensor):
        return data.detach().numpy()
    elif isinstance(data, list) and all(isinstance(t, torch.Tensor) for t in data):
        return np.array([t.detach().numpy() for t in data])
    else:
        raise ValueError("Unsupported data type. Must be PyTorch tensor, list of PyTorch tensors, pd.DataFrame, "
                         "pd.Series, or list.")
