"""The ``flavor`` module provides an example for a custom model flavor for ``omnia`` library.

This module exports ``omnia`` pipelines in the following formats:

omnia (native) format
    This is the main flavor that can be loaded back into ``omnia``, which relies on pickle
    internally to serialize a model.

    Note that pickle serialization requires using the same python environment (version) in
    whatever environment you're going to use this model for inference to ensure that the model
    will load with appropriate version of pickle.
mlflow.pyfunc
    Produced for use by generic pyfunc-based deployment tools and batch inference.

    The interface for utilizing a ``omnia`` model loaded as a ``pyfunc`` type for generating
    forecast predictions uses a *single-row* ``Pandas DataFrame`` configuration argument. The
    following columns in this configuration ``Pandas DataFrame`` are supported:

"""
import logging
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

from omnia.generics import utils

import mlflow
from mlflow import pyfunc
from mlflow.exceptions import MlflowException
from mlflow.models import Model
from mlflow.models.model import MLMODEL_FILE_NAME
from mlflow.models.utils import _save_example
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.tracking._model_registry import DEFAULT_AWAIT_MAX_SLEEP_SECONDS
from mlflow.tracking.artifact_utils import _download_artifact_from_uri
from mlflow.utils.environment import (
    _CONDA_ENV_FILE_NAME,
    _CONSTRAINTS_FILE_NAME,
    _PYTHON_ENV_FILE_NAME,
    _REQUIREMENTS_FILE_NAME,
    _mlflow_conda_env,
    _process_conda_env,
    _process_pip_requirements,
    _PythonEnv,
    _validate_env_arguments,
)
from mlflow.utils.file_utils import write_to
from mlflow.utils.model_utils import (
    _add_code_from_conf_to_system_path,
    _get_flavor_configuration,
    _validate_and_copy_code_paths,
    _validate_and_prepare_target_save_path,
)
from mlflow.utils.requirements_utils import _get_pinned_requirement


if TYPE_CHECKING:
    from omnia.generics import Pipeline


FLAVOR_NAME = "mlflow_omnia"

OMNIA_PREDICT = "predict"
SUPPORTED_OMNIA_PREDICT_METHODS = [
    OMNIA_PREDICT,
]

SERIALIZATION_FORMAT_PICKLE = "pickle"
SUPPORTED_SERIALIZATION_FORMATS = [
    SERIALIZATION_FORMAT_PICKLE,
]


_logger = logging.getLogger(__name__)


def get_default_pip_requirements(omnia_packages=None):
    """Create list of default pip requirements for MLflow Models.

    Returns
    -------
    list of default pip requirements for MLflow Models produced by this flavor.
    Calls to :func:`save_model()` and :func:`log_model()` produce a pip environment
    that, at a minimum, contains these requirements.
    """
    import omnia.generics as omnia

    if not omnia_packages:
        omnia_packages = ["omnia"]

    pip_deps = [_get_pinned_requirement(pkg, version=omnia.__version__)
                for pkg in omnia_packages]
    return pip_deps


def get_default_conda_env(omnia_packages=None):
    """
    Return default Conda environment for MLflow Models.

    Returns
    -------
    The default Conda environment for MLflow Models produced by calls to
    :func:`save_model()` and :func:`log_model()`
    """
    return _mlflow_conda_env(additional_pip_deps=get_default_pip_requirements(omnia_packages))


def save_model(
        omnia_pipeline,
        path,
        conda_env=None,
        code_paths=None,
        mlflow_model=None,
        signature=None,
        input_example=None,
        pip_requirements=None,
        extra_pip_requirements=None,
        serialization_format=SERIALIZATION_FORMAT_PICKLE,
):
    """Save a ``omnia`` pipeline to a path on the local file system.

    Parameters
    ----------
    omnia_pipeline : omnia.generics.Pipeline
        Fitted ``omnia`` pipeline object.
    path : str
        Local path where the model is to be saved.
    conda_env : Union[dict, str], optional (default=None)
        Either a dictionary representation of a Conda environment or the path to a
        conda environment yaml file.
    code_paths : array-like, optional (default=None)
        A list of local filesystem paths to Python file dependencies (or directories
        containing file dependencies). These files are *prepended* to the system path
        when the model is loaded.
    mlflow_model: mlflow.models.Model, optional (default=None)
        mlflow.models.Model configuration to which to add the python_function flavor.
    signature : mlflow.models.signature.ModelSignature, optional (default=None)
        Model Signature mlflow.models.ModelSignature describes
        model input and output :py:class:`Schema <mlflow.types.Schema>`. The model
        signature can be :py:func:`inferred <mlflow.models.infer_signature>` from
        datasets with valid model input (e.g. the training dataset with target column
        omitted) and valid model output (e.g. model predictions generated on the
        training dataset), for example:

        .. code-block:: py

          from mlflow.models import infer_signature

          train = df.drop_column("target_label")
          predictions = ...  # compute model predictions
          signature = infer_signature(train, predictions)

        .. Warning:: if performing probabilistic forecasts (``predict_interval``,
          ``predict_quantiles``) with a ``sktime`` model, the signature
          on the returned prediction object will not be correctly inferred due
          to the Pandas MultiIndex column type when using the these methods.
          ``infer_schema`` will function correctly if using the ``pyfunc`` flavor
          of the model, though.
    input_example : Union[pandas.core.frame.DataFrame, numpy.ndarray, dict, list, csr_matrix, csc_matrix],
    optional (default=None)
        Input example provides one or several instances of valid model input.
        The example can be used as a hint of what data to feed the model. The given
        example will be converted to a ``Pandas DataFrame`` and then serialized to json
        using the ``Pandas`` split-oriented format. Bytes are base64-encoded.
    pip_requirements : Union[Iterable, str], optional (default=None)
        Either an iterable of pip requirement strings
        (e.g. ["sktime", "-r requirements.txt", "-c constraints.txt"]) or the string
        path to a pip requirements file on the local filesystem
        (e.g. "requirements.txt")
    extra_pip_requirements : Union[Iterable, str], optional (default=None)
        Either an iterable of pip requirement strings
        (e.g. ["pandas", "-r requirements.txt", "-c constraints.txt"]) or the string
        path to a pip requirements file on the local filesystem
        (e.g. "requirements.txt")
    serialization_format : str, optional (default="pickle")
        The format in which to serialize the model. This should be one of the formats
        "pickle" or "cloudpickle"
    """
    import omnia.generics as omnia

    _validate_env_arguments(conda_env, pip_requirements, extra_pip_requirements)

    if serialization_format not in SUPPORTED_SERIALIZATION_FORMATS:
        raise MlflowException(
            message=(
                f"Unrecognized serialization format: {serialization_format}. "
                "Please specify one of the following supported formats: "
                "{SUPPORTED_SERIALIZATION_FORMATS}."
            ),
            error_code=INVALID_PARAMETER_VALUE,
        )

    _validate_and_prepare_target_save_path(path)
    code_dir_subpath = _validate_and_copy_code_paths(code_paths, path)

    if mlflow_model is None:
        mlflow_model = Model()
    if signature is not None:
        mlflow_model.signature = signature
    if input_example is not None:
        _save_example(mlflow_model, input_example, path)

    pipeline_basename_path = _save_model(pipeline=omnia_pipeline, mlflow_path=path)

    pyfunc.add_to_model(
        mlflow_model,
        loader_module="omnia.generics.utils.mlflow_omnia",
        model_path=pipeline_basename_path,
        conda_env=_CONDA_ENV_FILE_NAME,
        python_env=_PYTHON_ENV_FILE_NAME,
        code=code_dir_subpath,
    )

    mlflow_model.add_flavor(
        FLAVOR_NAME,
        pickled_model=pipeline_basename_path,
        omnia_version=omnia.__version__,
        serialization_format=serialization_format,
        code=code_dir_subpath,
    )
    mlflow_model.save(os.path.join(path, MLMODEL_FILE_NAME))

    # get the omnia-subpackages from the pipeline
    def _get_subpackage(estimator):
        modules = estimator.__module__.split(".")
        if len(modules) < 2:
            return

        if modules[0] != "omnia":
            return

        if modules[1] == "generics":
            return "omnia"

        return modules[1]

    omnia_packages = {_get_subpackage(estimator) for _, estimator in omnia_pipeline.steps}
    omnia_packages = [package for package in omnia_packages if package is not None]

    if conda_env is None:
        if pip_requirements is None:
            default_reqs = get_default_pip_requirements(omnia_packages)
            inferred_reqs = mlflow.models.infer_pip_requirements(
                path, FLAVOR_NAME, fallback=default_reqs
            )
            default_reqs = sorted(set(inferred_reqs).union(default_reqs))
        else:
            default_reqs = None
        conda_env, pip_requirements, pip_constraints = _process_pip_requirements(
            default_reqs, pip_requirements, extra_pip_requirements
        )
    else:
        conda_env, pip_requirements, pip_constraints = _process_conda_env(conda_env)

    with open(os.path.join(path, _CONDA_ENV_FILE_NAME), "w") as f:
        yaml.safe_dump(conda_env, stream=f, default_flow_style=False)

    if pip_constraints:
        write_to(os.path.join(path, _CONSTRAINTS_FILE_NAME), "\n".join(pip_constraints))

    write_to(os.path.join(path, _REQUIREMENTS_FILE_NAME), "\n".join(pip_requirements))

    _PythonEnv.current().to_yaml(os.path.join(path, _PYTHON_ENV_FILE_NAME))


def log_model(
        omnia_pipeline,
        artifact_path,
        conda_env=None,
        code_paths=None,
        registered_model_name=None,
        signature=None,
        input_example=None,
        await_registration_for=DEFAULT_AWAIT_MAX_SLEEP_SECONDS,
        pip_requirements=None,
        extra_pip_requirements=None,
        serialization_format=SERIALIZATION_FORMAT_PICKLE,
        **kwargs,
):
    """
    Log a ``omnia`` pipeline as an MLflow artifact for the current run.

    Parameters
    ----------
    omnia_pipeline : fitted ``omnia`` pipeline
        Fitted ``omnia`` pipeline object.
    artifact_path : str
        Run-relative artifact path to save the model to.
    conda_env : Union[dict, str], optional (default=None)
        Either a dictionary representation of a Conda environment or the path to a
        conda environment yaml file.
    code_paths : array-like, optional (default=None)
        A list of local filesystem paths to Python file dependencies (or directories
        containing file dependencies). These files are *prepended* to the system path
        when the model is loaded.
    registered_model_name : str, optional (default=None)
        If given, create a model version under ``registered_model_name``, also creating
        a registered model if one with the given name does not exist.
    signature : mlflow.models.signature.ModelSignature, optional (default=None)
        Model Signature mlflow.models.ModelSignature describes
        model input and output :py:class:`Schema <mlflow.types.Schema>`. The model
        signature can be :py:func:`inferred <mlflow.models.infer_signature>` from
        datasets with valid model input (e.g. the training dataset with target column
        omitted) and valid model output (e.g. model predictions generated on the
        training dataset), for example:

        .. code-block:: py

          from mlflow.models import infer_signature

          train = df.drop_column("target_label")
          predictions = ...  # compute model predictions
          signature = infer_signature(train, predictions)

        .. Warning:: if performing probabilistic forecasts (``predict_interval``,
          ``predict_quantiles``) with a ``sktime`` model, the signature
          on the returned prediction object will not be correctly inferred due
          to the Pandas MultiIndex column type when using the these methods.
          ``infer_schema`` will function correctly if using the ``pyfunc`` flavor
          of the model, though.
    input_example : Union[pandas.core.frame.DataFrame, numpy.ndarray, dict, list, csr_matrix, csc_matrix],
    optional (default=None)
        Input example provides one or several instances of valid model input.
        The example can be used as a hint of what data to feed the model. The given
        example will be converted to a ``Pandas DataFrame`` and then serialized to json
        using the ``Pandas`` split-oriented format. Bytes are base64-encoded.
    await_registration_for : int, optional (default=None)
        Number of seconds to wait for the model version to finish being created and is
        in ``READY`` status. By default, the function waits for five minutes. Specify 0
        or None to skip waiting.
    pip_requirements : Union[Iterable, str], optional (default=None)
        Either an iterable of pip requirement strings
        (e.g. ["sktime", "-r requirements.txt", "-c constraints.txt"]) or the string
        path to a pip requirements file on the local filesystem
        (e.g. "requirements.txt")
    extra_pip_requirements : Union[Iterable, str], optional (default=None)
        Either an iterable of pip requirement strings
        (e.g. ["pandas", "-r requirements.txt", "-c constraints.txt"]) or the string
        path to a pip requirements file on the local filesystem
        (e.g. "requirements.txt")
    serialization_format : str, optional (default="pickle")
        The format in which to serialize the model. This should be one of the formats
        "pickle" or "cloudpickle"
    kwargs:
        Additional arguments for :py:class:`mlflow.models.model.Model`

    Returns
    -------
    A :py:class:`ModelInfo <mlflow.models.model.ModelInfo>` instance that contains the
    metadata of the logged model.
    """
    return Model.log(
        artifact_path=artifact_path,
        flavor=utils.mlflow_omnia,
        registered_model_name=registered_model_name,
        omnia_pipeline=omnia_pipeline,
        conda_env=conda_env,
        code_paths=code_paths,
        signature=signature,
        input_example=input_example,
        await_registration_for=await_registration_for,
        pip_requirements=pip_requirements,
        extra_pip_requirements=extra_pip_requirements,
        serialization_format=serialization_format,
        **kwargs,
    )


def load_model(model_uri, dst_path=None) -> 'Pipeline':
    """
    Load a ``omnia`` pipeline from a local file or a run.

    Parameters
    ----------
    model_uri : str
        The location, in URI format, of the MLflow model. For example:

                    - ``/Users/me/path/to/local/model``
                    - ``relative/path/to/local/model``
                    - ``s3://my_bucket/path/to/model``
                    - ``runs:/<mlflow_run_id>/run-relative/path/to/model``
                    - ``mlflow-artifacts:/path/to/model``

        For more information about supported URI schemes, see
        `Referencing Artifacts <https://www.mlflow.org/docs/latest/tracking.html#
        artifact-locations>`_.
    dst_path : str, optional (default=None)
        The local filesystem path to which to download the model artifact.This
        directory must already exist. If unspecified, a local output path will
        be created.

    Returns
    -------
    omnia_pipeline : omnia.generics.Pipeline
        A ``omnia`` pipeline instance.
    """
    local_model_path = _download_artifact_from_uri(
        artifact_uri=model_uri, output_path=dst_path
    )
    flavor_conf = _get_flavor_configuration(
        model_path=local_model_path, flavor_name=FLAVOR_NAME
    )
    _add_code_from_conf_to_system_path(local_model_path, flavor_conf)
    omnia_model_file_path = os.path.join(
        local_model_path, flavor_conf["pickled_model"]
    )
    return _load_model(path=omnia_model_file_path)


def _save_model(pipeline, mlflow_path) -> str:
    """
    It saves the omnia pipeline to the given path.

    It uses the following workflow:
    1. The pipeline path should be resolved to the absolute path before saving (save method does with resolve=True)
    2. The pipeline should be saved to the resolved path. It will write the pipeline to local disk.
    3. The pipeline should be copied to the target path. The target path depends on the pipeline path type:
      a) if the pipeline has a relative path, we should join mlflow tmp dir with the pipeline relative path
      b) if the pipeline has an absolute path, we should join mlflow tmp dir with the pipeline basename
    4. MLflow should log the pipeline as an artifact in the MLflow run.

    Parameters
    ----------
    pipeline : omnia.generics.Pipeline
        Fitted ``omnia`` pipeline object.

    mlflow_path : str
        Local path where the model is to be saved.

    Returns
    -------
        The pipeline basename or relative path.

    """
    # save the pipeline to the resolved path in the local disk.
    pipeline.save(resolve=True)

    # get the pipeline path type
    pipeline_path = Path(pipeline.path)

    # join the mlflow tmp dir with the pipeline basename or relative path
    path = os.path.join(mlflow_path, pipeline_path.name)

    # if the path does not exist, create it
    os.makedirs(path, exist_ok=True)

    # copy the pipeline files to the target path
    shutil.copytree(pipeline.path, path, dirs_exist_ok=True)

    return pipeline_path.name


def _load_model(path) -> 'Pipeline':
    from omnia.generics import Pipeline
    return Pipeline.load(path)


def _load_pyfunc(path) -> '_OmniaModelWrapper':
    """
    Load PyFunc implementation. Called by ``pyfunc.load_model``.

    Parameters
    ----------
    path : str
        Local filesystem path to the MLflow Model with the ``omnia`` flavor.

    Returns
    -------
    omnia_wrapper : _OmniaModelWrapper
        A ``omnia`` pipeline wrapper.
    """

    pyfunc_flavor_conf = _get_flavor_configuration(
        model_path=path, flavor_name=pyfunc.FLAVOR_NAME
    )
    path = os.path.join(path, pyfunc_flavor_conf["model_path"])

    return _OmniaModelWrapper(_load_model(path))


class _OmniaModelWrapper:
    def __init__(self, omnia_pipeline: 'Pipeline'):
        self.omnia_pipeline = omnia_pipeline

    def predict(self, dataframe, *args, **kwargs):
        return self.omnia_pipeline.predict(dataframe)

    def score(self, dataframe_x, dataframe_y, *args, **kwargs):
        return self.omnia_pipeline.score(dataframe_x, dataframe_y)
