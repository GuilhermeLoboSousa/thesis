def is_estimator(obj) -> bool:
    """
    Check if the object is an estimator.

    Parameters
    ----------
    obj : object
        The object to check.

    Returns
    -------
    bool
        True if the object is an estimator, False otherwise.
    """
    if hasattr(obj, 'fit') and hasattr(obj, 'fitted') and hasattr(obj, 'name'):
        return True
    return False


def is_transformer(obj) -> bool:
    """
    Check if the object is a transformer.

    Parameters
    ----------
    obj : object
        The object to check.

    Returns
    -------
    bool
        True if the object is a transformer, False otherwise.
    """
    if hasattr(obj, 'fit') and hasattr(obj, 'transform') and hasattr(obj, 'fitted') and hasattr(obj, 'name'):
        return True
    return False


def is_model(obj) -> bool:
    """
    Check if the object is a model.

    Parameters
    ----------
    obj : object
        The object to check.

    Returns
    -------
    bool
        True if the object is a model, False otherwise.
    """
    if hasattr(obj, 'fit') and hasattr(obj, 'predict') and hasattr(obj, 'name'):
        return True
    return False


def is_predictor(obj) -> bool:
    """
    Check if the object is a predictor.

    Parameters
    ----------
    obj : object
        The object to check.

    Returns
    -------
    bool
        True if the object is a predictor, False otherwise.
    """
    if hasattr(obj, 'fit') and hasattr(obj, 'predict') and hasattr(obj, 'learner'):
        return True
    return False

