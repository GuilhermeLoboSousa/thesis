from abc import ABC, abstractmethod
from typing import Callable

from joblib import Parallel, delayed


class Multiprocessing(ABC):
    def __init__(self, process: Callable, n_jobs: int = -1):
        self.n_jobs = n_jobs
        self._process = process

    @property
    def process(self):
        return self._process

    @abstractmethod
    def run(self, items):
        pass


class JoblibMultiprocessing(Multiprocessing):
    def run(self,
            items: list,
            backend: object = None,
            verbose: int = 0,
            timeout: int = None,
            pre_dispatch: str = '2 * n_jobs',
            batch_size: str or int = 'auto',
            temp_folder: str = None,
            max_nbytes: str or int = '1M',
            mmap_mode: str = 'r',
            prefer: str = None,
            require: str = None,
            **kwargs):
        """
        Run the process in parallel
        Parameters
        ----------
        items: list
            List of items to process
        backend:
            Backend to use for parallel processing
        verbose: int
            Verbosity level
        timeout: int
            Timeout for parallel processing
        pre_dispatch: int
            Number of jobs to pre-dispatch
        batch_size: int
            Batch size
        temp_folder: str
            Temporary folder
        max_nbytes: int
            Maximum number of bytes
        mmap_mode: str
            Memory map mode
        prefer: str
            Prefered backend
        require: str
            Required backend
        kwargs: dict
            Keyword arguments to pass to the process

        Returns
        -------
        results
        """
        # getting the callback function
        parallel_callback = Parallel(n_jobs=self.n_jobs, backend=backend, verbose=verbose,
                                     timeout=timeout, pre_dispatch=pre_dispatch,
                                     batch_size=batch_size, temp_folder=temp_folder)

        # getting the delayed processes as a generator
        delayed_processes = (delayed(self.process)(item, **kwargs) for item in items)

        # running the processes in parallel
        results = parallel_callback(delayed_processes)
        return results
