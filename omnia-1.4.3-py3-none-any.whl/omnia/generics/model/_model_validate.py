from typing import Any, Union

from omnia.generics.validation.boolean_operators.base_validator import BaseValidator
from omnia.generics.validation.boolean_operators.operand_holders import OperandHolder
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


class ModelValidateMixIn:
    """
    MixIn class for model validation.

    """

    validation_property: ValidationProperty = ValidationProperty()

    @classmethod
    def is_tag_compatible(cls, previous_output: Union[OperandHolder, BaseValidator]) -> bool:
        """
        Check if tag is compatible with input tag

        Parameters
        ----------
        previous_output: OperandHolder | BaseValidator

        Returns
        -------
        bool
            Whether the tag is compatible with input tag.
        """
        return cls.validation_property.input_is_equivalent(previous_output=previous_output)

    @classmethod
    def validate(cls, x: Any = None, y: Any = None) -> bool:
        """
        It validates if the data can be fitted by the model.
        This validate method is different from the estimator one, as it is a class method.
        Besides that, the validation is done
        by checking if the data is compatible with at least one tag using any method.

        Parameters
        ----------
        x : pd.DataFrame, optional
            The data used to fit the model.

        y : pd.DataFrame, optional
            The target used to fit the model.

        Returns
        -------
        valid : bool
            True if the model is valid, False otherwise.

        """
        if x is None and y is None:
            raise ValueError('Either x or y must be provided.')

        if not cls.validation_property.input_tag:
            return True

        return cls.validation_property.validate_input(x, y)
