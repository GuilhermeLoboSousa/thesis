from typing import Union, List
import tensorflow as tf
from omnia.generics.model.keras_models import KerasModel
from omnia.generics.model import RegressorMixin, ClassifierMixin, MultiOutputMixin
from omnia.generics.parameter import ModelParameter
from omnia.generics.parameter.space import Categorical, Bool
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class RNNModel(tf.keras.Model):
    """
    RNNModel is a custom Keras model that implements a deep RNN network with dense layers.
    """

    def __init__(self, n_tasks: int = 1, rnn_type: str = 'LSTM', bidirectional: bool = False, num_layers: int = 3,
                 hidden_dim: int = 64, num_dense_layers: int = 2,
                 n_classes: Union[List[int], int] = 1, drop: float = 0.3, activation: str = "relu",
                 last_layer_activation: Union[List[str], str] = "sigmoid", loss: Union[List[str], str] = 'binary_crossentropy', **kwargs):
        """
        Initialize the RNNModel.

        Parameters:
            n_tasks (int, optional):
                The number of output tasks. Default is 1.
            rnn_type (str, optional):
                Type of RNN layer to use. Can be 'LSTM', 'GRU', or 'SimpleRNN'. Defaults to 'LSTM'.
            bidirectional (bool, optional):
                Whether to use bidirectional RNN layers. 
                Defaults to False.
            num_layers (int, optional):
                The number of RNN layers in the network. 
                Default is 3.
            hidden_dim (int, optional):
                The number of hidden units in each RNN layer.
                Default is 64.
            num_dense_layers (int, optional):
                The number of dense layers in the network. 
                Default is 1.
            n_classes (list, optional):
                The dimensionality of the outputs. 
                A list of integers where each integer represents the output dimension of each task. 
                Default is [1].
            drop (float, optional):
                The dropout rate. 
                Default is 0.3.
            activation (str, optional):
                The activation function. 
                Defaults to 'relu'.
            last_layer_activation (list, optional):
                The activation function of the last layers. 
                A list of strings where each string represents the activation function of the last layer of each task.
                Defaults to ['sigmoid'].
            loss (list, optional):
                The loss to use. 
                A list of strings where each string represents the loss function of each task.
                Defaults to ['binary_crossentropy'].

        Returns:
            None
        """
        super(RNNModel, self).__init__()
        self.n_tasks = n_tasks
        self.rnn_type = rnn_type
        self.bidirectional = bidirectional
        self.num_layers = num_layers
        self.drop = drop
        self.n_classes = n_classes if isinstance(
            n_classes, list) else [n_classes] * n_tasks
        self.hidden_dim = hidden_dim
        self.num_dense_layers = num_dense_layers
        self.activation = activation
        self.last_layer_activation = last_layer_activation if isinstance(
            last_layer_activation, list) else [last_layer_activation] * n_tasks
        self.loss = loss if isinstance(loss, list) else [loss] * n_tasks

        # RNN layers (Shared)
        rnn_layers = []
        layer_type = {
            'LSTM': tf.keras.layers.LSTM,
            'GRU': tf.keras.layers.GRU,
            'SimpleRNN': tf.keras.layers.SimpleRNN
        }

        for i in range(self.num_layers):
            if self.rnn_type not in layer_type:
                raise ValueError(
                    f"Invalid RNN type. Supported types are: {', '.join(layer_type.keys())}.")
            rnn_layer = layer_type[self.rnn_type](self.hidden_dim, return_sequences=(i != self.num_layers - 1),
                                                  activation=self.activation)
            if bidirectional:
                rnn_layer = tf.keras.layers.Bidirectional(rnn_layer)

            rnn_layers.append(rnn_layer)
            rnn_layers.append(tf.keras.layers.Dropout(self.drop))

        self.rnn = tf.keras.Sequential(rnn_layers)

        # Dense layers
        self.dense_layers = []

        # Dense Layers for each output
        for i, last_activation in enumerate(self.last_layer_activation):
            task_layers = []
            dense_units = self.hidden_dim
            for _ in range(self.num_dense_layers):
                task_layers.append(tf.keras.layers.Dense(
                    dense_units, activation=self.activation))
                task_layers.append(tf.keras.layers.Dropout(self.drop))
                new_dense_units = dense_units // 2
                dense_units = max(1, new_dense_units)

            # Add output layer
            output_size = 1 if self.n_classes[i] == 2 else self.n_classes[i]
            task_layers.append(tf.keras.layers.Dense(
                output_size, activation=last_activation))
            self.dense_layers.append(tf.keras.Sequential(task_layers))

    def call(self, inputs):
        """
        Forward pass of the RNNModel.
        Args:
            inputs (tf.Tensor):
                The input data.
        Returns:
            tf.Tensor:
                The output of the model.
        """
        # Pass inputs through RNN layers
        x = self.rnn(inputs)
        # Pass output through dense layers for each output task
        outputs = [dense_layer(x) for dense_layer in self.dense_layers]
        return outputs if self.n_tasks > 1 else outputs[0]

    def get_config(self):
        """
        Gets the configuration of the RNN model.
        Returns:
            config (dict):
                A dictionary containing the configuration of the RNN model.
        """
        config = super(RNNModel, self).get_config()
        config.update({
            'n_tasks': self.n_tasks,
            'rnn_type': self.rnn_type,
            'bidirectional': self.bidirectional,
            'num_layers': self.num_layers,
            'hidden_dim': self.hidden_dim,
            'num_dense_layers': self.num_dense_layers,
            'n_classes': self.n_classes,
            'drop': self.drop,
            'activation': self.activation,
            'last_layer_activation': self.last_layer_activation,
            'loss': self.loss,
        })
        return config

    def get_weights(self) -> list:
        """
        Get the weights of the model.
        Returns:
            weights (list):
                A list of the weights of the model.
                The list contains the weights of the RNN layers and the dense layers.
        """
        return [layer.get_weights() for layer in self.layers]


@class_register
class RNNModelClassifier(KerasModel, ClassifierMixin, MultiOutputMixin):
    """
    A tabular transformer classifier
    """

    name = 'RNNModelClassifier'
    model = RNNModel
    # Default is single-task classification
    n_tasks = ModelParameter(default=1, tunable=False)
    rnn_type = ModelParameter(
        default='LSTM', tunable=True, space=Categorical('LSTM', 'GRU', 'SimpleRNN'))
    bidirectional = ModelParameter(default=False, tunable=True, space=Bool())
    num_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 4, 5))
    hidden_dim = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 128, 256, 512))
    num_dense_layers = ModelParameter(
        default=2, tunable=True, space=Categorical( 2, 3, 4))
    activation = ModelParameter(default='relu', tunable=False)
    # Default is single-task binary classification
    n_classes = ModelParameter(default=2, tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    last_layer_activation = ModelParameter(default='sigmoid', tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)
    loss = ModelParameter(default='binary_crossentropy', tunable=False)
    metrics = ModelParameter(default=['accuracy'], tunable=False)

    path = 'rnn_classifier/'
    _input_type = DataTag.MATRIX
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTILABEL, TaskTag.MULTITASK_BINARY,
                       TaskTag.MULTITASK_MULTICLASS, TaskTag.MULTITASK_MULTILABEL]

    def _can_predict_proba(self) -> bool:
        """
        Checks if the model can predict probabilities.

        Returns:
            bool:
                True if the model can predict probabilities, False otherwise.
        """
        return True


@class_register
class RNNModelRegressor(KerasModel, RegressorMixin, MultiOutputMixin):
    """
    A tabular transformer regressor
    """

    name = 'RNNModelRegressor'
    model = RNNModel
    # Default is single-task regression
    n_tasks = ModelParameter(default=1, tunable=False)
    rnn_type = ModelParameter(
        default='LSTM', tunable=True, space=Categorical('LSTM', 'GRU', 'SimpleRNN'))
    bidirectional = ModelParameter(default=False, tunable=True, space=Bool())
    num_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 4, 5))
    hidden_dim = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 128, 256, 512))
    num_dense_layers = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default=['linear'], tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='mean_squared_error', tunable=False)
    metrics = ModelParameter(default='mean_squared_error', tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'rnn_regressor/'
    _input_type = DataTag.MATRIX
    _estimator_type = [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]
