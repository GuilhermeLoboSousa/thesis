import json
import os
from typing import Any, Callable, Union, List
import tensorflow as tf

from omnia.generics import np, pd
from omnia.generics.model import Model
from omnia.generics.utils.keywords import kwargs_only
from keras.callbacks import ModelCheckpoint
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag
from keras.utils import to_categorical


class KerasModel(Model):
    _input_type = DataTag.UNDEFINED
    _estimator_type = TaskTag.UNDEFINED
    path = 'keras_model/'

    @kwargs_only(has_self=True)
    def __init__(self, callbacks: Union[Callable, List[Callable]] = None, **kwargs):
        """
        The model constructor.
        """
        super(KerasModel, self).__init__(**kwargs)
        self.model = self.model(**self.parameters)
        self.params = kwargs

        if isinstance(callbacks, Callable):
            callbacks = [callbacks]
        self.callbacks = callbacks

    def _fit(self, x: Any, y: Any, x_val: Any = None, y_val: Any = None, **kwargs) -> 'KerasModel':
        """
        Fit the model to the data.

        Parameters
        ----------
        x: Any
            The input data.
        y: Any
            The target data.
            For multi-output models, y should be a list of arrays like [y1, y2, y3, ...].
        x_val: Any
            The validation input data.
        y_val: Any
            The validation target data.
        kwargs: dict
            Additional fitting parameters.
        """
        if isinstance(y, pd.DataFrame) or isinstance(y, pd.Series):
            y = y.values

        if isinstance(y_val, pd.DataFrame) or isinstance(y_val, pd.Series):
            y_val = y_val.values

        is_multitask = hasattr(y, 'shape') and len(
            y.shape) > 1 and y.shape[1] > 1

        if self.problem_type == 'multiclass':
            y = to_categorical(y)
            if y_val is not None:
                y_val = to_categorical(y_val)

        self.model.compile(optimizer=self.optimizer,
                           loss=self.loss, metrics=self.metrics)

        # For multitask models, y should be a list of arrays like [y1, y2, y3, ...]
        if is_multitask:
            y = [y[:, i] for i in range(y.shape[1])]
            if y_val is not None:
                y_val = [y_val[:, i] for i in range(y_val.shape[1])]

        best_weights_path = os.path.join(self.path, 'best_weights')
        if not os.path.exists(best_weights_path):
            os.makedirs(best_weights_path)

        monitor = 'val_loss' if x_val is not None else 'loss'
        model_checkpoint = ModelCheckpoint(filepath=os.path.join(
            best_weights_path, 'best_model.h5'), monitor=monitor, save_best_only=True, save_weights_only=True)
        if self.callbacks is None:
            self.callbacks = [model_checkpoint]
        else:
            self.callbacks.append(model_checkpoint)

        if x_val is None or y_val is None:
            self.model.fit(x, y, batch_size=self.batch_size,
                           epochs=self.epochs, callbacks=self.callbacks, **kwargs)
        else:
            self.model.fit(x, y, batch_size=self.batch_size,
                           epochs=self.epochs, validation_data=(x_val, y_val), callbacks=self.callbacks, **kwargs)

        # load best model weights
        self.model.load_weights(os.path.join(
            best_weights_path, 'best_model.h5'))
        return self

    def process_keras_predictions(self, raw_pred: Union[np.ndarray, List[np.ndarray]]) -> np.ndarray:
        """
        Processes raw Keras model predictions into structured predictions based on task type.

        Parameters
        ----------
        raw_pred: Union[np.ndarray, List[np.ndarray]]
            Raw predictions from the Keras model.

        Returns
        -------
        np.ndarray
            Processed predictions structured according to task type in a (n_samples, n_tasks) shape.
        """
        def binary_predictions(pred):
            return np.array([1 if x > 0.5 else 0 for x in pred])

        def multiclass_predictions(pred):
            return np.argmax(pred, axis=1)

        def regression_predictions(pred):
            return pred

        task_type = self.problem_type
        if task_type == 'binary':
            process_func = binary_predictions
        elif task_type == 'multiclass':
            process_func = multiclass_predictions
        elif task_type == 'regression':
            process_func = regression_predictions
        else:
            raise ValueError(
                "Invalid task type. Supported types are 'binary', 'multiclass', 'regression'.")

        if isinstance(raw_pred, list):  # Multitask scenario
            if task_type != 'regression':
                processed_predictions = np.array(
                    [process_func(x) for x in raw_pred]).T
            else:
                processed_predictions = np.hstack(raw_pred)
        elif task_type != 'regression':
            # Add an extra dimension for binary and multiclass predictions
            processed_predictions = np.expand_dims(
                process_func(raw_pred), axis=1)
        else:
            processed_predictions = process_func(raw_pred)

        return processed_predictions

    def _predict(self, x: Any) -> np.ndarray:
        """
        Make predictions using the model on the input data.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        np.ndarray
            The model predictions.
        """
        return self.process_keras_predictions(self.model.predict(x))

    def _predict_proba(self, x: Any) -> np.ndarray:
        """
        Make probability predictions using the model on the input data.

        Parameters
        ----------
        x: Any
            The input data.
        """
        if not self.can_predict_proba:
            raise ValueError('Model cannot predict probabilities.')
        raw_pred = self.model.predict(x)

        if isinstance(raw_pred, list):  # Multitask scenario
            if self.problem_type == 'multiclass':
                return np.stack(raw_pred, axis=1)
            else:
                return np.hstack([arr.ravel()[:, np.newaxis] for arr in raw_pred])
        else:
            if self.problem_type == 'multiclass':
                return np.expand_dims(raw_pred, axis=1)

        return raw_pred

    def save(self, path: str = None) -> None:
        """
        Save the model to the specified path.

        Parameters
        ----------
        path: str
            The path to save the model to.
        """
        try:
            path = self.path if path is None else path
            if path != self.path:
                try:
                    os.rename(self.path, path)
                except FileExistsError:
                    raise FileExistsError(f'Folder already exists: {path}')
            # save params
            with open(os.path.join(path, 'params.json'), 'w') as file:
                json.dump(self.params, file)
            # save model
            model_path = os.path.join(path, 'model')
            self.model.save(model_path, save_format='tf')
            state = {'path': path,
                     'problem_type': self.problem_type,
                     '_fitted': self._fitted}
            # save state
            state_path = os.path.join(path, 'state.json')
            with open(state_path, 'w') as file:
                json.dump(state, file)
        except Exception as e:
            raise ValueError(f'Error saving model: {e}')

    @classmethod
    def load(cls, path: str = None) -> 'KerasModel':
        """
        Load the model from the specified path.

        Parameters
        ----------
        path: str
            The path to load the model from.

        Returns
        -------
        KerasModel
            The loaded model.
        """
        if path is None:
            path = cls.path
        model_path = os.path.join(path, 'model')
        model = tf.keras.models.load_model(model_path)
        model.load_weights(os.path.join(path, 'best_weights', 'best_model.h5'))

        # state
        state_path = os.path.join(path, 'state.json')
        with open(state_path, 'r') as file:
            state = json.load(file)
        # load parameters
        with open(os.path.join(path, 'params.json'), 'r') as file:
            parameters = json.load(file)
        instance = cls(**parameters)
        instance.model = model
        instance._problem_type = state['problem_type']
        instance._fitted = state['_fitted']
        return instance
