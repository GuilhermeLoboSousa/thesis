from typing import Union, List
import tensorflow as tf
from omnia.generics.model.keras_models import KerasModel
from omnia.generics.model import RegressorMixin, ClassifierMixin, MultiOutputMixin
from omnia.generics.parameter import ModelParameter
from omnia.generics.parameter.space import Categorical
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class CNN1DModel(tf.keras.Model):
    """
    CNNModel is a class that represents a convolutional neural network model.
    """

    def __init__(self, n_tasks: int = 1, num_conv_layers: int = 2, first_filter_size: int = 128, kernel_size: int = 3,
                 stride: int = 1, padding: str = 'same', pool_size: int = 2, num_dense_layers: int = 1,
                 first_dense_units: int = 64, n_classes: Union[List[int], int] = 1, drop: float = 0.3, activation: str = "relu",
                 last_layer_activation: Union[List[str], str] = "sigmoid", loss: Union[List[str], str] = 'binary_crossentropy', **kwargs):
        """
        Initialize the CNNModel.

        Parameters
        ----------
        n_tasks : int
            The number of outputs. Defaults to 1.
        num_conv_layers (int, optional):
            The number of convolutional layers. Defaults to 2.
        first_filter_size (list, optional):
            The number of filters in each convolutional layer. Defaults to [128, 32].
        kernel_size (list, optional):
            The size of filters in each convolutional layer. Defaults to [3, 3].
        stride (int, optional):
            The stride of the convolutional layers. Defaults to 1.
        padding (str, optional):
            The padding of the convolutional layers. Defaults to 'same'.
            Should be one of 'valid', 'same', or 'causal'.
        pool_size (list, optional):
            The size of pooling windows in each convolutional layer. Defaults to [2, 2].
        num_dense_layers (int, optional):
            The number of dense layers. Defaults to 1.
        first_dense_units (list, optional):
            The number of neurons in each dense layer. Defaults to [64].
        n_classes (int, optional):
            The dimension of the output. Defaults to 1.
        drop (float, optional):
            The dropout rate. Defaults to 0.3.
        activation (str, optional):
            The activation function. Defaults to 'relu'.
        last_layers_activations (list, optional):
            The activation function list of the last layers. Defaults to ['sigmoid'].
        loss (list, optional):
            The loss function list. Defaults to ['binary_crossentropy'].
        """
        super(CNN1DModel, self).__init__()

        self.n_tasks = n_tasks
        self.input_dim = 1024  # dummy input dimension
        self.num_conv_layers = num_conv_layers
        self.first_filter_size = first_filter_size
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.pool_size = pool_size
        self.num_dense_layers = num_dense_layers
        self.first_dense_units = first_dense_units
        self.n_classes = n_classes if isinstance(
            n_classes, list) else [n_classes] * n_tasks
        self.drop = drop
        self.activation = activation
        self.last_layer_activation = last_layer_activation if isinstance(
            last_layer_activation, list) else [last_layer_activation] * n_tasks
        self.loss = loss if isinstance(loss, list) else [loss] * n_tasks

        # Reshape layer
        self.reshape_layer = tf.keras.layers.Reshape((self.input_dim, 1))

        # Convolutional layers
        conv_layers = []
        filter_size = self.first_filter_size
        for i in range(self.num_conv_layers):
            conv_layers.append(tf.keras.layers.Conv1D(filters=filter_size, kernel_size=self.kernel_size,
                                                      strides=self.stride, padding=self.padding,
                                                      activation=self.activation))
            conv_layers.append(tf.keras.layers.BatchNormalization())
            conv_layers.append(tf.keras.layers.MaxPooling1D(
                pool_size=self.pool_size, padding=self.padding))
            conv_layers.append(tf.keras.layers.Dropout(self.drop))
            new_filter_size = filter_size // 2
            filter_size = max(new_filter_size, 1)

        self.conv = tf.keras.Sequential(conv_layers)

        # Flatten layer
        self.flatten = tf.keras.layers.Flatten()

        # Dense layers
        self.dense_layers = []

        # Dense Layers for each output
        for i, last_activation in enumerate(self.last_layer_activation):
            dense_units = self.first_dense_units
            task_layers = []
            for _ in range(self.num_dense_layers):
                task_layers.append(tf.keras.layers.Dense(
                    dense_units, activation=self.activation))
                task_layers.append(tf.keras.layers.Dropout(self.drop))
                new_dense_units = dense_units // 2
                dense_units = max(new_dense_units, 1)

            # Add output layer
            output_size = 1 if self.n_classes[i] == 2 else self.n_classes[i]
            task_layers.append(tf.keras.layers.Dense(
                output_size, activation=last_activation))
            self.dense_layers.append(tf.keras.Sequential(task_layers))

    def call(self, inputs):
        """
        Forward pass of the CNNModel.

        Args:
            inputs (tf.Tensor): 
                The input data.

        Returns:
            tf.Tensor: 
                The output of the model.
        """
        if self.reshape_layer.target_shape != (inputs.shape[1], 1):
            self.reshape_layer.target_shape = (inputs.shape[1], 1)

        # Reshape input
        x = self.reshape_layer(inputs)
        # Pass inputs through convolutional layers
        x = self.conv(x)
        # Pass output through flatten layer
        flat = self.flatten(x)

        # handle multiple outputs
        if self.n_tasks > 1:
            out = [dense_layers(flat)
                   for dense_layers in self.dense_layers]
            return out

        # Pass output through dense layers
        out = self.dense_layers[0](flat)
        return out

    def get_config(self):
        """
        Gets the configuration of the CNNModel.

        Returns:
            config (dict): 
                A dictionary containing the configuration of the CNNModel.
        """
        config = super(CNN1DModel, self).get_config()
        config.update({
            'n_tasks': self.n_tasks,
            'num_conv_layers': self.num_conv_layers,
            'first_filter_size': self.first_filter_size,
            'kernel_size': self.kernel_size,
            'stride': self.stride,
            'padding': self.padding,
            'pool_size': self.pool_size,
            'num_dense_layers': self.num_dense_layers,
            'first_dense_units': self.first_dense_units,
            'n_classes': self.n_classes,
            'drop': self.drop,
            'activation': self.activation,
            'last_layer_activation': self.last_layer_activation,
            'loss': self.loss,
        })
        return config

    def get_weights(self) -> list:
        """
        Gets the weights of the CNNModel.

        Returns:
            weights (list): 
                A list containing the weights of the CNNModel.
                The list contains the weights of each layer.
        """
        return [layer.get_weights() for layer in self.layers]


@class_register
class CNN1DModelClassifier(KerasModel, ClassifierMixin, MultiOutputMixin):
    """
    A 1D CNN classifier.
    """
    name = 'CNNModelClassifier'
    model = CNN1DModel
    n_tasks = ModelParameter(default=1, tunable=False)
    num_conv_layers = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    first_filter_size = ModelParameter(
        default=128, tunable=True, space=Categorical(128, 64, 32))
    kernel_size = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 5, 7))
    stride = ModelParameter(default=1, tunable=True,
                            space=Categorical(1, 2, 3))
    padding = ModelParameter(default='same', tunable=False)
    pool_size = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    num_dense_layers = ModelParameter(
        default=1, tunable=True, space=Categorical(1, 2, 3))
    first_dense_units = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 16))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='sigmoid', tunable=False)
    n_classes = ModelParameter(default=2, tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='binary_crossentropy', tunable=False)
    metrics = ModelParameter(default=['accuracy'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'cnn_classifier/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTILABEL, TaskTag.MULTITASK_BINARY,
                       TaskTag.MULTITASK_MULTICLASS, TaskTag.MULTITASK_MULTILABEL]

    def _can_predict_proba(self) -> bool:
        """
        Check if the model can predict probabilities.

        Returns:
            bool:
                True if the model can predict probabilities, False otherwise.
        """
        return True


@class_register
class CNN1DModelRegressor(KerasModel, RegressorMixin, MultiOutputMixin):
    """
    A 1D CNN regressor.
    """
    name = 'CNNModelRegressor'
    model = CNN1DModel
    n_tasks = ModelParameter(default=1, tunable=False)
    num_conv_layers = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    first_filter_size = ModelParameter(
        default=128, tunable=True, space=Categorical(128, 64, 32))
    kernel_size = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 5, 7))
    stride = ModelParameter(default=1, tunable=True,
                            space=Categorical(1, 2, 3))
    padding = ModelParameter(default='same', tunable=False)
    pool_size = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    num_dense_layers = ModelParameter(
        default=1, tunable=True, space=Categorical(1, 2, 3))
    first_dense_units = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 16))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='linear', tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='mean_squared_error', tunable=False)
    metrics = ModelParameter(default=['mean_squared_error'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'cnn_regressor/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]
