from tensorflow.keras.optimizers import (Adam, Adadelta, Adagrad, Adamax, Ftrl, Nadam, RMSprop, SGD, Adafactor, AdamW,
                                         Lion)
from tensorflow.keras.losses import (BinaryCrossentropy, BinaryFocalCrossentropy, CategoricalCrossentropy,
                                     CategoricalFocalCrossentropy, CategoricalHinge, CosineSimilarity, Huber, Hinge,
                                     KLDivergence, LogCosh, MeanAbsoluteError, MeanAbsolutePercentageError,
                                     MeanSquaredError, MeanSquaredLogarithmicError, Poisson,
                                     SparseCategoricalCrossentropy, SquaredHinge)


KERAS_OPTIMIZERS = {
    "Adadelta": Adadelta,
    "Adagrad": Adagrad,
    "Adam": Adam,
    "Adamax": Adamax,
    "Ftrl": Ftrl,
    "Nadam": Nadam,
    "RMSprop": RMSprop,
    "SGD": SGD,
    "Adafactor": Adafactor,
    "AdamW": AdamW,
    "Lion": Lion,
}

KERAS_LOSSES = {
    'binary_crossentropy': BinaryCrossentropy,
    'binary_focal_crossentropy': BinaryFocalCrossentropy,
    'categorical_crossentropy': CategoricalCrossentropy,
    'categorical_focal_crossentropy': CategoricalFocalCrossentropy,
    'categorical_hinge': CategoricalHinge,
    'cosine_similarity': CosineSimilarity,
    'hinge': Hinge,
    'kl_divergence': KLDivergence,
    'huber': Huber,
    'log_cosh': LogCosh,
    'mean_absolute_error': MeanAbsoluteError,
    'mean_absolute_percentage_error': MeanAbsolutePercentageError,
    'mean_squared_error': MeanSquaredError,
    'mean_squared_logarithmic_error': MeanSquaredLogarithmicError,
    'poisson': Poisson,
    'sparse_categorical_crossentropy': SparseCategoricalCrossentropy,
    'squared_hinge': SquaredHinge,
}
