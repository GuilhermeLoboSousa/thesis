from typing import List, Union, Dict

from tensorflow.keras.layers import Embedding, LayerNormalization, MultiHeadAttention, Flatten, Dense, Dropout
import tensorflow as tf

from omnia.generics.model.keras_models import KerasModel
from omnia.generics.model import RegressorMixin, ClassifierMixin, MultiOutputMixin
from omnia.generics.parameter.space import Int, Real
from omnia.generics.parameter import ModelParameter
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class KerasTabularTransformer(tf.keras.Model):

    def __init__(self, n_tasks: int = 1, embedding_output_dim: int = 32,
                 n_attention_layers: int = 2, n_attention_heads: int = 4, attention_dropout: float = 0.0,
                 attention_key_dim: int = 10, dense_units: int = 64, dense_activation: str = 'relu',
                 dense_dropout: float = 0.1, last_layers_units: List[int] = [1],
                 last_layers_activations: List[str] = ['linear'], **kwargs):
        """
        Build a transformer model using Keras.

        Parameters
        ----------
        n_tasks : int
            Number of tasks.
        embedding_output_dim : int
            Output dimension of the embedding layer.
        n_attention_layers : int
            Number of attention layers.
        n_attention_heads : int
            Number of attention heads.
        attention_dropout :float
            Attention dropout.
        attention_key_dim : int
            Attention key dimensions.
        dense_units : int
            Number of units in the dense layer.
        dense_activation : str
            Activation function for the dense layer.
        dense_dropout : float
            Dropout rate for the dense layer.
        last_layers_units : List[int]
            List of units in the last layers.
        last_layers_activations : List[str]
            List of activation functions for the last layers.
        optimizer : str
            Optimizer.
        loss : str
            List of losses or dictionary of losses per task.
        metrics : Union[List[str], Dict[str, str]]
            List of metrics or dictionary of metrics per task.

        Returns
        -------
        model : Model
            The built model.
        """
        # model not supported yet, raise an error
        raise NotImplementedError('KerasTabularTransformer is not supported yet.')
        super(KerasTabularTransformer, self).__init__()
        self.input_dim = None
        self.n_tasks = n_tasks
        self.embedding_output_dim = embedding_output_dim
        self.n_attention_layers = n_attention_layers
        self.n_attention_heads = n_attention_heads
        self.attention_dropout = attention_dropout
        self.attention_key_dim = attention_key_dim
        self.dense_units = dense_units
        self.dense_activation = dense_activation
        self.dense_dropout = dense_dropout
        self.last_layers_units = last_layers_units
        self.last_layers_activations = last_layers_activations

        # Embedding layer
        self.embedding_layer = Embedding(input_dim=self.input_dim, output_dim=self.embedding_output_dim)

        # Normalization layer
        self.normalization_layer = LayerNormalization()

        # Attention layers
        self.attention_layers = []
        for _ in range(n_attention_layers):
            attention_layer = MultiHeadAttention(num_heads=n_attention_heads, key_dim=attention_key_dim,
                                                 dropout=attention_dropout)
            self.attention_layers.append(attention_layer)

        # Flatten layer
        self.flatten_layer = Flatten()

        # Output layers
        self.output_layers = []
        for i in range(n_tasks):
            if len(last_layers_units) == 1:
                last_layers_units = last_layers_units * n_tasks
            if len(last_layers_activations) == 1:
                last_layers_activations = last_layers_activations * n_tasks
            output_layer = Dense(units=dense_units, activation=dense_activation)
            dropout_layer = Dropout(dense_dropout)
            last_layer = Dense(units=last_layers_units[i], activation=last_layers_activations[i])
            self.output_layers.append((output_layer, dropout_layer, last_layer))

    def call(self, inputs):
        if self.input_dim is None:
            self.input_dim = inputs.shape[-1]
            self.embedding_layer.input_dim = self.input_dim

        x = self.embedding_layer(inputs)
        x = self.normalization_layer(x)

        for attention_layer in self.attention_layers:
            x = attention_layer(x, x)
            x = self.normalization_layer(x)

        x = self.flatten_layer(x)

        outputs = []
        for output_layer, dropout_layer, last_layer in self.output_layers:
            output = output_layer(x)
            output = dropout_layer(output)
            output = last_layer(output)
            outputs.append(output)
        if len(outputs) == 1:
            return outputs[0]
        return tf.transpose(tf.stack(outputs, axis=0), perm=[1, 0, 2])

    def get_config(self):
        config = super(KerasTabularTransformer, self).get_config()
        config.update({
            'n_tasks': self.n_tasks,
            'embedding_output_dim': self.embedding_output_dim,
            'n_attention_layers': self.n_attention_layers,
            'n_attention_heads': self.n_attention_heads,
            'attention_dropout': self.attention_dropout,
            'attention_key_dim': self.attention_key_dim,
            'dense_units': self.dense_units,
            'dense_activation': self.dense_activation,
            'dense_dropout': self.dense_dropout,
            'last_layers_units': self.last_layers_units,
            'last_layers_activations': self.last_layers_activations
        })
        return config


@class_register
class TabularTransformerRegressor(KerasModel, RegressorMixin, MultiOutputMixin):
    """
    A tabular transformer regressor.
    """
    name = 'TabularTransformerRegressor'
    model = KerasTabularTransformer
    n_tasks = ModelParameter(default=1, tunable=False)
    embedding_output_dim = ModelParameter(default=32, tunable=True, space=Int(16, 1024, default=32))
    n_attention_layers = ModelParameter(default=2, tunable=True, space=Int(1, 10, default=2))
    n_attention_heads = ModelParameter(default=4, tunable=True, space=Int(2, 10, default=4))
    attention_dropout = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 1.0, default=0.1))
    attention_key_dim = ModelParameter(default=10, tunable=True, space=Int(1, 100, default=10))
    dense_units = ModelParameter(default=64, tunable=True, space=Int(32, 256, default=64))
    dense_activation = ModelParameter(default='relu', tunable=False)
    dense_dropout = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 1.0, default=0.1))
    last_layers_units = ModelParameter(default=[1], tunable=False)
    last_layers_activations = ModelParameter(default=['linear'], tunable=False)
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='mean_squared_error', tunable=False)
    metrics = ModelParameter(default=['mean_squared_error'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'tabular_transformer_regressor/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]


@class_register
class TabularTransformerClassifier(KerasModel, ClassifierMixin, MultiOutputMixin):
    name = 'TabularTransformerClassifier'
    model = KerasTabularTransformer
    n_tasks = ModelParameter(default=1, tunable=False)
    embedding_output_dim = ModelParameter(default=32, tunable=False)
    n_attention_layers = ModelParameter(default=2, tunable=True, space=Int(1, 10, default=2))
    n_attention_heads = ModelParameter(default=4, tunable=True, space=Int(2, 10, default=4))
    attention_dropout = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 1.0, default=0.1))
    attention_key_dim = ModelParameter(default=10, tunable=True, space=Int(1, 100, default=10))
    dense_units = ModelParameter(default=64, tunable=True, space=Int(32, 256, default=64))
    dense_activation = ModelParameter(default='relu', tunable=False)
    dense_dropout = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 1.0, default=0.1))
    last_layers_units = ModelParameter(default=[1], tunable=False)
    last_layers_activations = ModelParameter(default=['sigmoid'], tunable=False)
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='binary_crossentropy', tunable=False)
    metrics = ModelParameter(default=['accuracy'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'tabular_transformer_classifier/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTILABEL, TaskTag.MULTITASK_BINARY,
                       TaskTag.MULTITASK_MULTICLASS, TaskTag.MULTITASK_MULTILABEL]

    def _can_predict_proba(self) -> bool:
        """
        Check if the model can predict probabilities.

        Returns
        -------
        bool
            True.
        """
        return True
