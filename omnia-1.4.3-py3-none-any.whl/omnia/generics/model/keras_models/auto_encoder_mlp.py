import tensorflow as tf
from omnia.generics import np
from omnia.generics.model.keras_models import KerasModel
from omnia.generics.model import RegressorMixin, ClassifierMixin, MultiOutputMixin
from omnia.generics.parameter import ModelParameter
from omnia.generics.parameter.space import Categorical
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


def unpack_x_y_sample_weight(data):
    """Unpacks user-provided data tuple.

    This is a convenience utility to be used when overriding
    `Model.train_step`, `Model.test_step`, or `Model.predict_step`.
    This utility makes it easy to support data of the form `(x,)`,
    `(x, y)`, or `(x, y, sample_weight)`.

    Example:

    >>> features_batch = ops.ones((10, 5))
    >>> labels_batch = ops.zeros((10, 5))
    >>> data = (features_batch, labels_batch)
    >>> # `y` and `sample_weight` will default to `None` if not provided.
    >>> x, y, sample_weight = unpack_x_y_sample_weight(data)
    >>> sample_weight is None
    True

    Args:
        data: A tuple of the form `(x,)`, `(x, y)`, or `(x, y, sample_weight)`.

    Returns:
        The unpacked tuple, with `None`s for `y` and `sample_weight` if they are
        not provided.
    """
    if isinstance(data, list):
        data = tuple(data)
    if not isinstance(data, tuple):
        return data, None, None
    elif len(data) == 1:
        return data[0], None, None
    elif len(data) == 2:
        return data[0], data[1], None
    elif len(data) == 3:
        return data[0], data[1], data[2]
    error_msg = (
        "Data is expected to be in format `x`, `(x,)`, `(x, y)`, "
        f"or `(x, y, sample_weight)`, found: {data}"
    )
    raise ValueError(error_msg)


class AutoEncoderMLP(tf.keras.Model):
    """
    AutoEncoderMLP is a class that represents an autoencoder model with an MLP at the end for classification/regression
    tasks.
    """

    def __init__(self, num_layers: int = 2, latent_dim: int = 32, first_hidden_dense_units: int = 512,
                 num_layers_class: int = 2, n_classes: int = 2, drop: float = 0.3,
                 activation: str = "relu", last_layer_activation: str = "sigmoid", **kwargs):
        """
        Initializes an instance of the AutoEncoderClassification class.

        Parameters
        ----------
        num_layers: int
            The number of layers in the encoder and decoder.
        latent_dim: int
            The dimension of the latent space.
        first_hidden_dense_units: int
            The number of units in the first hidden dense layer.
        num_layers_class: int
            The number of layers in the MLP classifier.
        n_classes: int
            The number of classes.
        drop: float
            The dropout rate.
        activation: str
            The activation function.
        last_layer_activation: str
            The activation function of the last layer.
        """
        super(AutoEncoderMLP, self).__init__()
        # this is a dummy number of features, it will be updated in the call method
        self.input_dimension = 100
        self.latent_dim = latent_dim
        self.num_layers = num_layers
        self.drop = drop
        self.first_hidden_dense_units = first_hidden_dense_units
        self.num_layers_class = num_layers_class
        self.n_classes = n_classes
        self.activation = activation
        self.last_layer_activation = last_layer_activation

        # Encoder layers
        self.encoder_layers = [tf.keras.layers.Dense(
            self.input_dimension, activation=self.activation)]
        self.encoder_layers.append(tf.keras.layers.Dropout(self.drop))
        encoder_units = self.first_hidden_dense_units
        for i in range(self.num_layers):
            self.encoder_layers.append(tf.keras.layers.Dense(
                encoder_units, activation=self.activation))
            self.encoder_layers.append(tf.keras.layers.Dropout(self.drop))
            encoder_units = encoder_units // 2
        self.encoder_layers.append(tf.keras.layers.Dense(
            self.latent_dim, activation=self.activation))
        self.encoder_layers.append(tf.keras.layers.Dropout(self.drop))
        self.encoder = tf.keras.Sequential(self.encoder_layers)

        # Decoder layers
        self.decoder_layers = []
        decoder_units = self.latent_dim
        for _ in reversed(range(self.num_layers)):
            self.decoder_layers.append(tf.keras.layers.Dense(
                decoder_units, activation=self.activation))
            self.decoder_layers.append(tf.keras.layers.Dropout(self.drop))
            decoder_units = decoder_units * 2
        self.decoder_layers.append(tf.keras.layers.Dense(
            self.input_dimension, activation=self.activation))
        self.decoder = tf.keras.Sequential(self.decoder_layers)

        # mlp_layers
        mlp_layers = []
        mlp_units = self.latent_dim
        for i in range(self.num_layers_class):
            mlp_layers.append(tf.keras.layers.Dense(
                mlp_units, activation=self.activation))
            mlp_layers.append(tf.keras.layers.Dropout(self.drop))
            mlp_units = mlp_units // 2
        if self.n_classes == 2:
            mlp_layers.append(tf.keras.layers.Dense(
                1, activation=self.last_layer_activation))
        else:
            mlp_layers.append(tf.keras.layers.Dense(
                self.n_classes, activation=self.last_layer_activation))
        self.classifier = tf.keras.Sequential(mlp_layers)

    def predict_step(self, data):
        """
        Predicts the output of the model.

        Parameters
        ----------
        data: Any
            The input data.

        Returns
        -------
        y_pred: Any
            The predicted output.
        """
        x, _, _ = unpack_x_y_sample_weight(data)
        return self(x, training=False)[1]

    def train_step(self, data):
        """
        Training step of the AutoEncoderClassification model.

        Parameters
        ----------
        data: Any
            The input data.

        Returns
        -------
        metrics: dict
            A dictionary containing the metrics of the model
        """
        x, y, sample_weight = unpack_x_y_sample_weight(data)
        # Run forward pass.
        with tf.GradientTape() as tape:
            y_pred = self(x, training=True)[1]
            loss = self.compute_loss(x, y, y_pred, sample_weight)
        self._validate_target_and_loss(y, loss)
        # Run backwards pass.
        self.optimizer.minimize(loss, self.trainable_variables, tape=tape)
        return self.compute_metrics(x, y, y_pred, sample_weight)

    def test_step(self, data):
        """
        Test step of the AutoEncoderClassification model.

        Parameters
        ----------
        data: Any
            The input data.

        Returns
        -------
        metrics: dict
            A dictionary containing the metrics of the model
        """
        x, y, sample_weight = unpack_x_y_sample_weight(data)

        y_pred = self(x, training=False)[1]
        # Updates stateful loss metrics.
        self.compute_loss(x, y, y_pred, sample_weight)
        return self.compute_metrics(x, y, y_pred, sample_weight)

    def call(self, inputs):
        """
        Forward pass of the AutoEncoderClassification model.

        Args:
            inputs (tf.Tensor):
                The input data.

        Returns:
            decoded, classification (tuple):
                A tuple containing the reconstructed input data and the classification output.
        """
        if inputs.shape[1] != self.input_dimension:
            self.input_dimension = inputs.shape[1]
            self.encoder_layers[0].units = self.input_dimension
            self.decoder_layers[-1].units = self.input_dimension

        encoded = self.encoder(inputs)
        decoded = self.decoder(encoded)
        classification = self.classifier(encoded)
        return decoded, classification

    def get_config(self):
        """
        Gets the configuration of the AutoEncoderClassification model.

        Returns:
            config (dict):
                A dictionary containing the configuration of the AutoEncoderClassification model.
        """
        config = super(AutoEncoderMLP, self).get_config()
        config.update({
            'num_layers': self.num_layers,
            'latent_dim': self.latent_dim,
            'first_hidden_dense_units': self.first_hidden_dense_units,
            'num_layers_class': self.num_layers_class,
            'num_classes': self.n_classes,
            'drop': self.drop,
            'activation': self.activation,
            'last_layer_activation': self.last_layer_activation
        })
        return config


@class_register
class AutoEncoderMLPClassifier(KerasModel, ClassifierMixin):
    """
    An autoencoder followed by an MLP classifier.
    """
    name = 'AutoEncoderMLPClassifier'
    model = AutoEncoderMLP
    num_layers = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    latent_dim = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 128, 256, 512))
    first_hidden_dense_units = ModelParameter(
        default=512, tunable=True, space=Categorical(512, 1024, 256, 128, 64))
    num_layers_class = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    n_classes = ModelParameter(default=2, tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='sigmoid', tunable=False)
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(
        default=['mse', 'binary_crossentropy'], tunable=False)
    metrics = ModelParameter(default=['mse', 'accuracy'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'auto_encoder_mlp_classifier/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTILABEL]

    def _can_predict_proba(self) -> bool:
        """
        Check if the model can predict probabilities.

        Returns
        -------
        bool
            True.
        """
        return True

    def _predict(self, x):
        """
        Predicts the output of the model.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        y_pred: Any
            The predicted output.
        """
        predictions = self.model.predict(x)
        if isinstance(predictions, tuple) and predictions[0].shape == x.shape:
            return self.process_keras_predictions(predictions[1])
        return self.process_keras_predictions(predictions)

    def _predict_proba(self, x):
        """
        Predicts the output of the model.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        y_pred: Any
            The predicted output.
        """
        predictions = self.model.predict(x)
        if isinstance(predictions, tuple) and predictions[0].shape == x.shape:
            preds = predictions[1]
        else:
            preds = predictions

        if preds.shape[1] != 1:
            return np.expand_dims(preds, axis=1)
        return preds


@class_register
class AutoEncoderMLPRegressor(KerasModel, RegressorMixin):
    """
    An autoencoder followed by an MLP regressor.
    """
    name = 'AutoEncoderMLPRegressor'
    model = AutoEncoderMLP
    num_layers = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    latent_dim = ModelParameter(
        default=64, tunable=True, space=Categorical(64, 32, 128, 256, 512))
    first_hidden_dense_units = ModelParameter(
        default=512, tunable=True, space=Categorical(512, 1024, 256, 128, 64))
    num_layers_class = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='linear', tunable=False)
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default=['mse', 'mse'], tunable=False)
    # if encoder and mlp metric is the same pass only one metric
    metrics = ModelParameter(default=['mse'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'auto_encoder_mlp_regressor/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.REGRESSION]

    def _predict(self, x):
        """
        Predicts the output of the model.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        y_pred: Any
            The predicted output.
        """
        predictions = self.model.predict(x)
        if isinstance(predictions, tuple) and predictions[0].shape == x.shape:
            return predictions[1]
        return predictions
