from typing import List, Union

import tensorflow as tf
from omnia.generics.model.keras_models import KerasModel
from omnia.generics.model import RegressorMixin, ClassifierMixin, MultiOutputMixin
from omnia.generics.parameter import ModelParameter
from omnia.generics.parameter.space import Categorical, Bool
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class ConvRNNModel(tf.keras.Model):
    """
    ConvRNNModel is a class that represents a model combining CNN and RNN layers.
    """

    def __init__(self, n_tasks: int = 1, rnn_type: str = 'LSTM', bidirectional: bool = False, num_conv_layers: int = 3,
                 first_filter_size: int = 128, kernel_size: int = 3, stride: int = 1,
                 padding: str = 'same', pool_size: int = 2, num_lstm_layers: int = 3,
                 lstm_hidden_dim: int = 32, num_dense_layers: int = 3,
                 first_dense_units: List[int] = 32, n_classes: Union[List[int], int] = 1, drop: float = 0.3,
                 activation: str = "relu", last_layer_activation: Union[List[str], str] = "sigmoid",
                 loss: Union[List[str], str] = 'binary_crossentropy', **kwargs):
        """
        Initializes an instance of the ConvRNNModel class.

        Parameters:
        - n_tasks (int, optional):
            The number of output units. Defaults to 1.
        - rnn_type (str, optional):
            Type of RNN layer to use. Can be 'LSTM', 'GRU', or 'SimpleRNN'. Defaults to 'LSTM'.
        - bidirectional (bool, optional):
            Whether to use bidirectional RNN layers. Defaults to False.
        - num_conv_layers: int, optional (default: 3)
            The number of convolutional layers in the model.
        - num_filters: List[int], optional (default: [128,64, 32])
            The number of filters for each convolutional layer.
        - kernel_sizes: List[int], optional (default: [3, 3,3])
            The size of the kernel for each convolutional layer.
        - stride: int, optional (default: 1)
            The stride of the convolutional layers.
        - padding: str, optional (default: 'same')
            The padding type for the convolutional layers.
            Should be one of 'valid', 'same', or 'causal'.
        - pool_sizes: List[int], optional (default: [2, 2,2])
            The size of the pooling windows for each convolutional layer.
        - num_lstm_layers: int, optional (default: 3)
            The number of LSTM layers in the model.
        - lstm_hidden_dim: List[int], optional (default: [32, 32,32])
            The number of hidden units for each LSTM layer.
        - num_dense_layers: int, optional (default: 3)
            The number of dense layers in the model.
        - neurons_dense: List[int], optional (default: [32, 16,16])
            The number of neurons for each dense layer.
        - n_classes: list, optional (default: [1])
            The dimensionality of the output.
        - drop: float, optional (default: 0.3)
            The dropout rate.
        -activation (str, optional):
            The activation function. Defaults to 'relu'.
        -last_layers_activations (list, optional):
            The activation function list of the last layers. Defaults to ['sigmoid'].
        -loss (str, optional):
            The loss function list. Defaults to ['binary_crossentropy'].
        """
        super(ConvRNNModel, self).__init__()
        self.n_tasks = n_tasks
        self.rnn_type = rnn_type
        self.bidirectional = bidirectional
        self.num_conv_layers = num_conv_layers
        self.first_filter_size = first_filter_size
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.pool_size = pool_size
        self.num_lstm_layers = num_lstm_layers
        self.lstm_hidden_dim = lstm_hidden_dim
        self.num_dense_layers = num_dense_layers
        self.first_dense_units = first_dense_units
        self.n_classes = n_classes if isinstance(
            n_classes, list) else [n_classes] * n_tasks
        self.drop = drop
        self.activation = activation
        self.last_layer_activation = last_layer_activation if isinstance(
            last_layer_activation, list) else [last_layer_activation] * n_tasks
        self.loss = loss if isinstance(loss, list) else [loss] * n_tasks
        self.input_dim = 1024  # dummy input dimension

        # Reshape layer
        self.reshape_layer = tf.keras.layers.Reshape((self.input_dim, 1))

        # CNN layers
        conv_layers = []
        filter_size = self.first_filter_size
        for i in range(self.num_conv_layers):
            conv_layers.append(tf.keras.layers.Conv1D(filters=filter_size, kernel_size=self.kernel_size,
                                                      strides=stride, padding=padding, activation=self.activation))
            conv_layers.append(tf.keras.layers.BatchNormalization())
            conv_layers.append(tf.keras.layers.MaxPooling1D(
                pool_size=self.pool_size, padding=padding))
            conv_layers.append(tf.keras.layers.Dropout(self.drop))
            new_filter_size = filter_size // 2
            filter_size = max(new_filter_size, 1)

        self.conv = tf.keras.Sequential(conv_layers)

        # RNN layers
        rnn_layers = []
        layer_type = {
            'LSTM': tf.keras.layers.LSTM,
            'GRU': tf.keras.layers.GRU,
            'SimpleRNN': tf.keras.layers.SimpleRNN
        }
        for i in range(self.num_lstm_layers):
            if self.rnn_type not in layer_type:
                raise ValueError(
                    "Invalid RNN type. Supported types are 'LSTM', 'GRU', and 'SimpleRNN'.")
            rnn_layer = layer_type[self.rnn_type](self.lstm_hidden_dim,
                                                  return_sequences=(
                                                      i != self.num_lstm_layers - 1),
                                                  activation=self.activation)
            if bidirectional:
                rnn_layer = tf.keras.layers.Bidirectional(rnn_layer)

            rnn_layers.append(rnn_layer)
            rnn_layers.append(tf.keras.layers.Dropout(self.drop))

        self.rnn = tf.keras.Sequential(rnn_layers)

        # Add a Flatten layer to ensure the output is a 2D tensor
        self.flatten = tf.keras.layers.Flatten()

        # Dense layers
        self.dense_layers = []
        for i, last_activation in enumerate(self.last_layer_activation):
            dense_units = self.first_dense_units
            task_layers = []
            for _ in range(self.num_dense_layers):
                task_layers.append(tf.keras.layers.Dense(
                    dense_units, activation=self.activation))
                task_layers.append(tf.keras.layers.Dropout(self.drop))
                new_dense_units = dense_units // 2
                dense_units = max(new_dense_units, 1)

            output_size = 1 if self.n_classes[i] == 2 else self.n_classes[i]
            task_layers.append(tf.keras.layers.Dense(
                output_size, activation=last_activation))
            self.dense_layers.append(tf.keras.Sequential(task_layers))

    def call(self, inputs):
        """
        Forward pass of the ConvLSTMModel.

        Args:
            inputs (tf.Tensor):
                The input data.

        Returns:
            tf.Tensor:
                The output of the model.
        """
        if self.reshape_layer.target_shape != (inputs.shape[1], inputs.shape[2]):
            self.reshape_layer.target_shape = (inputs.shape[1], inputs.shape[2])

        x = self.reshape_layer(inputs)
        x = self.conv(x)
        x = self.rnn(x)
        flat = self.flatten(x)

        if self.n_tasks > 1:
            out = [dense_layer(flat) for dense_layer in self.dense_layers]
            return out

        out = self.dense_layers[0](flat)
        return out

    def get_config(self):
        """
        Gets the configuration of the ConvLSTMModel.

        Returns:
            config (dict):
                A dictionary containing the configuration of the ConvLSTMModel.
        """
        config = super(ConvRNNModel, self).get_config()
        config.update({
            'n_tasks': self.n_tasks,
            'rnn_type': self.rnn_type,
            'bidirectional': self.bidirectional,
            'num_conv_layers': self.num_conv_layers,
            'first_filter_size': self.first_filter_size,
            'kernel_size': self.kernel_size,
            'stride': self.stride,
            'padding': self.padding,
            'pool_size': self.pool_size,
            'num_lstm_layers': self.num_lstm_layers,
            'lstm_hidden_dim': self.lstm_hidden_dim,
            'num_dense_layers': self.num_dense_layers,
            'first_dense_units': self.first_dense_units,
            'n_classes': self.n_classes,
            'drop': self.drop,
            'activation': self.activation,
            'last_layer_activation': self.last_layer_activation,
            'loss': self.loss,
        })
        return config

    def get_weights(self) -> List:
        """
        Gets the weights of the ConvLSTMModel.

        Returns:
            weights (list):
                A list containing the weights of the ConvLSTMModel.
                The list contains the weights of the convolutional, RNN, and dense layers.
        """
        weights = [self.conv.get_weights(), self.rnn.get_weights()]
        for dense in self.dense_layers:
            weights.append(dense.get_weights())
        return weights


@class_register
class ConvRNNModelClassifier(KerasModel, ClassifierMixin, MultiOutputMixin):
    """
    A hybrid model combining CNN and RNN layers for classification tasks.
    """
    name = 'ConvRNNModelClassifier'
    model = ConvRNNModel
    n_tasks = ModelParameter(default=1, tunable=False)
    rnn_type = ModelParameter(
        default='LSTM', tunable=True, space=Categorical('LSTM', 'GRU', 'SimpleRNN'))
    bidirectional = ModelParameter(default=False, tunable=True, space=Bool())
    num_conv_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    first_filter_size = ModelParameter(
        default=128, tunable=True, space=Categorical(128, 64, 32))
    kernel_size = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 5, 7))
    stride = ModelParameter(default=1, tunable=True,
                            space=Categorical(1, 2, 3))
    padding = ModelParameter(default='same', tunable=False)
    pool_size = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    num_lstm_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    lstm_hidden_dim = ModelParameter(
        default=32, tunable=True, space=Categorical(32, 16, 64, 128))
    num_dense_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    first_dense_units = ModelParameter(
        default=32, tunable=True, space=Categorical(32, 16, 64, 128))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='sigmoid', tunable=False)
    n_classes = ModelParameter(default=2, tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='binary_crossentropy', tunable=False)
    metrics = ModelParameter(default=['accuracy'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'conv_rnn_classifier/'
    _input_type = DataTag.MATRIX
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTILABEL, TaskTag.MULTITASK_BINARY,
                       TaskTag.MULTITASK_MULTICLASS, TaskTag.MULTITASK_MULTILABEL]

    def _can_predict_proba(self) -> bool:
        """
        Returns whether the model can predict probabilities.

        Returns
        -------
        bool
            True if the model can predict probabilities, False otherwise.
        """
        return True


@class_register
class ConvRNNModelRegressor(KerasModel, RegressorMixin, MultiOutputMixin):
    """
    A hybrid Convolutional Recurrent Neural Network (ConvRNN) model for regression tasks.
    """
    name = 'ConvRNNModelRegressor'
    model = ConvRNNModel
    n_tasks = ModelParameter(default=1, tunable=False)
    rnn_type = ModelParameter(
        default='LSTM', tunable=True, space=Categorical('LSTM', 'GRU', 'SimpleRNN'))
    bidirectional = ModelParameter(default=False, tunable=True, space=Bool())
    num_conv_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    first_filter_size = ModelParameter(
        default=128, tunable=True, space=Categorical(128, 64, 32))
    kernel_size = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 5, 7))
    stride = ModelParameter(default=1, tunable=True,
                            space=Categorical(1, 2, 3))
    padding = ModelParameter(default='same', tunable=False)
    pool_size = ModelParameter(
        default=2, tunable=True, space=Categorical(2, 3, 4))
    num_lstm_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    lstm_hidden_dim = ModelParameter(
        default=32, tunable=True, space=Categorical(32, 16, 64, 128))
    num_dense_layers = ModelParameter(
        default=3, tunable=True, space=Categorical(3, 2, 4))
    first_dense_units = ModelParameter(
        default=32, tunable=True, space=Categorical(32, 16, 64, 128))
    activation = ModelParameter(default='relu', tunable=False)
    last_layer_activation = ModelParameter(default='linear', tunable=False)
    drop = ModelParameter(default=0.3, tunable=True,
                          space=Categorical(0.3, 0.0, 0.1, 0.2, 0.4, 0.5))
    optimizer = ModelParameter(default='adam', tunable=False)
    loss = ModelParameter(default='mean_squared_error', tunable=False)
    metrics = ModelParameter(default=['mean_squared_error'], tunable=False)
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'conv_rnn_regressor/'
    _input_type = DataTag.MATRIX
    _estimator_type = [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]
