from autogluon.common.features.types import R_BOOL, R_INT, R_FLOAT, R_CATEGORY

from omnia.generics.validation import NumericalX, TextX


TAG_MODEL_DTYPE = {
    NumericalX: [R_BOOL, R_INT, R_FLOAT],
    TextX: [R_BOOL, R_CATEGORY],
}
