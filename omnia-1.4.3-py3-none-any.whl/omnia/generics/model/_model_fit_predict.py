from functools import wraps
from typing import Union, List

from autogluon.core.models import AbstractModel

from omnia.generics.array import np
from omnia.generics.dataframe import pd


def ag_kwargs(takes_x: bool = True, takes_y: bool = False):
    """
    Decorator to convert all arguments to autogluon keyword arguments.

    Parameters
    ----------
    takes_x : bool, optional
        Whether the decorated function takes an X argument.
    takes_y : bool, optional
        Whether the decorated function takes a y argument.

    Returns
    -------
    function
        Decorated function.
    """

    def outer_wrapper(func):

        @wraps(func)
        def wrapper(self, *args, **kwargs):
            x = None
            y = None

            if args:
                if takes_x and takes_y:
                    x = args[0]
                    y = args[1]
                elif takes_x:
                    x = args[0]
                elif takes_y:
                    y = args[0]

            if kwargs:
                if takes_x and takes_y:
                    x = kwargs.pop('x', kwargs.pop('X', x))
                    y = kwargs.pop('y', kwargs.pop('Y', y))
                elif takes_x:
                    x = kwargs.pop('x', kwargs.pop('X', x))
                elif takes_y:
                    y = kwargs.pop('y', kwargs.pop('Y', y))

            if takes_x:
                if x is None:
                    raise TypeError(
                        "missing 1 required positional argument: 'x'")
                else:
                    kwargs['X'] = x

            if takes_y:
                if y is None:
                    raise TypeError(
                        "missing 1 required positional argument: 'y'")
                else:
                    if isinstance(y, pd.DataFrame):
                        kwargs['y'] = y.iloc[:, 0].copy()
                    else:
                        kwargs['y'] = y

            return func(self, **kwargs)

        return wrapper

    return outer_wrapper


# TODO: try to convert the predict returns to be always a DataFrame? This might be a bit tricky.
class ModelFitPredictMixIn:

    @ag_kwargs(takes_x=True, takes_y=False)
    def preprocess(self: Union['ModelFitPredictMixIn', AbstractModel], *args, **kwargs) -> pd.DataFrame:
        """
        Method to preprocess the input data.
        This method takes the input data and transforms it to the internal representation usable by the model.

        This method is a wrapper for AutoGluon's preprocess method.
        In AutoGluon AbstractModel implementation, this method is called by the fit method.
        In a custom model implementation, this method will end up calling the _preprocess and _preprocess_data
        methods that will perform all the data conversions to transform x into model-ready format.

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to preprocess.

        Returns
        -------
        x : dataframe-like, shape (n_samples, n_features)
            The preprocessed input data.
        """
        return super(ModelFitPredictMixIn, self).preprocess(*args, **kwargs)

    @ag_kwargs(takes_x=True, takes_y=True)
    def fit(self: Union['ModelFitPredictMixIn', AbstractModel], *args, **kwargs) -> 'ModelFitPredictMixIn':
        """
        Method to fit the model with input data (x, y).
        This method takes the input data, calls preprocess to convert x into model-ready format and then fits the model.

        This method is a wrapper for AutoGluon's fit method.
        In AutoGluon AbstractModel implementation, this method is responsible for direct calls to preprocess
        and _fit methods.
        In a custom model implementation, this method will end up calling the _fit and _fit_data
        methods that will use the transformed x to fit the custom model and return it.
        A model attribute should be set in this method!

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to fit the model.

        y : dataframe-like, shape (n_samples, 1)
            The target to fit the model.

        Returns
        -------
        self : Union['ModelFitPredictMixIn', AbstractModel]
            The fitted model.
        """
        return super(ModelFitPredictMixIn, self).fit(*args, **kwargs)

    @ag_kwargs(takes_x=True, takes_y=False)
    def predict_proba(self: Union['ModelFitPredictMixIn', AbstractModel], *args, **kwargs) -> Union[List[float],
                                                                                                    np.array]:
        """
        Method to predict probabilities for input data (x).
        This method takes new data, calls preprocess to convert x into model-ready format and then predicts
        probabilities of y using the fitted model.

        This method is a wrapper for AutoGluon's predict_proba method.
        This method must only be reimplemented if the custom model misses a predict_proba method!

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to predict probabilities for.

        Returns
        -------
        y_pred : List[float] or np.array
            The predicted probabilities for each class.
        """
        return super(ModelFitPredictMixIn, self).predict_proba(*args, **kwargs)

    @ag_kwargs(takes_x=True, takes_y=False)
    def predict(self: Union['ModelFitPredictMixIn', AbstractModel], *args, **kwargs) -> Union[
        np.ndarray,
        pd.DataFrame,
        List[str],
        List[int],
        List[float]
    ]:
        """
        Method to predict for input data (x).
        This method takes new data, calls preprocess to convert x into model-ready format and then predicts
        y using the fitted model.

        This method is a wrapper for AutoGluon's predict method.
        This method must only be reimplemented if the custom model misses a predict method!

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to predict for.

        Returns
        -------
        y_pred : np.ndarray or pd.DataFrame or List[str] or List[int] or List[float]
            The predicted values for each sample.
        """
        predictions = super(ModelFitPredictMixIn,
                            self).predict(*args, **kwargs)
        if predictions.ndim == 1:
            predictions = np.expand_dims(predictions, axis=1)
        return predictions

    @ag_kwargs(takes_x=True, takes_y=True)
    def score(self: Union['ModelFitPredictMixIn', AbstractModel], *args, **kwargs) -> float:
        """
        Method to score the model on input data (x) and labels (y).
        This method takes new data, calls preprocess to convert x into model-ready format and then scores it.

        This method is a wrapper for AutoGluon's score method.
        This method must only be reimplemented if the custom model misses a score method!

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to score.

        y : dataframe-like, shape (n_samples, 1)
            The target to score the model.

        Returns
        -------
        score : Any
            The score.
        """
        return super(ModelFitPredictMixIn, self).score(*args, **kwargs)
