import json
import os
from typing import Any, List, Union

from joblib import dump, load

from omnia.generics import np
from omnia.generics.model import Model
from omnia.generics.utils.keywords import kwargs_only
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class ScikitLearnBaseModel(Model):
    """
    Base class for scikit-learn models.
    """
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.UNDEFINED]
    path = 'sklearn_model/'

    @kwargs_only(has_self=True)
    def __init__(self, **kwargs):
        """
        The model constructor.
        """
        super(ScikitLearnBaseModel, self).__init__(**kwargs)
        self.model = self.model(**kwargs)

    def _fit(self, x: Any, y: Any, x_val: Any = None, y_val: Any = None, **kwargs) -> 'ScikitLearnBaseModel':
        """
        Fit the model to the data.

        Parameters
        ----------
        x: Any
            The input data.
        y: Any
            The target data.
        x_val: Any
            The validation input data.
        y_val: Any
            The validation target data.
        kwargs: dict
            Additional fitting parameters.
        """
        self.model.fit(x, y, **kwargs)
        return self

    def _predict(self, x: Any) -> np.ndarray:
        """
        Make predictions using the model on the input data.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        np.ndarray
            The model predictions.
        """
        predictions = self.model.predict(x)
        # add dimension if 1D to make shape = (n_samples, n_tasks)
        if predictions.ndim == 1:
            predictions = np.expand_dims(predictions, axis=1)
        return predictions

    @staticmethod
    def _handle_predict_proba(pred: Union[np.ndarray, List[np.ndarray]]) -> np.ndarray:
        """
        Handle the predict_proba output.

        Parameters
        ----------
        pred: Union[np.ndarray, List[np.ndarray]]
            The predict_proba output.

        Returns
        -------
        np.ndarray
            The processed predict_proba output.
        """
        # this is needed to turn [1.] probability rows into [0, 1] rows and vice versa
        def transform_single_value_array(array):
            array = array.flatten()
            transformed = np.zeros((array.size, 2))
            transformed[array == 1, 1] = 1
            transformed[array == 0, 0] = 1
            return transformed

        if isinstance(pred, list):  # Multitask scenario
            transformed_preds = [
                transform_single_value_array(
                    array) if array.shape[1] == 1 else array
                for array in pred
            ]

            pred = np.stack(transformed_preds, axis=1)

        # handle binary tasks -> turn [x y] where x+y=1 into [y]
        if pred.shape[-1] == 2:
            if pred.ndim == 2:
                pred = pred[:, 1].reshape(-1, 1)
            else:
                pred = pred[:, :, 1]
        elif len(pred.shape) == 2:  # handle multiclass singletask tasks
            pred = np.expand_dims(pred, axis=1)
        return pred

    def _predict_proba(self, x: Any) -> np.ndarray:
        """
        Make probability predictions using the model on the input data.

        Parameters
        ----------
        x: Any
            The input data.

        Returns
        -------
        np.ndarray
            The model probability predictions.
        """
        predictions = self.model.predict_proba(x)
        return self._handle_predict_proba(predictions)

    def save(self, path: str = None) -> None:
        """
        Save the model to a directory.

        Parameters
        ----------
        path: str
            The path to save the model to.
        """
        try:
            path = self.path if path is None else path
            if not os.path.exists(path):
                os.makedirs(path)
            model_path = os.path.join(path, 'model.pkl')
            dump(self.model, model_path)
            state = {'path': path,
                     '_fitted': self._fitted}
            # save state
            state_path = os.path.join(path, 'state.json')
            with open(state_path, 'w') as file:
                json.dump(state, file)
        except Exception as e:
            raise ValueError(f'Error saving model: {e}')

    @classmethod
    def load(cls, path: str = None) -> 'ScikitLearnBaseModel':
        """
        Load a model from a directory.

        Parameters
        ----------
        path: str
            The path to load the model from.

        Returns
        -------
        ScikitLearnBaseModel
            The loaded model.
        """
        # load model
        if path is None:
            path = cls.path
        model_path = os.path.join(path, 'model.pkl')
        model = load(model_path)
        # state
        state_path = os.path.join(path, 'state.json')
        with open(state_path, 'r') as file:
            state = json.load(file)
        # load parameters
        values = model.get_params()
        instance = cls(**values)
        instance.model = model
        instance._fitted = state['_fitted']
        return instance
