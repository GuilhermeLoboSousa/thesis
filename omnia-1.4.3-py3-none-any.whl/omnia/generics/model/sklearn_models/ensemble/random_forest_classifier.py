from sklearn.ensemble import RandomForestClassifier as RandomForestClassifierSK

from omnia.generics.parameter import ModelParameter
from omnia.generics.validation.task_tag import TaskTag
from ...model import ClassifierMixin, MultiOutputMixin
from ..sk_model import ScikitLearnBaseModel
from omnia.generics.parameter.space import Int
from omnia.generics.setup.registry import class_register


@class_register
class RandomForestClassifier(ScikitLearnBaseModel, ClassifierMixin, MultiOutputMixin):
    """
    Random Forest Classifier model.

    Parameters
    ----------
    n_estimators: int, default=100
        The number of trees in the forest.
    criterion: str, default='gini'
        The function to measure the quality of a split.
    max_depth: int, default=None
        The maximum depth of the tree.
    min_samples_split: int, default=2
        The minimum number of samples required to split an internal node.
    min_samples_leaf: int, default=1
        The minimum number of samples required to be at a leaf node.
    min_weight_fraction_leaf: float, default=0.0
        The minimum weighted fraction of the sum total of weights (of all the input samples) required to be at a leaf node.
    max_features: int, float or {'auto', 'sqrt', 'log2'}, default='auto'
        The number of features to consider when looking for the best split.
    max_leaf_nodes: int, default=None
        Grow trees with max_leaf_nodes in best-first fashion.
    min_impurity_decrease: float, default=0.0
        A node will be split if this split induces a decrease of the impurity greater than or equal to this value.
    bootstrap: bool, default=True
        Whether bootstrap samples are used when building trees.
    oob_score: bool, default=False
        Whether to use out-of-bag samples to estimate the generalization accuracy.
    n_jobs: int, default=None
        The number of jobs to run in parallel.
    random_state: int, RandomState instance or None, default=None
        Controls the random seed given at each base learner at each boosting iteration.
    verbose: int, default=0
        Controls the verbosity when fitting and predicting.
    warm_start: bool, default=False
        When set to True, reuse the solution of the previous call to fit and add more estimators to the ensemble.
    class_weight: dict, list of dict or 'balanced', default=None
        Weights associated with classes in the form {class_label: weight}.
    ccp_alpha: non-negative float, default=0.0
        Complexity parameter used for Minimal Cost-Complexity Pruning.
    max_samples: int or float, default=None
        If bootstrap is True, the number of samples to draw from X to train each base estimator.
        If None (default), then draw X.shape[0] samples.
        If int, then draw max_samples samples.
        If float, then draw max_samples * X.shape[0] samples.
    monotonic_cst: array-like of int of shape (n_features), default=None
        Indicates the monotonicity constraint to enforce on each feature.
                1: monotonic increase
                0: no constraint
                -1: monotonic decrease
        If monotonic_cst is None, no constraints are applied.

        Monotonicity constraints are not supported for:
                multiclass classifications (i.e. when n_classes > 2),
                multioutput classifications (i.e. when n_outputs_ > 1),
                classifications trained on data with missing values.

        The constraints hold over the probability of the positive class.

    Attributes
    ----------
    name: str
        The name of the model.
    model: RandomForestClassifierSK
        The model itself.
    path: str
        The default path to save the model.
    tags: list
        The validation tags for the model.
    """
    name = 'RandomForestClassifier'
    model = RandomForestClassifierSK
    n_estimators = ModelParameter(default=100, tunable=True, space=Int(10, 1000, default=100))
    criterion = ModelParameter(default='gini', tunable=False)
    max_depth = ModelParameter(default=None, tunable=False)
    min_samples_split = ModelParameter(default=2, tunable=False)
    min_samples_leaf = ModelParameter(default=1, tunable=False)
    min_weight_fraction_leaf = ModelParameter(default=0.0, tunable=False)
    max_features = ModelParameter(default='auto', tunable=False)
    max_leaf_nodes = ModelParameter(default=None, tunable=False)
    min_impurity_decrease = ModelParameter(default=0.0, tunable=False)
    bootstrap = ModelParameter(default=True, tunable=False)
    oob_score = ModelParameter(default=False, tunable=False)
    n_jobs = ModelParameter(default=None, tunable=False)
    random_state = ModelParameter(default=None, tunable=False)
    verbose = ModelParameter(default=0, tunable=False)
    warm_start = ModelParameter(default=False, tunable=False)
    class_weight = ModelParameter(default=None, tunable=False)
    ccp_alpha = ModelParameter(default=0.0, tunable=False)
    max_samples = ModelParameter(default=None, tunable=False)
    monotonic_cst = ModelParameter(default=None, tunable=False)

    path = 'random_forest_classifier/'
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.MULTITASK_BINARY, TaskTag.MULTITASK_MULTICLASS]

    @property
    def _can_predict_proba(self) -> bool:
        """
        Returns True if the model can predict probabilities.
        As RandomForestClassifier can predict probabilities, this method returns True.

        Returns
        -------
        bool
            True.
        """
        return True
