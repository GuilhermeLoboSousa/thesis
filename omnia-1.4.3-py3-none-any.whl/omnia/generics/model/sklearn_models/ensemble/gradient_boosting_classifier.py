from omnia.generics.parameter.space import Real, Int
from sklearn.ensemble import GradientBoostingClassifier as GradientBoostingClassifierSK

from omnia.generics.parameter import ModelParameter
from omnia.generics.validation.task_tag import TaskTag
from ...model import ClassifierMixin
from ..sk_model import ScikitLearnBaseModel
from omnia.generics.setup.registry import class_register


@class_register
class GradientBoostingClassifier(ScikitLearnBaseModel, ClassifierMixin):
    """
    Gradient Boosting Classifier model.

    Parameters
    ----------
    loss: str, default='log_loss'
        The loss function to be optimized. 'log_loss' is the default.
    learning_rate: float, default=0.1
        The learning rate of the model.
    n_estimators: int, default=100
        The number of boosting stages to be run.
    subsample: float, default=1.0
        The fraction of samples to be used for fitting the individual base learners.
    criterion: str, default='friedman_mse'
        The function to measure the quality of a split.
    min_samples_split: int, default=2
        The minimum number of samples required to split an internal node.
    min_samples_leaf: int, default=1
        The minimum number of samples required to be at a leaf node.
    min_weight_fraction_leaf: float, default=0.0
        The minimum weighted fraction of the sum total of weights (of all the input samples) required to be at a leaf node.
    max_depth: int, default=3
        The maximum depth of the individual regression estimators.
    min_impurity_decrease: float, default=0.0
        A node will be split if this split induces a decrease of the impurity greater than or equal to this value.
    init: estimator, default=None
        An estimator object that is used to compute the initial predictions.
    random_state: int, RandomState instance or None, default=None
        Controls the random seed given at each base learner at each boosting iteration.
    max_features: int, float or {'auto', 'sqrt', 'log2'}, default=None
        The number of features to consider when looking for the best split.
    verbose: int, default=0
        Controls the verbosity when fitting and predicting.
    max_leaf_nodes: int, default=None
        Grow trees with max_leaf_nodes in best-first fashion.
    warm_start: bool, default=False
        When set to True, reuse the solution of the previous call to fit and add more estimators to the ensemble.
    validation_fraction: float, default=0.1
        The proportion of training data to set aside as validation set for early stopping.
    n_iter_no_change: int, default=None
        The number of iterations with no improvement to wait before stopping fitting.
    tol: float, default=1e-4
        The stopping criterion.
    ccp_alpha: non-negative float, default=0.0
        Complexity parameter used for Minimal Cost-Complexity Pruning.

    Attributes
    ----------
    name: str
        The name of the model.
    model: estimator
        The model itself.
    path: str
        The default path to save the model.
    tags: list
        The validation tags for the model.
    """
    name = 'GradientBoostingClassifier'
    model = GradientBoostingClassifierSK
    loss = ModelParameter(default='log_loss', tunable=False)
    learning_rate = ModelParameter(default=0.1, tunable=True, space=Real(0.01, 1, default=0.1))
    n_estimators = ModelParameter(default=100, tunable=True, space=Int(10, 1000, default=100))
    subsample = ModelParameter(default=1.0, tunable=False)
    criterion = ModelParameter(default='friedman_mse', tunable=False)
    min_samples_split = ModelParameter(default=2, tunable=False)
    min_samples_leaf = ModelParameter(default=1, tunable=False)
    min_weight_fraction_leaf = ModelParameter(default=0.0, tunable=False)
    max_depth = ModelParameter(default=3, tunable=True, space=Int(1, 10, default=3))
    min_impurity_decrease = ModelParameter(default=0.0, tunable=False)
    init = ModelParameter(default=None, tunable=False)
    random_state = ModelParameter(default=None, tunable=False)
    max_features = ModelParameter(default=None, tunable=False)
    verbose = ModelParameter(default=0, tunable=False)
    max_leaf_nodes = ModelParameter(default=None, tunable=False)
    warm_start = ModelParameter(default=False, tunable=False)
    validation_fraction = ModelParameter(default=0.1, tunable=False)
    n_iter_no_change = ModelParameter(default=None, tunable=False)
    tol = ModelParameter(default=1e-4, tunable=False)
    ccp_alpha = ModelParameter(default=0.0, tunable=False)

    path = 'gradient_boosting_classifier/'
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS]

    @property
    def _can_predict_proba(self) -> bool:
        """
        Returns True if the model can predict probabilities.
        As GradientBoostingClassifier can predict probabilities, this method returns True.

        Returns
        -------
        bool
            True.
        """
        return True
