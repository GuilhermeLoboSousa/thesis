from sklearn.linear_model import LinearRegression as LinearRegressionSK

from omnia.generics.parameter import ModelParameter
from omnia.generics.model.model import RegressorMixin
from omnia.generics.model.sklearn_models import ScikitLearnBaseModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.task_tag import TaskTag


@class_register
class LinearRegression(ScikitLearnBaseModel, RegressorMixin):
    """
    Linear Regression model.

    Parameters
    ----------
    fit_intercept: bool, default=True
        Whether to calculate the intercept for this model.
    copy_X: bool, default=True
        Whether to copy the input data.
    n_jobs: int, default=None
        The number of jobs to run in parallel.
    positive: bool, default=False
        Whether to enforce a positive coefficient constraint.

    Attributes
    ----------
    name: str
        The name of the model.
    model: object
        The model itself.
    path: str
        The default path to save the model.
    tags: list
        The validation tags for the model.
    """
    name = 'LinearRegression'
    model = LinearRegressionSK
    fit_intercept = ModelParameter(default=True, tunable=False)
    copy_X = ModelParameter(default=True, tunable=False)
    n_jobs = ModelParameter(default=None, tunable=False)
    positive = ModelParameter(default=False, tunable=False)

    path = 'linear_regression/'
    _estimator_type = [TaskTag.REGRESSION]

    @property
    def _can_predict_proba(self) -> bool:
        """
        Returns False if the model cannot predict probabilities.
        As LinearRegression cannot predict probabilities, this method returns False.

        Returns
        -------
        bool
            False.
        """
        return False
