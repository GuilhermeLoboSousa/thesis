from sklearn.linear_model import LogisticRegression as LogisticRegressionSK

from omnia.generics.parameter import ModelParameter
from omnia.generics.model.model import ClassifierMixin
from omnia.generics.model.sklearn_models import ScikitLearnBaseModel
from omnia.generics.parameter.space import Categorical, Real
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.task_tag import TaskTag


@class_register
class LogisticRegression(ScikitLearnBaseModel, ClassifierMixin):
    """
    Logistic Regression model.

    Parameters
    ----------
    penalty: str, default=None
        The norm used in the penalization.
    dual: bool, default=False
        Dual or primal formulation.
    tol: float, default=1e-6
        Tolerance for stopping criteria.
    C: float, default=1.0
        Inverse of regularization strength.
    fit_intercept: bool, default=True
        Whether to calculate the intercept for this model.
    intercept_scaling: float, default=1
        When self.fit_intercept is True, instance vector x becomes [x, self.intercept_scaling].
    class_weight: dict or 'balanced', default=None
        Weights associated with classes in the form {class_label: weight}.
    random_state: int, RandomState instance or None, default=None
        Controls the random seed given at each base learner at each boosting iteration.
    solver: str, default='lbfgs'
        The algorithm to use in the optimization problem.
    max_iter: int, default=100
        The maximum number of iterations taken for the solvers to converge.
    multi_class: str, default='auto'
        If the option chosen is 'ovr', then a binary problem is fit for each label.
        If the option chosen is 'multinomial', then the loss minimised is the multinomial loss fit across the entire probability distribution.
    verbose: int, default=0
        Controls the verbosity when fitting and predicting.
    warm_start: bool, default=False
        When set to True, reuse the solution of the previous call to fit and add more estimators to the ensemble.
    n_jobs: int, default=None
        The number of jobs to run in parallel.
    l1_ratio: float, default=None
        The Elastic-Net mixing parameter, with 0 <= l1_ratio <= 1.
        l1_ratio=0 corresponds to L2 penalty, l1_ratio=1 to L1.
        Only used if penalty='elasticnet'.

    Attributes
    ----------
    name: str
        The name of the model.
    model: object
        The model itself.
    path: str
        The default path to save the model.
    tags: list
        The validation tags for the model.
    """
    name = 'LogisticRegression'
    model = LogisticRegressionSK
    penalty = ModelParameter(default=None, tunable=True, space=Categorical(None, 'l2'))
    dual = ModelParameter(default=False, tunable=False)
    tol = ModelParameter(default=1e-6, tunable=True, space=Real(1e-6, 1e-2))
    C = ModelParameter(default=1.0, tunable=True, space=Categorical(1.0, 0.1, 0.01, 0.001, 10, 100, 1000))
    fit_intercept = ModelParameter(default=True, tunable=False)
    intercept_scaling = ModelParameter(default=1, tunable=False)
    class_weight = ModelParameter(default=None, tunable=False)
    random_state = ModelParameter(default=None, tunable=False)
    solver = ModelParameter(default='lbfgs', tunable=False)
    max_iter = ModelParameter(default=100, tunable=False)
    multi_class = ModelParameter(default='auto', tunable=False)
    verbose = ModelParameter(default=0, tunable=False)
    warm_start = ModelParameter(default=False, tunable=False)
    n_jobs = ModelParameter(default=None, tunable=False)
    l1_ratio = ModelParameter(default=None, tunable=False)

    path = 'logistic_regression/'
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS]

    @property
    def _can_predict_proba(self) -> bool:
        """
        Returns True if the model can predict probabilities.
        As LogisticRegression can predict probabilities, this method returns True.

        Returns
        -------
        bool
            True.
        """
        return True
