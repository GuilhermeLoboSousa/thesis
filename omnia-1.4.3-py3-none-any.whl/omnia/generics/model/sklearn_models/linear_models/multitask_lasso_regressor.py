from sklearn.linear_model import MultiTaskLasso

from omnia.generics.parameter import ModelParameter
from omnia.generics.model.model import MultiOutputMixin, RegressorMixin
from omnia.generics.model.sklearn_models import ScikitLearnBaseModel
from omnia.generics.parameter.space import Categorical
from omnia.generics.setup.registry import class_register


@class_register
class MultiTaskLassoRegressor(ScikitLearnBaseModel, MultiOutputMixin, RegressorMixin):
    name = 'MultiTaskLassoRegressor'
    model = MultiTaskLasso
    alpha = ModelParameter(default=1.0, tunable=True, space=Categorical(1.0, 0.0, 0.1, 0.01, 0.001, 10, 100, 1000))
    fit_intercept = ModelParameter(default=True, tunable=False)
    copy_X = ModelParameter(default=True, tunable=False)
    max_iter = ModelParameter(default=1000, tunable=False)
    tol = ModelParameter(default=1e-4, tunable=False)
    warm_start = ModelParameter(default=False, tunable=False)
    random_state = ModelParameter(default=None, tunable=False)
    selection = ModelParameter(default='cyclic', tunable=False)

    path = 'multi_task_lasso_regressor/'

    tags = []  # add omnia validation tags when validation is operational
