from typing import Any
from omnia.generics.model.keras_models.keras_models import KerasModel
from omnia.generics.model.torch_models.torch_model import TorchModel
from keras.callbacks import EarlyStopping as EarlyStoppingKeras
from pytorch_lightning.callbacks import EarlyStopping as EarlyStoppingLightning


class EarlyStopping:
    """
    Early stopping callback interface class that will get either the Keras early stopping or the PyTorch Lightning early stopping depending on the model.
    """

    def __new__(cls, model: Any, **kwargs) -> Any:
        """
        Return the appropriate early stopping callback based on the model type.

        Parameters
        ----------
        model: Any
            The model to get the early stopping callback for.
        kwargs: dict
            Additional arguments for the early stopping callback.
        """
        if issubclass(model, KerasModel):
            return EarlyStoppingKeras(**kwargs)
        elif issubclass(model, TorchModel):
            return EarlyStoppingLightning(**kwargs)
        else:
            raise ValueError("Model type not supported for early stopping.")
