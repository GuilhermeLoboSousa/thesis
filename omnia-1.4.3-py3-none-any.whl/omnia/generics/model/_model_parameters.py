import inspect
from typing import Union, Type, List, Dict, Tuple, Any

from autogluon.core.models import AbstractModel

from omnia.generics.parameter import Parameter
from ._utils import TAG_MODEL_DTYPE
from omnia.generics.utils.keywords import kwargs_only
from omnia.generics.io import write_json, read_json


class ModelParametersMixIn:
    name = None

    @kwargs_only(has_self=True)
    def __init__(self, **kwargs):
        """
        It allows to initialize the model with its parameters.

        Parameters
        ----------
        kwargs
            The parameters of the model.
        """
        self._init_parameters = {}

        descriptors = self._get_parameters()
        for name, descriptor in descriptors.items():
            if name in kwargs:
                self._init_parameters[name] = kwargs.pop(name)

        super(ModelParametersMixIn, self).__init__(**kwargs)

    @classmethod
    def _get_parameters(cls) -> Dict[str, Parameter]:
        """
        Method to return the parameters descriptors of the model.

        Returns
        -------
        parameters_descriptors : dict
            The parameters descriptors for the estimator.
        """
        return {name: descriptor
                for name, descriptor in inspect.getmembers(cls)
                if isinstance(descriptor, Parameter)}

    # TODO: this is not tested yet but it makes a model even more compatible with our Estimator's interface
    @property
    def parameters(self) -> Dict[str, Any]:
        """
        Returns
        -------
        parameters : dict
            The parameters of the model.
        """
        descriptors = self._get_parameters()
        return {name: getattr(self, name) for name in descriptors}

    def to_dict(self):
        """
        Saves an estimator object into a dict.

        NOTE!!!
        This method saves all estimators, models and predictors into a dict together
        with the corresponding parameters. It does not save, however, estimated parameters and model weights
        This dict object can be used to recreate a new fresh estimator or model with the same configuration.
        To save these objects, one can use the `to_pickle` or `save` methods.

        Returns
        -------
        estimator : dict
            The estimator object as a dict.
        """
        parameters = self._init_parameters

        state = {'name': self.name, 'parameters': parameters}
        return state

    @classmethod
    def from_dict(cls, state: dict):
        """
        It loads a new fresh estimator, model or predictor object from a dict.

        Parameters
        ----------
        state : dict
            The estimator object as a dict.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        parameters = state['parameters']
        obj = cls(**parameters)
        return obj

    def to_json(self, file_path: str):
        """
        Saves an estimator object into a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        success : bool
            True if the operation was successful, False otherwise.
        """
        state = self.to_dict()
        return write_json(file_path, state)

    @classmethod
    def from_json(cls, file_path: str):
        """
        Loads an estimator object from a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        state = read_json(file_path)
        return cls.from_dict(state)


class AutoGluonModelParametersMixIn(ModelParametersMixIn):

    # ------------------------------------------------------------------------------------------------------------------
    # AutoGluon AbstractModel Interface - Methods to handle model parameters
    # ------------------------------------------------------------------------------------------------------------------
    def _get_default_params(self: Union['AutoGluonModelParametersMixIn',
                                        AbstractModel]) -> Dict[str, Union[int, float, str, bool, Tuple, List]]:
        """
        Method to get the default parameters of the model.
        This method will be used in by the _set_default_params to set the default parameters of the model,
        as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel

        It will list all parameters (python descriptors) defined at the class level,
        and will retrieve the default values for each of them based on the AutoGluon search space object.

        Returns
        -------
        params : dict
            The default parameters of the model to be set in _set_default_params.
        """
        return {name: descriptor.get_default(self.problem_type)
                for name, descriptor in inspect.getmembers(self.__class__)
                if isinstance(descriptor, Parameter)}

    def _set_default_params(self: Union['AutoGluonModelParametersMixIn', AbstractModel]):
        """
        Method to set the default parameters of the model.
        This method calls _get_default_params to get the default parameters of the model,
        as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel

        After retrieving all default parameters, it will set them in the model
        using AutoGluon's _set_default_param_value.

        Parameters
        ----------

        Returns
        -------
        """
        params = {}

        for name, descriptor in inspect.getmembers(self.__class__):
            if isinstance(descriptor, Parameter):

                if name in self._init_parameters:
                    params[descriptor.parameter_name()] = self._init_parameters[name]

                else:
                    params[descriptor.parameter_name()] = descriptor.get_default(self.problem_type)

        for param, val in params.items():
            self._set_default_param_value(param, val)

    def _get_default_auxiliary_params(self: Union['AutoGluonModelParametersMixIn', AbstractModel]) -> Dict[str,
                                                                                                  Union[int, float,
                                                                                                        str, bool,
                                                                                                        Tuple, List]]:
        """
        Method to get the default auxiliary parameters of the model.
        This method retrieves various model-agnostic parameters such as maximum memory usage
        and valid input column data types.
        This method will be used in the _set_default_auxiliary_params method to set the auxiliary parameters,
        as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel

        Most of the magic happens in AutoGluon's _set_default_auxiliary_params method.
        As for our implementation, we just set up the allowed data types for the input columns based on the tags.

        Parameters
        ----------
        Returns
        -------
        params : dict
            The default auxiliary parameters of the model to be set in _set_default_auxiliary_params.
        """
        default_auxiliary_params = super(AutoGluonModelParametersMixIn, self)._get_default_auxiliary_params()

        valid_dtypes = [TAG_MODEL_DTYPE[tag] for tag in self.validation_property.input_tag.get_all_operand_classes()
                        if tag in TAG_MODEL_DTYPE]
        valid_dtypes = list({tag for tags in valid_dtypes for tag in tags})
        extra_auxiliary_params = dict(valid_raw_types=valid_dtypes)

        default_auxiliary_params.update(extra_auxiliary_params)
        return default_auxiliary_params

    def _set_default_auxiliary_params(self: Union['AutoGluonModelParametersMixIn', AbstractModel]):
        """
        Method to set the default auxiliary parameters of the model.
        This method calls the _get_default_auxiliary_params to retrieve model agnostic parameters,
        as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel

        All work is done in the _set_default_auxiliary_params method of AutoGluon's AbstractModel class.

        Parameters
        ----------
        Returns
        -------
        """
        return super(AutoGluonModelParametersMixIn, self)._set_default_auxiliary_params()

    @classmethod
    def get_hyperparameters(cls: Union[Type['AutoGluonModelParametersMixIn'], Type[AbstractModel]],
                            default: bool = True,
                            problem_type: str = None,
                            use_alias=False) -> Dict:
        """
        Method to generate the AutoGluon hyperparameter-model dictionary.
        It is useful to create the hyperparameter dictionary that will be used by AutoGluon to initialize
        the custom implemented model. AutoGluon will also use the hyperparameter dictionary to optimize the model
        parameters.
        This method will return a dictionary with the following keys:
            - 'name': the name of the model
            - 'params': the default parameters or search space of the model

        Parameters
        ----------
        default : bool, optional
            If True, the default parameters will be returned.
            If False, the search space will be returned.
            Default is False.

        problem_type : str, optional
            The problem type of the model.
            Default is None.

        use_alias : bool, optional
            If True, the alias of the model will be returned.
            If False, the name of the model will be returned.

        Returns
        -------
        model : dict
            The AutoGluon model version as a hyperparameter dictionary.
        """
        if use_alias:
            defaults = {descriptor.parameter_name(): descriptor.get_default(problem_type)
                        for _, descriptor in inspect.getmembers(cls)
                        if isinstance(descriptor, Parameter)}
        else:
            defaults = {name: descriptor.get_default(problem_type)
                        for name, descriptor in inspect.getmembers(cls)
                        if isinstance(descriptor, Parameter)}

        if default:
            return defaults

        if use_alias:
            search_space = {descriptor.parameter_name(): descriptor.get_default_space(problem_type)
                            for _, descriptor in inspect.getmembers(cls)
                            if isinstance(descriptor, Parameter) and descriptor.get_default_space(problem_type) is not None}
        else:
            search_space = {name: descriptor.get_default_space(problem_type)
                            for name, descriptor in inspect.getmembers(cls)
                            if isinstance(descriptor, Parameter) and descriptor.get_default_space(problem_type) is not None}

        defaults.update(search_space)
        return defaults

    def to_dict(self):
        """
        Saves an estimator object into a dict.

        NOTE!!!
        This method saves all estimators, models and predictors into a dict together
        with the corresponding parameters. It does not save, however, estimated parameters and model weights
        This dict object can be used to recreate a new fresh estimator or model with the same configuration.
        To save these objects, one can use the `to_pickle` or `save` methods.

        Returns
        -------
        estimator : dict
            The estimator object as a dict.
        """
        parameters = self._get_default_params()
        parameters.update(self._init_parameters)

        state = {'name': self.name, 'parameters': parameters}
        return state
