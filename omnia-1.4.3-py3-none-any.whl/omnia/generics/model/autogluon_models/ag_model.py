from abc import abstractmethod
from typing import Any, Union, Callable, List, Dict

from autogluon.core.models import AbstractModel as AutoGluonAbstractModel
from autogluon.features import LabelEncoderFeatureGenerator

from omnia.generics.dataframe import pd
from omnia.generics.evaluate.evaluate import Evaluator
from omnia.generics.model._model_fit_predict import ModelFitPredictMixIn
from omnia.generics.model._model_parameters import AutoGluonModelParametersMixIn
from omnia.generics.model._model_validate import ModelValidateMixIn
from omnia.generics.utils.keywords import kwargs_only
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class AutoGluonBaseModel(ModelFitPredictMixIn, AutoGluonModelParametersMixIn, ModelValidateMixIn,
                         AutoGluonAbstractModel):
    """
    Model base class.
    This class is derived from the `autogluon.core.models.AbstractModel` class.
    Thus, it contains all the batteries to initialize, fit, and predict a model properly using the AutoGluon engine.
    In addition, all model parameters can be optimized using also the AutoGluon engine.

    Minor modifications were added by the ModelFitPredictMixIn class.
    ModelParametersMixIn class provides a straightforward API (using Parameter python descriptor)
    to set and get model parameters. This mix-in class can then retrieve all these model parameters
    and pass them to the AutoGluon implementation.

    It provides the following methods:
        - get/set_model_parameters
        - tags
        - _preprocess
        - _fit
        - preprocess
        - fit
        - predict
        - predict_proba
        - score

    Parameters
    ----------
    Parameters are inherited from AbstractModel and added in custom implementations.

    Attributes
    ----------
    Attributes are inherited from AbstractModel and added in custom implementations.

    Methods
    -------
    Methods are inherited from AbstractModel and added in custom implementations.
    """

    # ------------------------------------------------------------------------------------------------------------------
    # AutoGluon's AbstractModel implementation
    # ------------------------------------------------------------------------------------------------------------------
    @kwargs_only(has_self=True)
    def __init__(self, **kwargs):
        """
        The model constructor.
        The model constructor should call the super constructor to perform AutoGluon's AbstractModel initialization of
        hyperparameters.
        For more information, see:
            - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
        """
        super(AutoGluonBaseModel, self).__init__(**kwargs)
        self._feature_generator = None
        self._fitted = False
        self._input_type = DataTag.TABULAR
        self._estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.REGRESSION, TaskTag.MULTILABEL]

    def _preprocess(self, X: pd.DataFrame, is_train: bool = False, **kwargs) -> pd.DataFrame:
        """
        Method to preprocess the input data.
        This method takes the input data and transforms it to the internal representation usable by the model.
        This method is implemented as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel.

        In addition to the AutoGluon's suggestion of preprocessing, this method will call custom processing of data.
        In detail, this method will call _preprocessing_data to transform the input data into a format usable by the
        model.

        Parameters
        ----------
        X : pd.DataFrame
            The input data.
        is_train : bool, optional
            Whether the data is used for training or not.
            This is used to determine whether the data should be transformed or not.
            The default is False.
        kwargs : dict
            Additional keyword arguments.

        Returns
        -------
        X : dataframe-like, shape (n_samples, n_features)
            The preprocessed input data.
        """
        X = super(AutoGluonBaseModel, self)._preprocess(X=X, **kwargs)

        if is_train:
            self._feature_generator = LabelEncoderFeatureGenerator(verbosity=0)
            self._feature_generator.fit(X=X)

        if self._feature_generator.features_in:
            X = X.copy()
            X[self._feature_generator.features_in] = self._feature_generator.transform(X=X)

        return self._preprocess_data(x=X)

    def _fit(self, X: pd.DataFrame, y: pd.DataFrame, X_val: pd.DataFrame = None, y_val: pd.DataFrame = None, **kwargs):
        """
        Abstract method to fit the model with input data (x, y).
        This method is implemented as suggested in AutoGluon tutorial:
            - Adding a custom model to AutoGluon:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html
            - Example of a custom RandomForest model:
                - https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#implementing-a-custom-model
            - Example of the AutoGluon RandomForest model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/rf/rf_model.html#RFModel
            - Example of the AutoGluon LightGBM model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/lgb/lgb_model.html#LGBModel
            - Example of the AutoGluon CatBoost model implementation:
                - https://auto.gluon.ai/stable/_modules/autogluon/tabular/models/catboost/catboost_model.html#CatBoostModel

        In addition to the AutoGluon's suggestion of _fit, this method will call custom fit method.
        In detail, this method will call _fit_data to fit transformed x t a custom model.

        Parameters
        ----------
        X : dataframe-like, shape (n_samples, n_features)
            The data to fit.
        y : dataframe-like, shape (n_samples,)
            The target variable to try to predict.
        X_val : dataframe-like, shape (n_samples, n_features), optional
            The validation data to use during fit.
            The default is None.
        y_val : dataframe-like, shape (n_samples,), optional
            The validation target variable to try to predict.
            The default is None.
        kwargs
            Additional AutoGluon arguments.

        Returns
        -------
        self : object
            The fitted model.
        """
        X = self.preprocess(x=X, is_train=True)
        self._fit_data(x=X, y=y, x_val=X_val, y_val=y_val)
        self._fitted = True

    @abstractmethod
    def _preprocess_data(self, x: pd.DataFrame) -> pd.DataFrame:
        """
        Abstract method to transform the input data into a format usable by the model.
        This method should be implemented in the child class.
        It will be called by the _preprocess method.

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The input data.

        Returns
        -------
        x : dataframe-like, shape (n_samples, n_features)
            The transformed input data.
        """
        ...

    @abstractmethod
    def _fit_data(self, x: pd.DataFrame, y: pd.DataFrame, x_val: pd.DataFrame = None, y_val: pd.DataFrame = None):
        """
        Abstract method to fit the model with input data (x, y).
        This method should be implemented in the child class.
        It will be called by the _fit method.

        Parameters
        ----------
        x : dataframe-like, shape (n_samples, n_features)
            The data to fit.
        y : dataframe-like, shape (n_samples,)
            The target variable to try to predict.
        x_val : dataframe-like, shape (n_samples, n_features), optional
            The validation data to use during fit.
            The default is None.
        y_val : dataframe-like, shape (n_samples,), optional
            The validation target variable to try to predict.
            The default is None.

        Returns
        -------
        self : object
            The fitted model.
        """
        ...

    @property
    def fitted(self) -> bool:
        """
        Check if the model is fitted.

        Returns
        -------
        bool
            Whether the model is fitted or not.
        """
        return self._fitted

    def evaluate(self, x: Any, y: Any, metrics: Union[str, Callable, List[Union[str, Callable]]],
                 per_task_metrics: bool = False, w: Any = None, **kwargs) -> Dict[str, float]:
        """
        Evaluate the model.

        Parameters
        ----------
        x: Any
            The input data.
        y: Any
            The target variable.
        metrics: Union[str, Callable, List[Union[str, Callable]]]
            The metrics to use for evaluation.
        per_task_metrics: bool
            If true, return computed metric for each task on multitask dataset.
        w: Any
            The weights of each sample for evaluation.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Dict[str, float]
            The evaluation scores.
        """
        evaluator = Evaluator(self, x, y, w)
        return evaluator.compute_model_performance(metrics=metrics, per_task_metrics=per_task_metrics, **kwargs)

    @property
    def input_type(self) -> Union[DataTag, List[DataTag]]:
        """
        Get the input data type.

        Returns
        -------
        DataTag
            The input data type.
        """
        return self._input_type

    @property
    def estimator_type(self) -> Union[TaskTag, List[TaskTag]]:
        """
        Get the estimator type.

        Returns
        -------
        TaskTag
            The estimator type.
        """
        return self._estimator_type


class AutoGluonModel(ModelFitPredictMixIn, AutoGluonModelParametersMixIn, ModelValidateMixIn):
    """
    Base class for AutoGluon models.
    This class is a mixin to be added to each AutoGluon concrete model.

    It provides the following methods:
    - get/set_model_parameters
    - tags
    - remaining parameters, attributes, and methods are implemented in the parent classes at AutoGluon.

    Parameters
    ----------
    Parameters are inherited from AutoGluon's model

    Attributes
    ----------
    Attributes are inherited from AutoGluon's model

    Methods
    -------
    Methods are inherited from AutoGluon's model
    """
    _input_type = DataTag.TABULAR

    def evaluate(self, x: Any, y: Any, metrics: Union[str, Callable, List[Union[str, Callable]]],
                 per_task_metrics: bool = False, w: Any = None, **kwargs) -> Dict[str, float]:
        """
        Evaluate the model.

        Parameters
        ----------
        x: Any
            The input data.
        y: Any
            The target variable.
        metrics: Union[str, Callable, List[Union[str, Callable]]]
            The metrics to use for evaluation.
        per_task_metrics: bool
            If true, return computed metric for each task on multitask dataset.
        w: Any
            The weights of each sample for evaluation.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Dict[str, float]
            The evaluation scores.
        """
        evaluator = Evaluator(self, x, y, w)
        return evaluator.compute_model_performance(metrics=metrics, per_task_metrics=per_task_metrics, **kwargs)

    @property
    def input_type(self) -> DataTag:
        """
        Get the input data type.

        Returns
        -------
        DataTag
            The input data type.
        """
        return self._input_type
