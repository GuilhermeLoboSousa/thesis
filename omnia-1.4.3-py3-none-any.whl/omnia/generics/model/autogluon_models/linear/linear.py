from autogluon.common.space import Real, Categorical
from autogluon.tabular.models import LinearModel as AGLinearModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class LinearModel(AutoGluonModel, AGLinearModel):
    """
    Class that represents a Linear model.

    Linear model (scikit-learn):
        - https://scikit-learn.org/stable/modules/classes.html#module-sklearn.linear_model

    Model backend differs depending on problem_type:

        'binary' & 'multiclass':
            - https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html

        'regression':
            - https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html#sklearn.linear_model.Ridge

    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models

    Parameters
    ----------
    c: float, default=1.0
        Inverse of regularization strength; must be a positive float.
        Like in support vector machines, smaller values specify stronger regularization.
        The optimal value depends on the dataset and the cost function.

    fit_intercept: bool, default=True
        Whether to calculate the intercept for this model.
        If set to false, no intercept will be used in calculations
        (e.g. data is expected to be already centered).

    vectorizer_dict_size: int, default=75000
        Size of the dictionary used to vectorize the text.
        If None, the dictionary will be generated from the training data.

    penalty: str, default='L2'
        The penalty to use in the optimization problem.
        It defaults to 'L2' which is the standard regularizer for linear SVM models.
        'L1' is also supported.

    handle_text: bool, default='ignore'
        Whether to handle text data.
        If 'ignore', the text data will be ignored.
        It also accepts 'only' and 'include'.

    solver: str, default='lbfgs'
        The solver to use for optimization.
        It defaults to 'lbfgs' which is a limited memory BFGS
        Other options include 'sag', 'saga', 'newton-cg', 'liblinear', 'sgd'.
        See https://scikit-learn.org/stable/modules/sgd.html for more information.

    random_state: int, default=0
        The seed of the pseudo random number generator to use when shuffling the data.
        If int, random_state is the seed used by the random number generator;

    proc_ngram_range: tuple, default=(1, 5)
        The range of n-values for n-grams to be used by the tokenizer.
        The lower bound is 1 and upper bound is 5 by default
        REQUIRED if handle_text is 'include'.

    proc_skew_threshold: float, default=0.99
        The threshold for the skew to be considered.
        If the skew is greater than this threshold, the data will be transformed.
        REQUIRED if handle_text is 'include'.

    proc_impute_strategy: str, default='median'
        The strategy to use for imputation.
        It defaults to 'median' which is the median of the column.
        Other options include 'mean', 'most_frequent', 'constant', 'most_recent'.
        REQUIRED if handle_text is 'include'.
    """
    name = 'LinearModel'

    c: float = ModelParameter(default=1.0, tunable=True, alias='C', space=Real(0.01, 100, default=1.0))
    fit_intercept: bool = ModelParameter(default=True, tunable=True, space=Categorical(True, False))
    vectorizer_dict_size: int = ModelParameter(default=75000, tunable=False)
    penalty: str = ModelParameter(default='L2', tunable=False)
    handle_text: str = ModelParameter(default='ignore', tunable=False)
    solver: str = ModelParameter(default='lbfgs', tunable=False,
                                 binary__default='lbfgs',
                                 multiclass__default='lbfgs',
                                 regression__default='auto')
    random_state: int = ModelParameter(default=0, tunable=False)
    proc_ngram_range: tuple = ModelParameter(default=(1, 5), tunable=False, alias='proc.ngram_range')
    proc_skew_threshold: float = ModelParameter(default=0.99, tunable=False, alias='proc.skew_threshold')
    proc_impute_strategy: str = ModelParameter(default='median', tunable=False, alias='proc.impute_strategy')

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))
