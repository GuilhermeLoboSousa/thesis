from autogluon.common.space import Int, Categorical, Real
from sklearn.svm import SVR, SVC

from omnia.generics.parameter import ModelParameter
from omnia.generics.array import np
from ..ag_model import AutoGluonBaseModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import NumericalX, TextX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class SupportVectorMachineModel(AutoGluonBaseModel):
    """
    Support Vector Machine (SVM) model.

    Implementation is based on the Scikit-Learn svm library:
        - https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html
        - https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVR.html

    Parameters
    ----------
    c : float, default=1.0
        Penalty parameter C of the error term.

    kernel : {'linear', 'poly', 'rbf', 'sigmoid'}, default='rbf'
        Specifies the kernel type to be used in the algorithm.
        It must be one of 'linear', 'poly', 'rbf', 'sigmoid'.
        If none is given, 'rbf' will be used.

    degree : int, default=3
        Degree of the polynomial kernel function ('poly').
        Ignored by all other kernels.

    gamma : float, default=0.0
        Kernel coefficient for 'rbf', 'poly' and 'sigmoid'.
        If gamma is 0.0 then 1/n_features will be used instead.
        If auto, uses 1/n_features.

    coef0 : float, default=0.0
        Independent term in kernel function.

    epsilon : float, default=0.1
        Epsilon in the epsilon-SVR model.

    shrinking : bool, default=True
        Whether to use the shrinking heuristic.

    probability : bool, default=True
        Whether to enable probability estimates. This must be enabled prior to calling
        predict_proba.

    tol : float, default=1e-3
        Tolerance for stopping criterion.

    cache_size : float, default=200
        Specify the size of the kernel cache (in MB).

    class_weight : {dict, 'balanced'}, default=None
        Set the parameter C of class i to class_weight[i]*C for SVC.
        If not given, all classes are supposed to have weight one.
        The ‘balanced’ mode uses the values of y to automatically adjust weights
        inversely proportional to class frequencies in the input data
        as n_samples / (n_classes * np.bincount(y))

    max_iter : int, default=-1
        Hard limit on iterations within solver, or -1 for no limit.

    decision_function_shape : {'ovo', 'ovr'}, default='ovr'
        Whether to return a one-vs-rest ('ovr') decision function of shape
        (n_samples, n_classes) as all other classifiers, or the original
        one-vs-one ('ovo') decision function of libsvm which has shape
        (n_samples, n_classes * (n_classes - 1) / 2).

    random_state : int, default=0
        The seed of the pseudo random number generator to use when shuffling
        the data for probability estimation.

    Attributes
    ----------
    model : sklearn.svm.SVC or sklearn.svm.SVR
        The model sklearn model.

    Examples
    --------
    >>> from omnia.generics.model import SupportVectorMachineModel
    >>> from omnia.generics.dataframe import pd
    >>> x_train = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    >>> x_test = pd.DataFrame([[7, 8], [9, 10], [11, 12]])
    >>> y_train = pd.DataFrame([1, 2, 3])
    >>> model = SupportVectorMachineModel()
    >>> model.fit(x_train, y_train)
    >>> y_pred = model.predict(x_test)
    """
    name = 'SVM'

    c = ModelParameter(default=1.0, tunable=True, space=Real(lower=0.0, upper=1.0, default=1.0), alias='C')
    kernel = ModelParameter(default='rbf', tunable=True,
                            space=Categorical('rbf', 'linear', 'poly', 'sigmoid', 'precomputed'))
    degree = ModelParameter(default=3, tunable=True, space=Int(lower=1, upper=10, default=3))
    gamma = ModelParameter(default='scale', tunable=True, space=Categorical('scale', 'auto'))
    coef0 = ModelParameter(default=0.0, tunable=True, space=Real(lower=0.0, upper=1.0, default=0.0))
    epsilon = ModelParameter(default=0.1, tunable=True, space=Real(lower=0.0, upper=1.0, default=0.1))
    shrinking = ModelParameter(default=True, tunable=True, space=Categorical(True, False))
    # Probability is not tunable because AG will call predict_proba() which will fail if probability=False
    probability = ModelParameter(default=True, tunable=False)
    tol = ModelParameter(default=1e-3, tunable=True, space=Real(lower=0.0, upper=1.0, default=1e-3))
    cache_size = ModelParameter(default=200, tunable=False)
    class_weight = ModelParameter(default=None, tunable=False)
    max_iter = ModelParameter(default=-1, tunable=False)
    decision_function_shape = ModelParameter(default='ovr', tunable=True, space=Categorical('ovr', 'ovo'))
    random_state = ModelParameter(default=0, tunable=False)

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))

    def _preprocess_data(self, x):
        return x.fillna(0).to_numpy(dtype=np.float32)

    def _fit_data(self, x, y, x_val=None, y_val=None):
        params = self._get_model_params()

        if self.problem_type in ['regression', 'softclass']:
            model_cls = SVR
            params.pop('class_weight', None)
            params.pop('decision_function_shape', None)
            params.pop('probability', None)
            params.pop('random_state', None)

        else:
            model_cls = SVC
            params.pop('epsilon', None)

        self.model = model_cls(**params)
        self.model.fit(x, y)


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    from omnia.generics.dataframe import pd

    x_train = pd.DataFrame([[1, 2, 10, 11, 12, 9], [3, 4, 10, 11, 12, 9], [5, 6, 10, 11, 12, 9]])
    y_train = pd.DataFrame([0.1, 0.2, 0.3])

    model = SupportVectorMachineModel()
    model.fit(x_train, y_train)

    x_test = pd.DataFrame([[1, 2, 10, 11, 12, 9], [9, 10, 10, 11, 12, 9], [11, 12, 10, 11, 12, 9]])
    y_pred = model.predict(x_test)
    print(y_pred)

    y_pred_proba = model.predict_proba(x_test)
    print(y_pred_proba)

    y_test = pd.DataFrame([0, 0, 0])
    score = model.score(x=x_test, y=y_test)
    print(score)
