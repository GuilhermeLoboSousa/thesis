from autogluon.common.space import Real, Int
from autogluon.tabular.models import LGBModel as AGLGBModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class LGBModel(AutoGluonModel, AGLGBModel):
    """
    Class that represents a LightGBM model.

    LightGBM model: https://lightgbm.readthedocs.io/en/latest/
    Hyperparameter options: https://lightgbm.readthedocs.io/en/latest/Parameters.html
    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models

    Parameters
    ----------
    learning_rate: float, (default=0.03)
        The learning rate for the model.

    num_leaves: int, optional (default=128)
        The number of leaves in the tree.

    feature_fraction: float, optional (default=0.9)
        The fraction of features to be used in the model.

    bagging_fraction: float, optional (default=1.0)
        The fraction of samples to be used in the model.

    min_data_in_leaf: int, optional (default=20)
        The minimum number of data in a leaf.

    """
    name = 'LGBModel'

    learning_rate: float = ModelParameter(default=0.03, tunable=True,
                                          space=Real(lower=5e-3, upper=0.2, default=0.03, log=True))
    num_leaves: int = ModelParameter(default=128, tunable=True, space=Int(lower=16, upper=128, default=128))
    feature_fraction: float = ModelParameter(default=0.9, tunable=True, space=Real(lower=0.75, upper=1.0, default=0.9))
    bagging_fraction: float = ModelParameter(default=1.0)
    min_data_in_leaf: int = ModelParameter(default=20, tunable=True, space=Int(lower=2, upper=60, default=20))

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))


if __name__ == '__main__':
    from omnia.generics.dataframe import pd

    _x = pd.DataFrame({'a': [1, 2, 3, 4, 5], 'b': [1, 2, 3, 4, 5]})
    _y = pd.Series([1, 0, 0, 0, 1])
    model = LGBModel()
    model.fit(_x, _y)
    model.predict(_x)
