from autogluon.common.space import Int, Categorical
from autogluon.tabular.models import KNNModel as AGKNNModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class KNNModel(AutoGluonModel, AGKNNModel):
    """
    Class that represents a K Nearest Neighbors model
    KNN model (scikit-learn):
        - https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html

    Parameters
    ----------
    n_neighbors : int, default=5
        Number of neighbors to use by default for :meth:`kneighbors` queries.

    weights : str, default='uniform'
        Weight function used in prediction.
        - 'uniform' : uniform weights. All points in each neighborhood are weighted equally.
        - 'distance' : weight points by the inverse of their distance. in this case, closer neighbors of a query point
            will have a greater influence than neighbors which are further away.

    algorithm : {'auto', 'ball_tree', 'kd_tree', 'brute'}, default='auto'
        Algorithm used to compute the nearest neighbors.
        - 'ball_tree' will use :class:`BallTree`
        - 'kd_tree' will use :class:`KDTree`
        - 'brute' will use a brute-force search.
        - 'auto' will attempt to decide the most appropriate algorithm based on the values passed to :meth:`fit` method.

    leaf_size : int, default=30
        Leaf size passed to :class:`BallTree` or :class:`KDTree`. This can affect the speed of the construction and
        query, as well as the memory required to store the tree. The optimal value depends on the
        nature of the problem.

    p : int, default=2
        Power parameter for the Minkowski metric. When p = 1, this is equivalent to using manhattan_distance (l1), and
        euclidean_distance (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.

    metric : str or callable, default='minkowski'
        the distance metric to use for the tree.
        - 'minkowski' : use the city block or Euclidean distance metric.
        - 'euclidean' : use the Euclidean distance metric.
        - 'l1' : use the manhattan distance metric.
        - 'l2' : use the Euclidean distance metric.
        - 'manhattan' : use the manhattan distance metric.
        - callable : a user-defined metric. The function should accept two arrays
            (of equal length), and return the distance between them.

    Examples
    --------
    >>> from omnia.generics.model import KNNModel
    >>> from omnia.generics.dataframe import pd
    >>> x_train = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    >>> x_test = pd.DataFrame([[7, 8], [9, 10], [11, 12]])
    >>> y_train = pd.DataFrame([1, 2, 3])
    >>> model = KNNModel()
    >>> model.fit(x_train, y_train)
    >>> y_pred = model.predict(x_test)
    """
    name = 'KNNModel'

    n_neighbors: int = ModelParameter(default=5, tunable=True, space=Int(1, 30, default=5))
    weights: str = ModelParameter(default='uniform', tunable=True, space=Categorical('uniform', 'distance'))
    algorithm: str = ModelParameter(default='auto', tunable=True, space=Categorical('auto', 'ball_tree',
                                                                                    'kd_tree', 'brute'))
    leaf_size: int = ModelParameter(default=30, tunable=True, space=Int(1, 50, default=30))
    p: int = ModelParameter(default=2, tunable=True, space=Int(1, 2, default=2))
    # TODO: Fix this. In some datasets, the precomputed matrix has negative values, which is not allowed.
    # metric: str = ModelParameter(default='minkowski', tunable=True, space=Categorical('minkowski', 'precomputed'))
    metric: str = ModelParameter(default='minkowski', tunable=False)

    validation_property = ValidationProperty(input_tag=IsPandasX & NumericalX)
