from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

from omnia.generics import ModelParameter
from omnia.generics.array import np
from omnia.generics.model import AutoGluonBaseModel
from omnia.generics.validation import NumericalX, TextX


class RandomForestModel(AutoGluonBaseModel):
    """
    Random Forest Model
    A random forest is a meta estimator that fits a number of decision tree classifiers
    on various sub-samples of the dataset and uses averaging to improve the predictive accuracy and control over-fitting.
    The whole dataset is used to build each tree

    Parameters
    ----------
    n_estimators : int
        The number of trees in the forest.

    criterion : string, optional (default="gini")
        The function to measure the quality of a split. Supported criteria are the following:
            - "gini" for the Gini impurity
            - "entropy" for the information gain
            - "log_loss" for the log loss
            - "mse" for the mean squared error

    max_depth : int or None, optional (default=None)
        The maximum depth of the tree.
        If None, then nodes are expanded until all leaves are pure or until all leaves contain less
        than min_samples_split samples.

    n_jobs : int
        The number of jobs to run in parallel for both fit and predict.

    random_state : int
        The seed of the pseudo random number generator to use when shuffling the data.

    bootstrap : bool
        Whether bootstrap samples are used when building trees.

    Attributes
    ----------
    model : sklearn.ensemble.RandomForestRegressor or sklearn.ensemble.RandomForestClassifier
        The model.

    Examples
    --------
    >>> from omnia.generics.model import RandomForestModel
    >>> from omnia.generics.dataframe import pd
    >>> x_train = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    >>> x_test = pd.DataFrame([[7, 8], [9, 10], [11, 12]])
    >>> y_train = pd.DataFrame([1, 2, 3])
    >>> model = RandomForestModel()
    >>> model.fit(x_train, y_train)
    >>> y_pred = model.predict(x_test)
    """
    name = 'RF'
    n_estimators = ModelParameter(default=300, tunable=False)
    criterion = ModelParameter(default="gini", tunable=False)
    max_depth = ModelParameter(default=1, tunable=False)
    n_jobs = ModelParameter(default=-1, tunable=False)
    random_state = ModelParameter(default=0, tunable=False)
    bootstrap = ModelParameter(default=True, tunable=False)

    tags = [NumericalX, TextX]

    def _preprocess_data(self, x):
        return x.fillna(0).to_numpy(dtype=np.float32)

    def _fit_data(self, x, y, x_val=None, y_val=None):
        if self.problem_type in ['regression', 'softclass']:
            model_cls = RandomForestRegressor
        else:
            model_cls = RandomForestClassifier

        params = self._get_model_params()
        self.model = model_cls(**params)
        self.model.fit(x, y)


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    from omnia.generics.dataframe import pd
    x_train = pd.DataFrame([[1, 2, 10, 11, 12, 9], [3, 4, 10, 11, 12, 9], [5, 6, 10, 11, 12, 9]])
    y_train = pd.DataFrame([1, 0, 0])

    model = RandomForestModel(n_estimators=600)
    model.fit(x_train, y_train)
    print(model.n_estimators)
    print(model.criterion)

    x_test = pd.DataFrame([[1, 2, 10, 11, 12, 9], [9, 10, 10, 11, 12, 9], [11, 12, 10, 11, 12, 9]])
    y_pred = model.predict(x_test)
    print(y_pred)

    y_pred_proba = model.predict_proba(x_test)
    print(y_pred_proba)

    y_test = pd.DataFrame([0, 0, 0])
    score = model.score(x=x_test, y=y_test)
    print(score)
