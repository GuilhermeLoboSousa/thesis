from autogluon.common.space import Int
from autogluon.tabular.models import RFModel

from ..ag_model import AutoGluonModel
from omnia.generics.parameter import ModelParameter
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import NumericalX, TextX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class RandomForestModel(AutoGluonModel, RFModel):
    """
    Random Forest Model
    Random Forest model (scikit-learn):
        - https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html

    A random forest is a meta estimator that fits a number of decision tree classifiers
    on various sub-samples of the dataset and uses averaging to improve the predictive accuracy and control over-fitting.
    The whole dataset is used to build each tree

    Parameters
    ----------
    n_estimators : int, optional (default=300)
        The number of trees in the forest.

    criterion : string, optional (default="gini")
        The function to measure the quality of a split. Supported criteria are the following:
            - "gini" for the Gini impurity
            - "entropy" for the information gain
            - "log_loss" for the log loss
            - "mse" for the mean squared error

    max_leaf_nodes : int, optional (default=15000)
        Grow trees with max_leaf_nodes in best-first fashion.
        Best nodes are defined as relative reduction in impurity.
        Cap leaf nodes to 15000 to avoid large datasets using unreasonable amounts of memory/disk for RF/XT

    n_jobs : int, optional (default=-1)
        The number of jobs to run in parallel for both fit and predict.

    random_state : int, optional (default=0)
        The seed of the pseudo random number generator to use when shuffling the data.

    bootstrap : bool, optional (default=True)
        Whether bootstrap samples are used when building trees.

    Examples
    --------
    >>> from omnia.generics.model import RandomForestModel
    >>> from omnia.generics.dataframe import pd
    >>> x_train = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    >>> x_test = pd.DataFrame([[7, 8], [9, 10], [11, 12]])
    >>> y_train = pd.DataFrame([1, 2, 3])
    >>> model = RandomForestModel()
    >>> model.fit(x_train, y_train)
    >>> y_pred = model.predict(x_test)
    """
    name = 'RF'
    n_estimators: int = ModelParameter(default=300, tunable=False)  # This parameter is
    # not tunable because it is not supported by AutoGluon
    criterion: str = ModelParameter(default="gini",
                                    tunable=False,
                                    binary__default="gini",
                                    multiclass__default="gini",
                                    regression__default="squared_error")
    max_leaf_nodes: int = ModelParameter(default=15000, tunable=True, space=Int(1000, 15000, default=15000))
    n_jobs: int = ModelParameter(default=-1, tunable=False)
    random_state: int = ModelParameter(default=0, tunable=False)
    bootstrap: bool = ModelParameter(default=True, tunable=False)

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))
