from autogluon.common.space import Real, Categorical
from autogluon.tabular.models import TabularNeuralNetTorchModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import NumericalX, TextX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class MultilayerPerceptronNN(AutoGluonModel, TabularNeuralNetTorchModel):
    """
    Multilayer Perceptron Neural Network

    Parameters
    ----------
    num_epochs : int (default: 500)
        Maximum number of epochs to train the model.

    epochs_wo_improve : int (default: 20)
        Number of epochs without improvement to stop training. If the validation performance has not improved for
        this number of epochs, the training will be stopped.

    activation : str (default: 'relu')
        Activation function to use.
        Possible values accoring to the `torch.nn.functional`:
            - 'relu'
            - 'elu'
            - 'tanh'

    embedding_size_factor : float (default: 1.0)
        Factor to multiply the embedding size. This will adjust the size of embedding layers to the number of features.
        It ranges from 0.01 to 100 on log-scale.

    embed_exponent : float (default: 0.56)
        Exponent to use for the embedding size.

    max_embedding_dim : int (default: 100)
        Maximum embedding dimension. The maximum embedding size for a single categorical feature.
        It must be an integer greater than 1.

    y_range : tuple (default: None)
        Range of the target variable. It must be a tuple with two elements. The first element is the minimum value and
        the second element is the maximum value (min_y, max_y).
        If None, the minimum and maximum values are estimated from the Y.
        If the problem type is classification, this value must be None.
        (-np.inf, np.inf) is also allowed.
        REGRESSION PROBLEM TYPE ONLY.

    y_range_extend : float (default: 0.05)
        Range of the target variable that will be extended if y_range is None.
        REGRESSION PROBLEM TYPE ONLY.

    dropout_prob : float (default: 0.1)
        Dropout probability. It must be a float between 0 and 1.
        If 0, no dropout is applied.

    optim : str (default: 'adam')
        Optimizer to use.
        Possible values accoring to the `torch.optim`:
            - 'adam'
            - 'sgd'

    learning_rate : float (default: 3e-4)
        Learning rate used by the optimizer to update the weights during model trainning.
        It must be a float greater than 0.

    weight_decay : float (default: 1e-6)
        Weight decay regularization parameter. It must be a float greater than 0.

    use_ngram_features : bool (default: False)
        Use ngram features. If False, it will drop automatically generated ngram features from language features.
        This results in worse model quality but far faster inference and training times.

    num_layers : int (default: 4)
        Number of layers in the model. It must be an integer. It can range from 2 to 5.

    hidden_size : int (default: 128)
        Number of hidden units in each layer. It must be an integer.
        Possible values:
            - 128
            - 256
            - 512

    maximum_batch_size : int (default: 512)
        Maximum batch size to use. It must be an integer. It can range from 1 to 1000.
        Note that the batch size is not fixed. It will be adjusted to fit the data.

    use_batchnorm : bool (default: False)
        It determines whether to use batch normalization.

    loss_function : str (default: 'auto')
        Loss function to use.  It must be a string.
        Possible values accoring to the `torch.nn.functional`:
            - 'binary_cross_entropy'
            - 'binary_cross_entropy_with_logits'
            - 'poisson_nll_loss'
            - 'cosine_embedding_loss'
            - 'cross_entropy'
            - 'ctc_loss'
            - 'gaussian_nll_loss'
            - 'hinge_embedding_loss'
            - 'kl_div'
            - 'l1_loss'
            - 'mse_loss'
            - 'margin_ranking_loss'
            - 'multilabel_margin_loss'
            - 'multilabel_soft_margin_loss'
            - 'multi_margin_loss'
            - 'nll_loss'
            - 'huber_loss'
            - 'smooth_l1_loss'
            - 'soft_margin_loss'
            - 'triplet_margin_loss'
            - 'triplet_margin_with_distance_loss'

        If 'auto', it will be automatically selected according to the problem type.

    gamma : float (default: 5.0)
        Margin loss weight which helps ensure noncrossing quantile estimates.
        It can range from 0.1 to 10.0 with 0.1 steps.
        QUANTILE PROBLEM TYPE ONLY.

    alpha : float (default: 0.01)
        Alpha parameter for the huber pinbal loss function. It must be a float greater than 0.
        QUANTILE PROBLEM TYPE ONLY.

    seed_value : int (default: 0)
        Seed value to use for the random number generator.
        It must be an integer.

    proc_embed_min_categories: int, (default: 4)
        Minimum number of categories to use for the embedding.
        It must be an integer greater than 1.
        TEXT PROBLEM TYPE ONLY.

    proc_impute_strategy: str, (default: 'median')
        Imputation strategy to use.
        Possible values accoring to the `sklearn.impute`:
            - 'mean'
            - 'median'
            - 'most_frequent'
            - 'constant'
            - 'most_recent'
            - 'random'
        TEXT PROBLEM TYPE ONLY.

    proc_max_category_levels: int, (default: 100)
        Maximum number of category levels to use.
        It must be an integer greater than 1.
        TEXT PROBLEM TYPE ONLY.

    proc_skew_threshold: float, (default: 0.99)
        Threshold to use for the skew.
        It must be a float between 0 and 1.
        TEXT PROBLEM TYPE ONLY.
    Examples
    --------
    >>> from omnia.generics.model import MultilayerPerceptronNN
    >>> from omnia.generics.dataframe import pd
    >>> x_train = pd.DataFrame([[1, 2], [3, 4], [5, 6]])
    >>> x_test = pd.DataFrame([[7, 8], [9, 10], [11, 12]])
    >>> y_train = pd.DataFrame([1, 2, 3])
    >>> model = MultilayerPerceptronNN()
    >>> model.fit(x_train, y_train)
    >>> y_pred = model.predict(x_test)
    """
    name = 'MLP'

    num_epochs: int = ModelParameter(default=500, tunable=False)
    epochs_wo_improve: int = ModelParameter(default=20, tunable=False)
    activation: str = ModelParameter(default='relu', tunable=True, space=Categorical('relu', 'elu', 'tanh'))
    embedding_size_factor: float = ModelParameter(default=1.0, tunable=True,
                                                  space=Categorical(1.0, 0.5, 1.5, 0.7, 0.6, 0.8, 0.9, 1.1, 1.2, 1.3,
                                                                    1.4))
    embed_exponent: float = ModelParameter(default=0.56, tunable=False)
    max_embedding_dim: int = ModelParameter(default=100, tunable=False)
    y_range: float = ModelParameter(default=None, tunable=False)
    y_range_extend: float = ModelParameter(default=0.05, tunable=False)
    dropout_prob: float = ModelParameter(default=0.1, tunable=True, space=Categorical(0.1, 0.0, 0.5, 0.2, 0.3, 0.4))
    optim: str = ModelParameter(default='adam', tunable=False, alias='optimizer')
    learning_rate: float = ModelParameter(default=3e-4, tunable=True,
                                          space=Real(lower=1e-4, upper=3e-2, default=3e-4, log=True))
    weight_decay: float = ModelParameter(default=1e-6, tunable=True,
                                         space=Real(lower=1e-12, upper=1, default=1e-6, log=True))
    use_ngram_features: bool = ModelParameter(default=False, tunable=False)
    num_layers: int = ModelParameter(default=4, tunable=True, space=Categorical(4, 2, 3, 5, 6, 7, 8, 9, 10))
    hidden_size: int = ModelParameter(default=128, tunable=True, space=Categorical(128, 64, 256, 512))
    maximum_batch_size: int = ModelParameter(default=512, tunable=False, alias='max_batch_size')
    use_batchnorm: bool = ModelParameter(default=False, tunable=True, space=Categorical(False, True))
    loss_function: str = ModelParameter(default='auto', tunable=False)
    gamma: float = ModelParameter(default=5.0, tunable=True, space=Real(lower=0.1, upper=10.0, default=5.0, log=True))
    alpha: float = ModelParameter(default=0.01, tunable=True, space=Categorical(0.01, 0.001, 0.1, 1.0))
    seed_value: int = ModelParameter(default=0, tunable=False)
    proc_embed_min_categories: int = ModelParameter(default=4, tunable=False, alias='proc.embed_min_categories')
    proc_impute_strategy: str = ModelParameter(default='median', tunable=False, alias='proc.impute_strategy')
    proc_max_category_levels: int = ModelParameter(default=100, tunable=False, alias='proc.max_category_levels')
    proc_skew_threshold: float = ModelParameter(default=0.99, tunable=False, alias='proc.skew_threshold')

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))


if __name__ == '__main__':
    import doctest

    doctest.testmod()
