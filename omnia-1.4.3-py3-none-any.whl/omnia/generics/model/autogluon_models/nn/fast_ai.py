from typing import List, Union

from autogluon.common.space import Real, Categorical
from autogluon.tabular.models import NNFastAiTabularModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class FastAINN(AutoGluonModel, NNFastAiTabularModel):
    """
    Class that represents a Fast AI model.

    Fast AI model: https://docs.fast.ai/
    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models

    Parameters
    ----------
    layers : List[int], optional (default=None)
        List of layer sizes.

    emb_drop: float, optional (default=0.1)
        Embedding dropout.

    ps: float, optional (default=0.1)
        Dropout probability.

    bs: int or str, optional (default='auto')
        Batch size.

    lr: float, optional (default=1e-2)
        Learning rate.

    epochs: int or str, optional (default='auto')
        Number of epochs.

    smoothing: float, optional (default=0.0)
        Label smoothing.

    alpha: float, optional (default=0.01)
        Regularization strength in HuberPinball loss.
        To be used in quantile regression.

    early_stopping_min_delta: float, optional (default=0.0001)
        Early stopping threshold. https://docs.fast.ai/callbacks.tracker.html#EarlyStoppingCallback

    early_stopping_patience: int, optional (default=20)
        Early stopping patience. https://docs.fast.ai/callbacks.tracker.html#EarlyStoppingCallback
    """
    name = 'FastAINN'
    layers: List[int] = ModelParameter(default=None, tunable=True,
                                       space=Categorical(None, [200, 100], [200], [500], [1000], [500, 200], [50, 25],
                                                         [1000, 500], [200, 100, 50], [500, 200, 100],
                                                         [1000, 500, 200]))
    emb_drop: float = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 0.5, default=0.1))
    ps: float = ModelParameter(default=0.1, tunable=True, space=Real(0.0, 0.5, default=0.1))
    bs: Union[str, int] = ModelParameter(default='auto')
    lr: float = ModelParameter(default=1e-2, tunable=True, space=Real(5e-5, 1e-1, default=1e-2, log=True))
    epochs: Union[str, int] = ModelParameter(default='auto', tunable=False)
    smoothing: float = ModelParameter(default=0.0)
    alpha: float = ModelParameter(default=0.01, tunable=True, space=Categorical(0.01, 0.001, 0.1, 1.0))
    early_stopping_min_delta: float = ModelParameter(default=0.0001, tunable=False, alias='early.stopping.min_delta')
    early_stopping_patience: int = ModelParameter(default=20, tunable=False, alias='early.stopping.patience')

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))
