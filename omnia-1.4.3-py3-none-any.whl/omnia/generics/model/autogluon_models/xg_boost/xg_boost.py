from autogluon.common.space import Real, Int, Categorical
from autogluon.tabular.models import XGBoostModel as AGXGBoostModel

from ..ag_model import AutoGluonModel
from omnia.generics.parameter import ModelParameter
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class XGBoostModel(AutoGluonModel, AGXGBoostModel):
    """
    Class that represents a XGBoost model.

    XGBoost model: https://xgboost.readthedocs.io/en/latest/
    XGBoost hyperparameter options: https://xgboost.readthedocs.io/en/latest/parameter.html
    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models

    Parameters
    ----------
    n_estimators : int, default=10000
        Number of trees in the model.

    booster : str, default='gbtree'
        Booster type.

    objective : str, default='binary:logistic'
        Objective function.

    learning_rate : float, default=0.1
        Learning rate for the model.

    use_label_encoder : bool, default=False
        Whether to use label encoder.

    max_depth : int, default=6
        Maximum depth of the tree.

    min_child_weight : int, default=1
        Minimum sum of instance weight(hessian) needed in a child.

    gamma : float, default=0.01
        Minimum loss reduction required to make a further partition on a leaf node of the tree.

    subsample : float, default=1.0
        Subsample ratio of the training instance.

    colsample_bytree : float, default=1.0
        Subsample ratio of columns when constructing each tree.

    reg_alpha : float, default=0.0
        L1 regularization term on weights.

    reg_lambda : float, default=1.0
        L2 regularization term on weights.

    n_jobs : int, default=-1
        Number of jobs to run in parallel.
    """
    name = 'XGBoostModel'

    n_estimators: int = ModelParameter(default=10000, tunable=False)
    booster: str = ModelParameter(default='gbtree', tunable=False)
    objective: str = ModelParameter(default='binary:logistic', tunable=False,
                                    binary__default='binary:logistic',
                                    multiclass__default='multi:softproba',
                                    regression__default='reg:squarederror')
    learning_rate: float = ModelParameter(default=0.1, tunable=True,
                                          space=Real(lower=5e-3, upper=0.2, default=0.1, log=True))
    use_label_encoder: bool = ModelParameter(default=False, tunable=True, space=Categorical(False, True))
    max_depth: int = ModelParameter(default=6, tunable=True, space=Int(lower=3, upper=10, default=6))
    min_child_weight: int = ModelParameter(default=1, tunable=True, space=Int(lower=1, upper=5, default=1))
    gamma: float = ModelParameter(default=0.01, tunable=True, space=Real(lower=0, upper=5, default=0.01))
    subsample: float = ModelParameter(default=1.0, tunable=True, space=Real(lower=0.5, upper=1.0, default=1.0))
    colsample_bytree: float = ModelParameter(default=1.0, tunable=True, space=Real(lower=0.5, upper=1.0, default=1.0))
    reg_alpha: float = ModelParameter(default=0.0, tunable=True, space=Real(lower=0.0, upper=10.0, default=0.0))
    reg_lambda: float = ModelParameter(default=1.0, tunable=True, space=Real(lower=0.0, upper=10.0, default=1.0))
    n_jobs: int = ModelParameter(default=-1, tunable=False)
    proc_max_category_levels: int = ModelParameter(default=100, tunable=False, alias='proc.max_category_levels')

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))
