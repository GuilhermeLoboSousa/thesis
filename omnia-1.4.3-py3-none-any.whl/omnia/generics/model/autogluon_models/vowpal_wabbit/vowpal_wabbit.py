from autogluon.common.features.types import R_INT, R_FLOAT, R_CATEGORY, R_OBJECT, S_TEXT_NGRAM, S_IMAGE_PATH, \
    S_TEXT_AS_CATEGORY, S_TEXT_SPECIAL
from autogluon.common.space import Int, Categorical
from autogluon.tabular.models import VowpalWabbitModel as AGVowpalWabbitModel

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class VowpalWabbitModel(AutoGluonModel, AGVowpalWabbitModel):
    """
    Class that represents a Vowpal Wabbit model.

    Vowpal Wabbit model: https://vowpalwabbit.org/
    VowpalWabbit Command Line args: https://github.com/VowpalWabbit/vowpal_wabbit/wiki/Command-line-arguments
    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models

    Parameters
    ----------
    passes : int, optional (default=10)
        Number of passes over the data.

    bit_precision : int, optional (default=32)
        Number of bits of precision to use for floating point values.

    ngram : int, optional (default=2)
        Number of ngrams to use for text features.

    skips : int, optional (default=1)
        Number of skips to use for text features.

    learning_rate : float, optional (default=1)
        Learning rate for the model.

    sparse_weights : bool, optional (default=True)
        Whether to use sparse weights.
    """
    name = 'VowpalWabbitModel'

    passes: int = ModelParameter(default=10, tunable=True, space=Int(1, 100, default=10))
    bit_precision: int = ModelParameter(default=16, tunable=False, space=Int(1, 32, default=32))
    ngram: int = ModelParameter(default=2, tunable=True, space=Int(1, 10, default=2))
    skips: int = ModelParameter(default=1, tunable=True, space=Int(1, 10, default=1))
    learning_rate: int = ModelParameter(default=1, tunable=True, space=Int(1, 10, default=1))
    sparse_weights: int = ModelParameter(default=True, tunable=True, space=Categorical(True, False))

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))

    def _get_default_auxiliary_params(self) -> dict:
        """
        Returns the default auxiliary parameters for the model.

        It has to be re-implemented in VowpalWabbitModel because it behaves differently than the remaining models.
        Returns
        -------
        auxiliary_params : dict
            The default auxiliary parameters for the model.
        """
        default_auxiliary_params = super()._get_default_auxiliary_params()
        extra_auxiliary_params = dict(
            valid_raw_types=[R_INT, R_FLOAT, R_CATEGORY, R_OBJECT],
            ignored_type_group_special=[S_IMAGE_PATH, S_TEXT_NGRAM, S_TEXT_AS_CATEGORY, S_TEXT_SPECIAL]
        )
        default_auxiliary_params.update(extra_auxiliary_params)
        return default_auxiliary_params
