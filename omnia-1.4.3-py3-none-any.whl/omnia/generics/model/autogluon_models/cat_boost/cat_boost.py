from autogluon.common.space import Real, Int
from autogluon.core.constants import SOFTCLASS
from autogluon.tabular.models import CatBoostModel as AGCatBoostModel
from autogluon.tabular.models.catboost.catboost_utils import get_catboost_metric_from_ag_metric

from omnia.generics.parameter import ModelParameter
from ..ag_model import AutoGluonModel
from omnia.generics.setup.registry import class_register
from omnia.generics.validation import TextX, NumericalX, IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


@class_register
class CatBoostModel(AutoGluonModel, AGCatBoostModel):
    """
    Class that represents a CatBoost model.

    CatBoost model: https://catboost.ai/
    CatBoost hyperparameter options: https://catboost.ai/docs/concepts/python-reference_parameters-list.html
    AutoGluon model: https://auto.gluon.ai/stable/api/autogluon.tabular.models.html#module-autogluon.tabular.models
    Parameters
    ----------
    iterations : int, default=10000
        Number of iterations.

    learning_rate : float, default=0.05
        Learning rate.

    depth : int, default=6
        Depth of the tree.

    l2_leaf_reg : float, default=3
        L2 regularization.

    random_seed : int, default=0
        Random seed to ensure reproducibility.

    allow_writing_files : bool, default=False
        Whether to allow writing CatBoost log files.
    """
    name = 'CatBoostModel'
    iterations: int = ModelParameter(default=10000, tunable=False)
    learning_rate: float = ModelParameter(default=0.05, tunable=True,
                                          space=Real(lower=5e-3, upper=0.2, default=0.05, log=True))
    depth: int = ModelParameter(default=6, tunable=True, space=Int(lower=5, upper=8, default=6))
    l2_leaf_reg: float = ModelParameter(default=3, tunable=True, space=Real(lower=1, upper=5, default=3))
    random_seed: int = ModelParameter(default=0, tunable=False)
    allow_writing_files: bool = ModelParameter(default=False, tunable=False)

    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX | TextX))

    def _set_default_params(self):
        """
        Set default parameters.
        """
        params = self._get_default_params()

        for param, val in params.items():
            self._set_default_param_value(param, val)

        if self.problem_type != SOFTCLASS:
            eval_metric = get_catboost_metric_from_ag_metric(self.stopping_metric, self.problem_type)
            self._set_default_param_value('eval_metric', eval_metric)
