from omnia.generics.model.autogluon_models.random_forest import RandomForestModel
from omnia.generics.model.autogluon_models.mlp import MultilayerPerceptronNN
from omnia.generics.model.autogluon_models.cat_boost import CatBoostModel
from omnia.generics.model.autogluon_models.knn import KNNModel
from omnia.generics.model.autogluon_models.lgb import LGBModel
from omnia.generics.model.autogluon_models.linear import LinearModel
from omnia.generics.model.autogluon_models.nn import FastAINN
from omnia.generics.model.autogluon_models.svm import SupportVectorMachineModel
from omnia.generics.model.autogluon_models.xg_boost import XGBoostModel
from omnia.generics.model.autogluon_models.xt import XTModel
from omnia.generics.model.autogluon_models import VowpalWabbitModel


_MODELS = {RandomForestModel: {},
           MultilayerPerceptronNN: {},
           CatBoostModel: {},
           KNNModel: {},
           LGBModel: {},
           LinearModel: {},
           FastAINN: {},
           VowpalWabbitModel: {},
           XGBoostModel: {},
           XTModel: {},
           SupportVectorMachineModel: {}}
