import os
from typing import Any, Callable, List, Union

from torch.utils.data import DataLoader, TensorDataset
import pickle

from omnia.generics import np
from omnia.generics.model import Model
from omnia.generics.model.torch_models._torch_dataset import _to_tensor
from omnia.generics.utils.keywords import kwargs_only
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.utils import to_numpy
from omnia.generics.utils.constants import BINARY, MULTICLASS
from .lightning_module import OmniaLightningModule
from .lightning_data_module import OmniaDataModule
from pytorch_lightning import Trainer
from pytorch_lightning.tuner import Tuner
from pytorch_lightning.callbacks import ModelCheckpoint


class TorchModel(Model):
    """
    Base model for all PyTorch models in omnia. Child classes should implement the following methods:
    - _fit: fit the model to the data
    - _predict: make predictions on new data
    - _predict_proba: make probability predictions on new data
    """
    _input_type = DataTag.UNDEFINED
    _estimator_type = DataTag.UNDEFINED
    path = 'torch_model/'

    @kwargs_only(has_self=True)
    def __init__(self, callbacks: Union[Callable, List[Callable]] = None, **kwargs):
        """
        The model constructor.

        Parameters
        ----------
        kwargs: dict
            The model parameters.
        """
        super(TorchModel, self).__init__(**kwargs)

        self.model = self.model(**self.parameters)

        if isinstance(callbacks, Callable):
            callbacks = [callbacks]
        self.lightning_module = OmniaLightningModule(
            model=self.model, criterion=self.loss, optimizer=self.optimizer, learning_rate=self.learning_rate,
            epochs=self.epochs)
        self.trainer = Trainer(max_epochs=self.epochs, callbacks=callbacks, default_root_dir=self.path,
                               gradient_clip_val=0.5, logger=False, enable_checkpointing=False)
        self.tuner = Tuner(self.trainer)

    def _fit(self, x: Any, y: Any, x_val: Any = None, y_val: Any = None, **kwargs) -> 'TorchModel':
        """
        Fit the model to the data.

        Parameters
        ----------
        x: Any
            The input data to fit the model.
        y: Any
            The target variable to fit the model.
        x_val: Any
            The input data to validate the model.
        y_val: Any
            The target variable to validate the model.
        kwargs: dict
            Additional parameters to pass to the fit method.
        """

        datamodule = OmniaDataModule(x=x, y=y, batch_size=self.batch_size,
                                     x_val=x_val, y_val=y_val)

        # TODO: find out why this is not working, im pretty sure its because of the model param in the lightning module,
        #  which cant be loaded
        """
        lr_find = self.tuner.lr_find(self.lightning_module,
                                     datamodule=datamodule)
        self.tuner.scale_batch_size(self.lightning_module,
                                    datamodule=datamodule)
        """
        monitor = 'val_loss' if x_val is not None else 'train_loss'
        model_checkpoint = ModelCheckpoint(
            dirpath=self.path,  monitor=monitor, filename='{epoch:02d}-{step:02d}-{'+monitor+':.2f}', save_top_k=1,
            mode='min')
        self.trainer.callbacks.append(model_checkpoint)

        self.trainer.fit(self.lightning_module,
                         datamodule=datamodule, **kwargs)

        # load best model
        self.lightning_module = OmniaLightningModule.load_from_checkpoint(
            model_checkpoint.best_model_path, model=self.model)
        return self

    def _predict(self, x: Any) -> np.ndarray:
        """
        Make predictions on new data.

        Parameters
        ----------
        x: Any
            The input data to make predictions on.

        Returns
        -------
        predictions: np.ndarray
            The predictions.
        """
        self.lightning_module.eval()
        self.lightning_module.freeze()
        x_dataset = TensorDataset(_to_tensor(x))
        # NOTE: pytorch lightning handles predictions in batches, batch size is set to the length of the dataset
        # to make it easier to handle the predictions
        x_dataloader = DataLoader(
            x_dataset, batch_size=len(x_dataset), shuffle=False)

        predictions = self.trainer.predict(self.lightning_module, x_dataloader)
        predictions = to_numpy(predictions[0])

        if predictions.ndim > 2:
            # binary multi-task
            if self.problem_type == BINARY:
                predictions = predictions.squeeze(-1).T
                return (predictions > 0.5).astype(int)
            # multi-class multi-task
            elif self.problem_type == MULTICLASS:
                return np.array([np.argmax(pred, axis=1) for pred in predictions]).T
            # multi-task regression
            else:
                return predictions.squeeze(-1).T
        if hasattr(self, "n_classes"):
            # single task multi-class
            if self.n_classes > 2:
                predictions = np.argmax(predictions, axis=1)
                return np.expand_dims(predictions, axis=1)
            # single task binary
            return (predictions > 0.5).astype(int)

        # single task regression
        return predictions

    def _predict_proba(self, x: Any) -> np.ndarray:
        """
        Make probability predictions on new data.

        Parameters
        ----------
        x: Any
            The input data to make probability predictions on.

        Returns
        -------

        """
        if not self.can_predict_proba:
            raise ValueError('Model cannot predict probabilities.')

        self.lightning_module.eval()
        self.lightning_module.freeze()
        x_dataset = TensorDataset(_to_tensor(x))
        x_dataloader = DataLoader(
            x_dataset, batch_size=len(x_dataset), shuffle=False)

        predictions = self.trainer.predict(self.lightning_module, x_dataloader)
        predictions = to_numpy(predictions[0])

        if predictions.ndim > 2:
            if predictions.shape[-1] == 1:
                predictions = predictions.squeeze(-1).T
            else:
                predictions = np.swapaxes(predictions, 0, 1)

        return predictions

    def save(self, path: str = None) -> None:
        """
        Save the model to the given path.

        Parameters
        ----------
        path: str
            The path to save the model to.
        """
        path = self.path if path is None else path
        if path != self.path:
            try:
                os.rename(self.path, path)
            except FileExistsError:
                raise FileExistsError(f'Folder already exists: {path}')

        params_path = os.path.join(path, 'params.pkl')
        # NOTE: best model is saved by default with the ModelCheckpoint callback
        # model_path = os.path.join(path, 'model.ckpt')
        # self.trainer.save_checkpoint(model_path)
        parameters = self.parameters
        _fitted = self._fitted
        params_dict = {'parameters': parameters,
                       '_fitted': _fitted, 'problem_type': self.problem_type}
        with open(params_path, 'wb') as f:
            pickle.dump(params_dict, f)

    @classmethod
    def load(cls, path: str = None) -> 'TorchModel':
        """
        Load the model from the given path.

        Parameters
        ----------
        path: str
            Path to the file to load the model from.

        Returns
        -------
        model: TorchModel
            The model loaded from the file.
        """
        if path is None:
            path = cls.path
        # get the latest model checkpoint
        model_checkpoint = os.path.basename(
            max([os.path.join(path, f) for f in os.listdir(path) if f.endswith('.ckpt')], key=os.path.getctime))
        model_path = os.path.join(path, model_checkpoint)
        params_path = os.path.join(path, 'params.pkl')
        with open(params_path, 'rb') as f:
            params_dict = pickle.load(f)
        parameters = params_dict['parameters']
        instance = cls(**parameters)
        instance.lightning_module = OmniaLightningModule.load_from_checkpoint(
            model_path, model=instance.model)
        instance._fitted = params_dict['_fitted']
        instance._problem_type = params_dict['problem_type']
        return instance
