from typing import Any, List, Union
import pytorch_lightning as pl
from torch import nn
from ._utils import TORCH_CRITERION, TORCH_OPTIMIZER
from torch.utils.data import DataLoader
from torch import Tensor


class OmniaLightningModule(pl.LightningModule):
    """
    A LightningModule for training, validating, and predicting with a PyTorch model.

    Parameters
    ----------
    model : nn.Module
        The PyTorch model to be trained.
    criterion : str
        The loss function to be used during training.
    optimizer : str
        The optimizer to be used for training.
    learning_rate : float
        The learning rate for the optimizer.
    epochs : int
        The number of epochs to train the model.
    kwargs : dict
        Additional arguments.
    """

    def __init__(self, model: nn.Module, criterion: str, optimizer: str, learning_rate: float, epochs: int, **kwargs):
        super(OmniaLightningModule, self).__init__()
        self.save_hyperparameters(ignore='model')
        self.model = model
        self.criterion = TORCH_CRITERION[criterion]()
        self.optimizer = optimizer
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.kwargs = kwargs

    def forward(self, x: Any):
        """
        Same as torch.nn.Module.forward.

        Parameters:
        ----------
        x: Any
            The input data.

        Return:
        -------
            Your model's output.
        """
        return self.model(x)

    def training_step(self, batch: DataLoader,  batch_idx: int) -> Tensor:
        """
        Compute, log and return the training loss.

        Parameters:
        ----------
        batch: DataLoader
            The output of the data iterable.
        batch_idx: int
            The index of this batch.

        Return:
        -------
        Tensor - The loss tensor.
        """
        inputs, targets = batch
        outputs = self(inputs)
        loss = self._compute_loss(outputs, targets)
        self.log('train_loss', loss, prog_bar=True)
        return loss

    def validation_step(self, batch: DataLoader,  batch_idx: int):
        """
        Compute and log the validation loss.

        Parameters:
        ----------
        batch: DataLoader
            The output of the validation data iterable.
        batch_idx: int
            The index of this batch.
        """
        inputs, targets = batch
        outputs = self(inputs)
        loss = self._compute_loss(outputs, targets)
        self.log('val_loss', loss, prog_bar=True)

    def _compute_loss(self, outputs: Union[Tensor, List[Tensor]], targets: Union[Tensor, List[Tensor]]) -> Tensor:
        """
        Compute the loss between the model's outputs and the targets.

        Parameters:
        ----------
        outputs: Union[Tensor, List[Tensor]]
            The model's outputs, which can be a single tensor or a list of tensors for multi-task learning.
        targets: Union[Tensor, List[Tensor]]
            The target values, which can be a single tensor or a list of tensors for multi-task learning.

        Return:
        -------
        Tensor - The loss tensor.
        """
        if not isinstance(outputs, list):
            outputs = [outputs]

        if len(targets.shape) > 1:
            targets = [targets[:, i] for i in range(targets.shape[1])]
        else:
            targets = [targets]

        loss = 0
        for output, target in zip(outputs, targets):
            if output.shape[1] == 1:  # binary
                target = target.view(-1, 1)
                loss += self.criterion(output, target)
            else:  # multi-class
                target = target.view(-1).long()
                loss += self.criterion(output, target)

        return loss

    def configure_optimizers(self) -> Any:
        """
        Configure the optimizer for training.
        """
        optimizer = TORCH_OPTIMIZER[self.optimizer](
            self.parameters(), lr=self.learning_rate)
        return optimizer

    def predict_step(self, batch: DataLoader, batch_idx: int, dataloader_idx: int = None) -> Tensor:
        """
        Step function called during pytorch_lightning.trainer.trainer.Trainer.predict

        Parameters:
        ----------
        batch: DataLoader
            The output of the data iterable.
        batch_idx: int
            The index of this batch.
        dataloader_idx: int
            The index of the dataloader.

        Return:
        -------
        Tensor - The model's predictions
        """
        return self(batch[0])
