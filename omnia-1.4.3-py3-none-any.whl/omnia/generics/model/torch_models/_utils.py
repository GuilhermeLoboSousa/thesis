from torch.nn import BCELoss, CrossEntropyLoss, BCEWithLogitsLoss, L1Loss, MSELoss, ReLU, Sigmoid, Softmax, Tanh
from torch.optim import (Adadelta, Adagrad, Adam, AdamW, SparseAdam, Adamax, ASGD, LBFGS, NAdam, RAdam, RMSprop, Rprop,
                         SGD)


TORCH_CRITERION = {
    # regression
    'mean_squared_error': MSELoss,
    'mean_absolute_error': L1Loss,
    # classification
    'binary_crossentropy': BCELoss,
    'binary_crossentropy_logits': BCEWithLogitsLoss,
    'categorical_crossentropy': CrossEntropyLoss,
    'sparse_categorical_crossentropy': CrossEntropyLoss
}

TORCH_OPTIMIZER = {
    'Adadelta': Adadelta,
    'Adagrad': Adagrad,
    'Adam': Adam,
    'AdamW': AdamW,
    'SparseAdam': SparseAdam,
    'Adamax': Adamax,
    'ASGD': ASGD,
    'LBFGS': LBFGS,
    'NAdam': NAdam,
    'RAdam': RAdam,
    'RMSprop': RMSprop,
    'Rprop': Rprop,
    'SGD': SGD,
}

# TODO: add remaining (https://pytorch.org/docs/stable/nn.html#non-linear-activations-weighted-sum-nonlinearity)
TORCH_ACTIVATION = {
    'relu': ReLU,
    'sigmoid': Sigmoid,
    'softmax': Softmax,
    'tanh': Tanh,
    'linear': None
}
