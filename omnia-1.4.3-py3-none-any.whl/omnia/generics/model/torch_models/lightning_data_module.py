from typing import Optional, Any, Union
import pytorch_lightning as pl
from omnia.generics.model.torch_models._torch_dataset import _to_tensor
from torch.utils.data import DataLoader, TensorDataset


class OmniaDataModule(pl.LightningDataModule):
    """
    A LightningDataModule for handling and preparing training and validation datasets.

    Parameters
    ----------
    x : Any
        The input training data.
    y : Any
        The target training data.
    batch_size : int
        The batch size for training and validation.
    x_val : Optional[Any], optional
        The input validation data, by default None.
    y_val : Optional[Any], optional
        The target validation data, by default None.
    """

    def __init__(self, x: Any, y: Any, batch_size: int, x_val: Optional[Any] = None, y_val: Optional[Any] = None):
        super(OmniaDataModule, self).__init__()
        self.x = x
        self.y = y
        self.batch_size = batch_size
        self.x_val = x_val
        self.y_val = y_val

    def prepare_data(self) -> None:
        """
        Prepare the training and validation datasets.
        This method is called only once.
        """
        x_tensor = _to_tensor(self.x)
        y_tensor = _to_tensor(self.y)
        x_val_tensor = _to_tensor(
            self.x_val) if self.x_val is not None else None
        y_val_tensor = _to_tensor(
            self.y_val) if self.y_val is not None else None

        train_dataset = TensorDataset(x_tensor, y_tensor)
        val_dataset = None
        if x_val_tensor is not None and y_val_tensor is not None:
            val_dataset = TensorDataset(x_val_tensor, y_val_tensor)
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset

    def train_dataloader(self) -> DataLoader:
        """
        An iterable or collection of iterables specifying training samples.
        """
        return DataLoader(self.train_dataset, batch_size=self.batch_size, shuffle=True)

    def val_dataloader(self) -> Union[DataLoader, list]:
        """
        An iterable or collection of iterables specifying validation samples.
        Returns [] if no validation data is provided, cannot be None.
        """
        return DataLoader(self.val_dataset, batch_size=self.batch_size, shuffle=False) if self.val_dataset else []
