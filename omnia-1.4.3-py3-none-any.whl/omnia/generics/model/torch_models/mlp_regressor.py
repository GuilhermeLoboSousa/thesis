from typing import List

import torch
from torch import nn
from omnia.generics.model import MultiOutputMixin, RegressorMixin
from omnia.generics.parameter import ModelParameter
from omnia.generics.model.torch_models import TorchModel
from omnia.generics.parameter.space import Real
from omnia.generics.setup.registry import class_register
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


class TorchMLPRegressor(nn.Module):
    """
    A PyTorch multi-layer perceptron regressor.

    Parameters
    ----------
    n_tasks: int
        The number of output tasks.
    num_layers: int
        The number of hidden layers.
    first_layer_output_dim: int
        The output dimension of the first layer.
    dropout_prob: float
        The dropout probability.
    use_batch_norm: bool
        Whether to use batch normalization.
    """

    def __init__(self, n_tasks: int, num_layers: int = 2,  first_layer_output_dim: int = 64,
                 dropout_prob: float = 0.0, use_batch_norm: bool = False, **kwargs):
        """
        Constructor for the TorchMLPRegressor class.
        """
        super(TorchMLPRegressor, self).__init__()
        self.n_tasks = n_tasks
        self.num_layers = num_layers
        self.first_layer_output_dim = first_layer_output_dim
        self.dropout_prob = dropout_prob
        self.use_batch_norm = use_batch_norm
        # Shared layers
        self.input_layer = nn.LazyLinear(self.first_layer_output_dim)
        # Define hidden layers
        self.hidden = nn.ModuleList()
        hidden_size = self.first_layer_output_dim
        for _ in range(self.num_layers):
            self.hidden.append(nn.Linear(hidden_size, hidden_size // 2))
            hidden_size = hidden_size // 2

        # Activation function
        self.act = nn.ReLU()

        hidden_size = self.first_layer_output_dim
        # Batch Normalization layers
        if self.use_batch_norm:
            self.batch_norm = nn.ModuleList()
            for _ in range(self.num_layers):
                hidden_size = hidden_size // 2
                self.batch_norm.append(nn.BatchNorm1d(hidden_size))

        # Dropout layer
        self.dropout = nn.Dropout(p=self.dropout_prob)

        # Output layers for each task
        self.output_layers = nn.ModuleList([
            nn.Sequential(nn.Linear(hidden_size, hidden_size//2),
                          nn.Linear(hidden_size//2, 1))
            for _ in range(n_tasks)
        ])

    def forward(self, X: torch.Tensor) -> List[torch.Tensor]:
        """
        Forward pass of the model.

        Parameters
        ----------
        X: torch.Tensor
            The input data.

        Returns
        -------
        outputs: List[torch.Tensor]
            The output data for each task.
        """
        # Forward pass through shared layers
        X = self.input_layer(X)
        for i in range(self.num_layers):
            X = self.hidden[i](X)
            X = self.act(X)
            if self.use_batch_norm:
                X = self.batch_norm[i](X)
            X = self.dropout(X)

        # Forward pass through output layers
        outputs = [output_layer(X) for output_layer in self.output_layers]
        return outputs


@class_register
class MLPRegressor(TorchModel, MultiOutputMixin, RegressorMixin):
    """
    A multi-task multi-layer perceptron regressor.

    Parameters
    ----------
    n_tasks: int
        The number of output tasks.
    num_layers: int
        The number of hidden layers.
    first_layer_output_dim: int
        The output dimension of the first hidden layer.
    dropout_prob: float
        The dropout probability.
    use_batch_norm: bool
        Whether to use batch normalization.
    loss: str
        The loss function to use.
        Options: 'mean_squared_error', 'mean_absolute_error'
    optimizer: str
        The optimizer to use.
        Options: 'Adadelta', 'Adagrad', 'Adam', 'AdamW', 'SparseAdam', 'Adamax', 'ASGD', 'LBFGS', 'NAdam', 'RAdam',
        'RMSprop', 'Rprop', 'SGD'
    learning_rate: float
        The learning rate to use.
    epochs: int
        The number of epochs to use.
    batch_size: int
        The batch size to use.

    Attributes
    ----------
    name: str
        The name of the model.
    model: TorchMLPRegressor
        The model itself.
    path: str
        The default path to save the model.
    tags: list
        The validation tags for the model.
    """
    name = 'MLPRegressor'
    model = TorchMLPRegressor
    # Number of output tasks
    n_tasks = ModelParameter(default=1, tunable=False)
    num_layers = ModelParameter(default=2, tunable=False)
    first_layer_output_dim = ModelParameter(default=64, tunable=False)
    dropout_prob = ModelParameter(
        default=0.0, tunable=True, space=Real(0.0, 1.0, default=0.0))
    use_batch_norm = ModelParameter(default=True, tunable=False)
    loss = ModelParameter(default='mean_squared_error', tunable=False)
    optimizer = ModelParameter(default='Adam', tunable=False)
    learning_rate = ModelParameter(
        default=0.01, tunable=True, space=Real(1e-6, 1e-2, default=0.01))
    epochs = ModelParameter(default=100, tunable=False)
    batch_size = ModelParameter(default=32, tunable=False)

    path = 'mlp_regressor/'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]
