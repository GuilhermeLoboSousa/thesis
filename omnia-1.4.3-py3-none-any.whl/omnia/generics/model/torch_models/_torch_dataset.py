from typing import Any

import torch
from torch.utils.data import Dataset

from omnia.generics import np, pd


def _to_tensor(data: Any) -> torch.Tensor:
    """
    Convert data to a PyTorch tensor.

    Parameters
    ----------
    data: Any
        The data to convert to a PyTorch tensor.

    Returns
    -------
    tensor: torch.Tensor
        The PyTorch tensor.
    """
    if isinstance(data, np.ndarray) or isinstance(data, list):
        return torch.tensor(data, dtype=torch.float32)
    elif isinstance(data, pd.DataFrame) or isinstance(data, pd.Series):
        return torch.tensor(data.values, dtype=torch.float32)
    else:
        raise ValueError(
            "Unsupported data type. Must be NumPy array, pandas DataFrame, pandas Series, or list.")


class TorchDataset(Dataset):
    """
    A PyTorch dataset.
    Provides an interface to the data for training and evaluation.
    """

    def __init__(self, X: Any, y: Any = None):
        """
        The dataset constructor.

        Parameters
        ----------
        X: Any
            The input data.
        y: Any
            The target variable.
        """
        self.X = _to_tensor(X)
        self.y = _to_tensor(y) if y is not None else None

    def __len__(self) -> int:
        """
        Get the length of the dataset.

        Returns
        -------
        length: int
            The length of the dataset.
        """
        return len(self.X)

    def __getitem__(self, idx: int) -> (torch.Tensor, torch.Tensor):
        """
        Get an item from the dataset.

        Parameters
        ----------
        idx: int
            The index of the item to get from the dataset.

        Returns
        -------
        item: (torch.Tensor, torch.Tensor)
            The input data and target variable at the given index.
        """
        if self.y is not None:
            return self.X[idx], self.y[idx]
        else:
            return self.X[idx], None
