from abc import ABCMeta, abstractmethod
from typing import Any, Callable, Dict, List, Literal, TYPE_CHECKING, Union

from ._model_parameters import ModelParametersMixIn
from ._model_validate import ModelValidateMixIn
from omnia.generics import np, pd
from omnia.generics.evaluate import Evaluator
from omnia.generics.utils import infer_problem_type
from omnia.generics.utils.constants import BINARY, MULTICLASS, REGRESSION
from omnia.generics import np
from omnia.generics.validation.data_tag import DataTag

if TYPE_CHECKING:
    from omnia.generics.utils.metrics import _METRICS

    _METRIC_VALUES = Literal[_METRICS.keys()]


class Model(ModelParametersMixIn, ModelValidateMixIn, metaclass=ABCMeta):
    """
    Base class for all models in omnia. Child classes should implement the following methods:
    - _fit: fit the model to the data
    - _predict: make predictions on new data
    - _predict_proba: make probability predictions on new data
    - evaluate: evaluate the model on a dataset
    - save: save the model to a file
    - load: load the model from a file
    """
    _fitted = False
    _problem_type = None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, '_input_type'):
            raise TypeError(
                f"Class {cls.__name__} must define '_input_type' attribute")
        if not hasattr(cls, '_estimator_type'):
            raise TypeError(
                f"Class {cls.__name__} must define '_estimator_type' attribute")
        if not hasattr(cls, 'path'):
            raise TypeError(
                f"Class {cls.__name__} must define 'path' attribute")

    def fit(self, x: Any, y: Any, x_val: Any = None, y_val: Any = None, problem_type: str = None, **kwargs) -> 'Model':
        """
        Fit the model to the data. It sets the _fitted attribute to True if the model is successfully fitted.

        Parameters
        ----------
        x: Any
            The input data to fit the model.
        y: Any
            The target variable to fit the model.
        x_val: Any
            The input data to validate the model.
        y_val: Any
            The target variable to validate the model.
        problem_type: str
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"
        kwargs: dict
            Additional parameters to pass to the fit method.
        """
        if y is not None and (isinstance(y, np.ndarray) or isinstance(y, pd.DataFrame)):
            self._problem_type = problem_type or infer_problem_type(y)
            assert self._problem_type in [BINARY, MULTICLASS, REGRESSION], \
                (f"Unsupported problem type: {self._problem_type}. Supported problem types are: {BINARY}, {MULTICLASS}, "
                 f"{REGRESSION}.")
        self._fit(x, y, x_val, y_val, **kwargs)
        self._fitted = True
        return self

    @ abstractmethod
    def _fit(self, x: Any, y: Any, x_val: Any = None, y_val: Any = None, **kwargs) -> 'Model':
        """
        Fit the model to the data. This method should be implemented by the child class.

        Parameters
        ----------
        x: Any
            The input data to fit the model.
        y: Any
            The target variable to fit the model.
        x_val: Any
            The input data to validate the model.
        y_val: Any
            The target variable to validate the model.
        kwargs: dict
            Additional parameters to pass to the fit method.
        """
        ...

    @ property
    def fitted(self) -> bool:
        """
        Check if the model has been fitted.

        Returns
        -------
        bool
            True if the model has been fitted, False otherwise.
        """
        return self._fitted

    def predict(self, x: Any) -> np.array:
        """
        Make predictions on new data.

        Parameters
        ----------
        x: Any
            The input data to make predictions on.

        Returns
        -------
        y_pred: Any
            The predictions on the input data.
        """
        if not self._fitted:
            raise ValueError('Model has not been fitted yet.')
        return self._predict(x)

    @ abstractmethod
    def _predict(self, x: Any) -> np.array:
        """
        Make predictions on new data. This method should be implemented by the child class.

        Parameters
        ----------
        x: Any
            The input data to make predictions on.

        Returns
        -------
        y_pred: np.array
            The predictions on the input data.
        """
        ...

    @ property
    def can_predict_proba(self) -> bool:
        """
        Check if the model can predict probabilities.
        It verifies if the model has a _can_predict_proba attribute.

        Returns
        -------
        bool
            True if the model can predict probabilities, False otherwise.
        """
        if hasattr(self, '_can_predict_proba'):
            return self._can_predict_proba
        return False

    def predict_proba(self, x: Any) -> np.array:
        """
        Make probability predictions on new data.

        Parameters
        ----------
        x: Any
            The input data to make probability predictions on.

        Returns
        -------
        y_pred: np.array
            The probability predictions on the input data.
        """
        if not self.can_predict_proba:
            raise ValueError('Model cannot predict probabilities.')
        return self._predict_proba(x)

    @ abstractmethod
    def _predict_proba(self, x: Any) -> np.array:
        """
        Make probability predictions on new data. This method should be implemented by the child class.

        Parameters
        ----------
        x: Any
            The input data to make probability predictions on.

        Returns
        -------
        y_pred: np.array
            The probability predictions on the input data.
        """
        ...

    @ property
    def problem_type(self) -> str:
        """
        Get the problem type of the model.

        Returns
        -------
        str
            The problem type of the model.
        """
        return self._problem_type

    def evaluate(self, x: Any, y: Any, metrics: Union[str, Callable, List[Union[str, Callable]]],
                 per_task_metrics: bool = False, w: Any = None, **kwargs) -> Dict[str, float]:
        """
        Evaluates the performance of this model on specified dataset.

        This function uses `Evaluator` under the hood to perform model
        evaluation.

        Keyword arguments specified here will be passed to
        `Evaluator.compute_model_performance`.

        Parameters
        ----------
        x: Any
            The input data to evaluate the model.
        y: Any
            The target variable to evaluate the model.
        metrics: Union[str, Callable, List[str], List[Callable]]
            The metric(s) to use to evaluate the model.
            Should be one of the following:
                - "accuracy"
                - "balanced_accuracy"
                - "f1"
                - "precision"
                - "recall"
                - "roc_auc"
                - "jaccard_score"
                - "log_loss"
                - "mean_squared_error"
                - "mean_absolute_error"
                - "r2"
                - "root_mean_squared_error"
                - "mean_absolute_percentage_error"
                - "mean_squared_log_error"
                - "median_absolute_error"
            or a callable that takes in `y_true` and `y_pred` as arguments.
        kwargs: dict
            Additional parameters to pass to the metric function.
        per_task_metrics: bool, optional (default False)
            If true, return computed metric for each task on multitask dataset.
        w: Any, optional
            Sample weights to pass to the metric function.
        Returns
        -------
        scores: dict
            Dictionary mapping names of metrics to metric scores. If
            per_task_metrics is True, each metric will map to a list of
            scores, one for each task.
        """
        evaluator = Evaluator(self, x, y, w)
        return evaluator.compute_model_performance(metrics=metrics, per_task_metrics=per_task_metrics, **kwargs)

    @ abstractmethod
    def save(self) -> None:
        """
        Save the model to a file. This method should be implemented by the child class.
        """
        ...

    @ classmethod
    @ abstractmethod
    def load(cls, path: str) -> 'Model':
        """
        Load the model from a file. This method should be implemented by the child class.

        Parameters
        ----------
        path: str
            The path to the file to load the model from.

        Returns
        -------
        model: Model
            The model loaded from the file.
        """
        ...

    @property
    def input_type(self) -> DataTag:
        """
        Get the input type of the model.

        Returns
        -------
        DataTag
            The input type of the model.
        """
        return self._input_type

    @property
    def estimator_type(self) -> str:
        """
        Get the estimator type of the model.

        Returns
        -------
        str
            The estimator type of the model.
        """
        return self._estimator_type


class ClassifierMixin:
    """
    Mixin class for classifiers. It provides a score method to evaluate the model on a dataset.
    """
    _estimator_type = "classifier"
    _tags = []  # add omnia validation tags when validation is operational

    def score(self, x: Any, y: Any, sample_weight: Any = None, threshold: float = 0.5) -> float:
        """
        Evaluate the model on a dataset using the accuracy metric.

        Parameters
        ----------
        x: Any
            The input data to evaluate the model.
        y: Any
            The target variable to evaluate the model.
        sample_weight: Any
            Sample weights to pass to the accuracy metric.
        threshold: float
            The threshold to use for binary classification metrics.

        Returns
        -------
        score: float
            The accuracy score of the model on the input data.
        """
        from sklearn.metrics import accuracy_score
        predictions = self.predict(x)
        # only for binary classification
        if all(0 <= p <= 1 for p in predictions.flatten()):
            predictions = (predictions > threshold).astype(int)
        if y.shape != predictions.shape:
            predictions = predictions.reshape(y.shape)
        return accuracy_score(y, predictions, sample_weight=sample_weight)

    @ property
    @ abstractmethod
    def _can_predict_proba(self) -> bool:
        """
        Check if the model can predict probabilities. This method should be implemented by the child class.

        Returns
        -------
        bool
            True if the model can predict probabilities, False otherwise.
        """
        ...


class RegressorMixin:
    _estimator_type = "regressor"
    _tags = []  # add omnia validation tags when validation is operational

    def score(self, x: Any, y: Any, sample_weight: Any = None) -> float:
        """
        Evaluate the model on a dataset using the r2 metric.

        Parameters
        ----------
        x: Any
            The input data to evaluate the model.
        y: Any
            The target variable to evaluate the model.
        sample_weight: Any
            Sample weights to pass to the r2 metric.

        Returns
        -------
        score: float
            The r2 score of the model on the input data.
        """
        from sklearn.metrics import r2_score
        predictions = self.predict(x)
        if y.shape != predictions.shape:
            predictions = predictions.reshape(y.shape)
        return r2_score(y, predictions, sample_weight=sample_weight)

    @ staticmethod
    def can_predict_proba() -> bool:
        """
        Returns
        -------
        bool
            False, since regressors cannot predict probabilities.
        """
        return False


class MultiOutputMixin:
    """
    Mixin class for multioutput models.
    """
    _estimator_type = "multioutput"
    _tags = []  # add omnia validation tags when validation is operational
