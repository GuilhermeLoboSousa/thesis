from .model import Model, ClassifierMixin, RegressorMixin, MultiOutputMixin
from omnia.generics.model.autogluon_models.ag_model import AutoGluonBaseModel, AutoGluonModel
from .autogluon_models import (RandomForestModel,
                               MultilayerPerceptronNN,
                               CatBoostModel,
                               KNNModel,
                               LGBModel,
                               LinearModel,
                               FastAINN,
                               VowpalWabbitModel,
                               XGBoostModel,
                               XTModel,
                               SupportVectorMachineModel)
from omnia.generics.model.sklearn_models.sk_model import ScikitLearnBaseModel
from .sklearn_models import (GradientBoostingClassifier,
                             RandomForestClassifier,
                             LogisticRegression,
                             LinearRegression,
                             MultiTaskLassoRegressor)
from omnia.generics.model.torch_models.torch_model import TorchModel
from .torch_models import (MLPClassifier,
                           MLPRegressor)
from omnia.generics.model.keras_models.keras_models import KerasModel
from .keras_models import (  # TabularTransformerRegressor, TabularTransformerClassifier,
    CNN1DModelClassifier,
    CNN1DModelRegressor, RNNModelClassifier, RNNModelRegressor,
    AutoEncoderMLPClassifier, AutoEncoderMLPRegressor, ConvRNNModelClassifier,
    ConvRNNModelRegressor)
