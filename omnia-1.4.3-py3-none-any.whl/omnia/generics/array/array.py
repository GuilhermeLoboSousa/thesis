from types import ModuleType
from typing import Optional

array_libs = {}

try:
    import cupy as cp
    array_libs['cupy'] = cp
except ImportError:
    cp = None

try:
    import numpy as np
    array_libs['numpy'] = np
except ImportError:
    np = None


default_array_lib = None


def get_default_array() -> Optional[str]:
    """
    It returns the name of the default array library.

    Returns
    --------
    array_lib : str
        The default array library name (currently available: 'cupy', 'numpy')
    """

    global default_array_lib
    array_lib_order = ['cupy', 'numpy']

    if not default_array_lib:
        for array_lib in array_lib_order:
            if array_lib in array_libs:
                default_array_lib = array_lib
                break

        if not default_array_lib:
            raise RuntimeError("No array library available.")

    return default_array_lib


def set_default_array(array_lib: str) -> None:
    """
    It sets default array library.

    Parameters
    -----------
    array_lib : str
        The array library name (currently available: 'cupy', 'numpy')

    Returns
    --------
    """

    global default_array_lib

    array_lib = array_lib.lower()

    if array_lib in array_libs:
        default_array_lib = array_lib
    else:
        raise RuntimeError(f"array library {array_lib} not available.")


def array_instance() -> ModuleType:
    """
    It returns the selected array library.

    Returns
    --------
    array_lib : ModuleType
        The default array library name (currently available: 'cupy', 'numpy')
    """

    array_name = get_default_array()

    if array_name:
        return array_libs[array_name]


np = array_instance()
