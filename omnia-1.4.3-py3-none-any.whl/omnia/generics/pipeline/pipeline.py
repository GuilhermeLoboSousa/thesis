import logging
import os
import warnings
from datetime import datetime
from pathlib import Path
from typing import Callable, List, Dict, Any, Tuple, Union

import sklearn.base

from omnia.generics.io import write_pickle, read_pickle
from omnia.generics.model import Model, AutoGluonBaseModel, AutoGluonModel
from omnia.generics.parameter import Parameter
from omnia.generics.prediction import TabularPredictor, MultiLabelTabularPredictor
from omnia.generics.prediction.predictor import Predictor
from omnia.generics.setup import setup_estimator, get_estimator
from omnia.generics.transformation import Transformer, SklearnWrapper
from omnia.generics.utils import is_transformer, is_predictor, is_model
from omnia.generics.utils.importing import get_class
from ._utils import _attribute_lookup, _item_lookup, _read_pipeline_configuration, _write_pipeline_configuration
from omnia.generics.utils.function_transformer import PassthroughTransformer


class Pipeline(Transformer,
               name='Pipeline',
               category='pipeline',
               register=True):
    """
    Pipeline is a transformer that applies a list of transformers in sequence.
    The final step of the pipeline can be a predictor which is used to make predictions.
    The intermediate steps of the pipeline must be transformers only.
    That is, they must implement the fit and transform methods.
    If the final step is a predictor, it must implement the predict method.
    Otherwise, an error is raised when calling predict.

    Pipeline can be used to combine multiple transformers and predictors in a single transformer.
    Thus, custom pipelines can be created to process/fit input data in a specific way and then predict on new data.

    Note that, the fit method also calls the transform method of all intermediate steps to transform the input data.
    Only the last step of the pipeline is fitted without transforming the data.

    Parameters
    ----------
    steps : List[Tuple[str, Union[Transformer, TabularPredictor, MultiLabelTabularPredictor]]]
        List of transformers to apply in sequence. List of tuples (name, transformer) that will be chained in order.
        The final step of the pipeline can be a predictor which is used to make predictions.
        The intermediate steps of the pipeline must be transformers only.

    path : str, optional (default=None)
        Path to save the pipeline. If None, a time-stamped folder called "omnia-pipeline-[TIMESTAMP]"
        could have been created in the working directory to store all models.

    Examples
    --------
    >>> from omnia.generics import pd, Pipeline, TabularPredictor
    >>>
    >>> pipeline = Pipeline(steps=[('predictor', TabularPredictor())])
    >>> pipeline.fit(pd.DataFrame({'a': ['111', '2167441', '3611']}), pd.DataFrame({'c': [7, 8, 9]}))
    >>> pipeline.predict(pd.DataFrame({'a': ['111', '2167441', '3611']}))
    """

    steps: List[Tuple[str, Union[Transformer, TabularPredictor, MultiLabelTabularPredictor, Model]]] = (
        Parameter(default=[],
                  tunable=False))

    path: str = Parameter(default=None, tunable=False)

    def _set_parameters(self, **kwargs):
        """
        The internal initializer of the estimator.
        It sets the parameters of the estimator using the kwargs and data descriptors.

        Parameters
        ----------
        kwargs : dict
            The parameters of the estimator.
        """
        descriptors = self._get_parameters()

        for name, descriptor in descriptors.items():
            value = kwargs.pop(name, descriptor.default)
            if name == 'steps':
                for i in range(len(value)):
                    if isinstance(value[i][1], sklearn.base.BaseEstimator):
                        value[i] = (value[i][0], SklearnWrapper(value[i][1]))
            setattr(self, name, value)

        if kwargs:
            cls_name = self.__class__.__name__
            raise TypeError(
                f'{cls_name} got unexpect keyword arguments: {kwargs.keys()}')

    def __getattr__(self, item) -> Union[Transformer, TabularPredictor, MultiLabelTabularPredictor, Model, Any]:
        """
        Method to access dynamic attributes of the pipeline.
        This method tries to perform lazy attribute access to one of the following items in the pipeline:
            1. steps/transformers/predictor
            2. transformers' parameters or estimated parameters

        The lookup can be performed as follows:
            1. pipeline.step_name
            2. pipeline.step_name.parameter_name
            3. pipeline.step_name__parameter_name
            4. pipeline.step_name__estimated_parameter_name

        Parameters
        ----------
        item: str
            The attribute name to be accessed.

        Returns
        -------
        value: Any
            The value of the pipeline attribute or the value of the parameter in a given step.

        Raises
        ------
        AttributeError
            If the attribute is not found.
        """
        transformers = self.steps_to_dict()
        value = _attribute_lookup(transformers, item)
        return value

    def __getitem__(self, item) -> Union[Transformer, TabularPredictor, Model, List[Transformer],
                                         List[TabularPredictor], List[Model],
                                         List[Union[Transformer, TabularPredictor]],
                                         List[Union[Transformer, Model]], Any]:
        """
        Returns the transformer or predictor at the given index or key.
        This method tries to perform transformers lookup using indexes, slices or key.
        If the index is out of range, an IndexError is raised.
        If the key is not found, a KeyError is raised.

        Parameters
        ----------
        item: int, slice, str
            The index, slice or key to look up.

        Returns
        -------
        value: Any
            The transformer or predictor at the given index or key.

        Raises
        ------
        IndexError
            If the index is out of range.

        KeyError
            If the key is not found.
        """
        value = _item_lookup(self.steps, item)
        return value

    def steps_to_dict(self) -> Dict[str, Transformer]:
        """
        Returns a dictionary with the step name and the transformer.

        Returns
        -------
        steps_dict: Dict[str, Transformer]
            A dictionary containing the step name and the transformer.
        """
        return {name: transformer for name, transformer in self.steps}

    @property
    def fitted(self) -> bool:
        """
        It returns True if the pipeline is fitted, False otherwise.

        Returns
        -------
        fitted : bool
            True if the model is fitted, False otherwise.
        """
        return all(step[1].fitted for step in self.steps)

    @property
    def parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the parameters of all transformers as a dict of dicts.

        Returns
        -------
        parameters : Dict[Dict[str, Any]]
            The parameters of the transformers.
        """
        return {name: transformer.parameters for name, transformer in self.steps
                if is_transformer(transformer)}

    @property
    def estimated_parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the estimated parameters of all transformers as a dict of dicts.

        Returns
        -------
        estimated_parameters : Dict[Dict[str, Any]]
            The estimated parameters of the transformers.
        """
        return {name: transformer.estimated_parameters for name, transformer in self.steps
                if is_transformer(transformer)}

    @property
    def tags(self):
        """
        Return the tags of the used transformers that will be used to validate the input data.

        Returns
        -------
        tags : list
            The list of tags for the transformers.
        """
        all_tags = set()
        for _, transformer in self.steps:
            all_tags.update(transformer.validation_property.input_tag)
        return list(all_tags)

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        Validates the input data.
        As the validation of composite transformers, heterogeneous data, or datatype changes is difficult to validate,
        this method will only check if the input data is valid for the first transformer.

        Parameters
        ----------
        x : Any, optional
            The input data to validate.
        y : Any, optional
            The target data to validate.

        Returns
        -------
        valid : bool
            True if the input data is valid, False otherwise.
        """
        # TODO: the validation is not working properly, perhaps because some transformers are not correctly tagged
        # return self.steps[0][1].validate(x, y)
        return True

    def fit(self,
            x: Any,
            y: Any = None,
            x_val: Any = None,
            y_val: Any = None,
            problem_type: str = None) -> 'Pipeline':
        """
        Fits the pipeline.
        This method fits the first transformer in the pipeline.

        Parameters
        ----------
        x : pd.Series, Any
            The input data to fit.

        y : pd.Series, Any, optional
            The target data to fit.

        x_val : pd.Series, Any, optional
            The input data to validate.

        y_val : pd.Series, Any, optional
            The target data to validate.
        problem_type: str
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        self : Pipeline
            The fitted pipeline.
        """
        if (self.is_predictor() or self.is_model()) and y is None:
            raise ValueError("Predictor-like pipelines must have a target.")

        if (self.is_predictor() or self.is_model()) and x_val is not None and y_val is None:
            raise ValueError("Validation data is only supported for predictor-like pipelines "
                             "(the last step must be a predictor). Both Y and Y_val must be provided.")

        if (not self.is_predictor() and not self.is_model()) and x_val is not None and y_val is not None:
            raise ValueError("Validation data is only supported for predictor-like pipelines "
                             "(the last step must be a predictor).")

        if x_val is not None and y_val is not None:
            self._fit_train_and_validation(x, y, x_val, y_val, problem_type)
            return self

        self._fit(x, y, problem_type)
        return self

    def _fit_transform_data(self, x: Any, y: Any = None) -> Tuple[Any, Any]:
        """
        Fits the first steps of the pipeline and transforms the data.

        Parameters
        ----------
        x : Any
            The input data to fit and transform.

        y : Any, optional
            The target data to fit and transform.

        Returns
        -------
        x_transformed : Any
            The transformed data.

        y_transformed : Any, optional
            The transformed target data.
        """
        for name, transformer in self.steps[:-1]:
            # TODO: the validation is not working properly, perhaps because some transformers are not correctly tagged
            # is_valid = transformer.validate(x, y)
            # if not is_valid:
            #     raise ValueError(f'Step {name} could not been validated against the input data!')

            x, y = transformer.fit_transform(x, y)

        return x, y

    def _fit_train_and_validation(self,
                                  x: Any,
                                  y: Any,
                                  x_val: Any,
                                  y_val: Any,
                                  problem_type: str = None) -> 'Pipeline':
        """
        Fits the pipeline with validation data.
        This method fits and transforms first the validation data.
        Then, it fits the rest of the pipeline.

        Parameters
        ----------
        x : Any
            The input data to fit.

        y : Any
            The target data to fit.

        x_val : Any
            The input data to validate.

        y_val : Any
            The target data to validate.
        problem_type: str
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        self : Pipeline
            The fitted pipeline.
        """
        self._validate_steps()

        x, y = self._fit_transform_data(x, y)

        x_val, y_val = self._transform(x_val, y_val)

        if self.is_predictor() or self.is_model():
            self.steps[-1][1].fit(x=x, y=y, x_val=x_val,
                                  y_val=y_val, problem_type=problem_type)
            return self
        self.steps[-1][1].fit(x, y)
        return self

    def _fit(self, x: Any, y: Any = None, problem_type: str = None):
        """
        Fits all transformers to "x" and "y".

        Parameters
        ----------
        x: Any
            The data to transform.
        y: Any
            The target variable to try to predict in the case of supervised learning.
        problem_type: str
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        self : Transformer
            The fitted transformers.
        """
        # for index, step in enumerate(self.steps):
        #     if isinstance(step[1], sklearn.base.BaseEstimator):
        #         self.steps[index] = (step[0], SklearnWrapper(step[1]))
        self._validate_steps()

        for name, transformer in self.steps[:-1]:
            # TODO: the validation is not working properly, perhaps because some transformers are not correctly tagged
            # is_valid = transformer.validate(x, y)
            # if not is_valid:
            #     raise ValueError(f'Step {name} could not been validated against the input data!')

            x, y = transformer.fit_transform(x, y)

        if self.is_predictor() or self.is_model():
            # TODO: the validation is not working properly, perhaps because some transformers are not correctly tagged
            # is_valid = self.steps[-1][1].validate(x, y)
            # if not is_valid:
            #     raise ValueError(f'Step {name} could not been validated against the input data!')
            self.steps[-1][1].fit(x, y, problem_type=problem_type)
            return self
        self.steps[-1][1].fit(x, y)
        return self

    def _transform(self, x: Any, y: Any = None):
        """
        Transform the input data (x, y) based on the estimated parameters during the transformers fit.

        Parameters
        ----------
        x: Any
            The data to transform.
        y: Any
            The target variable to try to predict in the case of supervised learning.

        Returns
        -------
        Any
            The concatenated Any.
        """
        for name, transformer in self.steps[:-1]:
            x, y = transformer.transform(x, y)

        if self.is_predictor() or self.is_model():
            return x, y

        return self.steps[-1][1].transform(x, y)

    def predict(self, x: Any, model: str = None) -> Any:
        """
        It predicts the target variable for the given data.
        In detail, it calls `predict` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.

        Returns
        -------
        y_pred : Any
            The predicted target variable.
        """
        if self.is_predictor():
            x, _ = self.transform(x)
            return self.steps[-1][1].predict(x, model)
        if self.is_model():
            x, _ = self.transform(x)
            return self.steps[-1][1].predict(x)
        raise ValueError('This transformer is not a predictor!')

    def predict_proba(self, x: Any, model: str = None) -> Any:
        """
        It predicts the probabilities of the target variable for the given data.
        In detail, it calls `predict_proba` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.

        Returns
        -------
        y_pred : Any
            The predicted probabilities of the target variable.
        """
        if self.is_predictor():

            # transform the data first
            x, _ = self.transform(x)

            # get predictor
            predictor = self.steps[-1][1]

            # check if the model can predict probabilities
            if predictor.can_predict_proba:
                return predictor.predict_proba(x, model)

            return predictor.predict(x, model)
        if self.is_model():

            # transform the data first
            x, _ = self.transform(x)

            # get model
            model = self.steps[-1][1]

            # check if the model can predict probabilities
            if model.can_predict_proba:
                return model.predict_proba(x)

            return model.predict(x)

        raise ValueError('This transformer is not a predictor!')

    def leaderboard(self, x: Any = None, y: Any = None) -> Any:
        """
        It returns the leaderboard according to the fit process or for the given data.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.

        Returns
        -------
        leaderboard : Any
            The leaderboard.
        """
        if self.is_predictor():
            if x is not None:
                x, y = self.transform(x, y)
            return self.steps[-1][1].leaderboard(x, y)
        if self.is_model():
            raise ValueError(
                'The leaderboard method is not available for models!')
        raise ValueError('This transformer is not a predictor!')

    def score(self, x: Any, y: Any, model: str = None, metrics: Union[str, Callable, List[Union[str, Callable]]] = None,
              per_task_metrics: bool = False, **kwargs) -> Dict[str, float]:
        """
        It returns the score of the given model.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.
        metrics : str, Callable, List[Union[str, Callable]], optional (default=None)
            The metrics to evaluate the model.
        per_task_metrics : bool, optional (default=False)
            If True, return computed metric for each task on multitask dataset.

        Returns
        -------
        scores: dict
            Dictionary mapping names of metrics to metric scores. If
            per_task_metrics is True, each metric will map to a list of
            scores, one for each task.
        """
        if metrics is not None:
            if not isinstance(metrics, list):
                metrics = [metrics]
        if self.is_predictor():
            metric_names = []
            for metric in metrics:
                if hasattr(metric, '__name__'):
                    metric_names.append(metric.__name__)
                else:
                    metric_names.append(metric)

            x, y = self.transform(x, y)
            return {metric: self.steps[-1][1].score(x, y, model).get(metric, None) for metric in metric_names}
        if self.is_model():
            x, y = self.transform(x, y)
            return self.steps[-1][1].evaluate(x, y, metrics=metrics, per_task_metrics=per_task_metrics, **kwargs)
        raise ValueError('This transformer is not a predictor or a model!')

    @property
    def best_model(self) -> Union[str, Dict[str, str]]:
        """
        It returns the best model name.

        Returns
        -------
        best_model : str
            The best model name.
        """
        if self.is_predictor():
            return self.steps[-1][1].best_model
        if self.is_model():
            return self.steps[-1][1]
        raise ValueError('This transformer is not a predictor!')

    def _set_paths(self):
        """
        It sets the paths for the transformers and predictor.
        """
        if self.path is None:
            current_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
            self.path = os.path.join(
                os.getcwd(), f'omnia-pipeline-{current_time}')

        if not os.path.exists(self.path):
            Path(self.path).mkdir(parents=True, exist_ok=True)

        if self.is_predictor() or self.is_model():

            if self.steps[-1][1].path == self.path:
                return

            self.steps[-1][1].path = self.path

        return

    def _validate_steps(self):
        """
        Pipeline steps validation:
            1. The first step must be a transformer unless it is one step long.
            2. The last step must be a transformer or predictor.
            3. The number of steps must be greater than 1.
            4. The number of steps must be equal to the number of transformers.
            5. The steps must be unique.
            6. The pipeline path is created or validated

        Raises
        ------
        ValueError
            If the number of steps is not greater than 0.
            If the number of steps differs from the number of transformers/predictor
            If the steps are not unique
            If the first step is not a transformer
            If the last step is not a transformer or predictor
        """
        if len(self.steps) < 1:
            raise ValueError("The number of steps must be greater than 0.")

        names, transformers = zip(*self.steps)
        if len(names) != len(transformers):
            raise ValueError(
                "The number of names and transformers must be the same.")

        if len(names) != len(set(names)):
            raise ValueError("The names must be unique.")

        # previous_output = None
        for i, transformer in enumerate(transformers):
            if i == 0 and len(transformers) > 1:
                if not is_transformer(transformer):
                    raise ValueError("The first step must be a transformer.")
            else:
                if not is_transformer(transformer) and not is_predictor(transformer) and not is_model(transformer):
                    raise ValueError(
                        "The last step must be a transformer or predictor.")

            # if previous_output is not None:
            #     is_compatible = transformer.is_tag_compatible(previous_output)
            #     if not is_compatible:
            #         raise ValueError(f"The output of the previous step is not compatible with the "
            #                          f"input of the current step {transformer.name}.")
            # if i != len(transformers) - 1:
            #     previous_output = transformer.validation_property.output_tag

        self._set_paths()

    def is_predictor(self) -> bool:
        """
        It returns True if the last step is a predictor.

        Returns
        -------
        is_predictor : bool
            True if the last step is a predictor.
        """
        return isinstance(self.steps[-1][1], Predictor)

    def is_model(self) -> bool:
        """
        It returns True if the last step is a model.

        Returns
        -------
        is_model : bool
            True if the last step is a model.
        """
        return isinstance(self.steps[-1][1], Model) or isinstance(self.steps[-1][1], AutoGluonBaseModel) or \
            isinstance(self.steps[-1][1], AutoGluonModel)

    def to_pickle(self, file_path: str) -> bool:
        """
        It saves the pipeline to a pickle file.

        NOTE: This method saves all transformers and pipeline into the same pickle file.
        It does not save the predictor nor models.

        Parameters
        ----------
        file_path : str
            The path to the pickle file.

        Returns
        -------
        is_saved : bool
            True if the pipeline is saved.
        """
        state = self.__getstate__()
        state = {key: value for key, value in state.items() if key in [
            'steps', 'path', '_fitted']}

        if self.is_predictor() or self.is_model():
            warnings.warn('This method saves all transformers and pipeline into the same pickle file. '
                          'It does not save the predictor nor models.')

            state['steps'] = state['steps'][:-1]
            return write_pickle(file_path, state)

        return write_pickle(file_path, state)

    @classmethod
    def from_pickle(cls, file_path: str) -> 'Pipeline':
        """
        It loads the pipeline from a pickle file.

        Parameters
        ----------
        file_path : str
            The path to the pickle file.

        Returns
        -------
        pipeline : Pipeline
            The pipeline.
        """
        state = read_pickle(file_path)

        fitted = state.pop('_fitted', False)

        instance = cls(**state)
        instance._fitted = fitted
        return instance

    @classmethod
    def from_nni_hparams(cls, hparams: Dict[str, Any], problem_type: str = None, metric: str = None,
                         path: str = None) -> 'Pipeline':
        """
        It loads the pipeline from a nni hparams.

        Parameters
        ----------
        problem_type: str
            problem type of the pipeline (classification or regression to pass to TabularPredictor)
        metric: str
            metric to optimize (to pass to TabularPredictor)
        hparams : Dict[str, Any]
            The nni hyperparameters.
        path : str
            The path to the pipeline.

        Returns
        -------
        pipeline : Pipeline
            The pipeline.
        """
        steps = []
        for step, options in hparams.items():

            # cast to list if it is not
            if not isinstance(options, list):
                options = [options]

            # for the options in the step
            for option in options:

                # cast to the dict format ({'_name': 'name', 'param1': 'value1', ...})
                if not isinstance(option, dict):
                    option = {'_name': option}

                if option['_name'] == 'passthrough':
                    continue

                # get the class
                estimator_or_predictor_type = get_class(option['_name'])

                # get the params to initialize the class
                params = {param_name: param_value
                          for param_name, param_value in option.items()
                          if param_name != '_name'}

                # check if it is a predictor.
                # If so, we should take care of three things:
                #   - cast the models to their classes
                #   - add the problem_type
                #   - add the metric
                if is_predictor(estimator_or_predictor_type):
                    models = params.pop('models', None)

                    if models is None:
                        params['models'] = None

                    elif isinstance(models, list):
                        params['models'] = [
                            get_class(model) for model in models]

                    elif isinstance(models, dict):
                        params['models'] = {
                            get_class(model): model_params for model, model_params in models.items()}

                    else:
                        raise ValueError(
                            f"model must be None, list or a dict. Got {type(models)} instead.")

                    params['problem_type'] = problem_type
                    params['metric'] = metric

                steps.append((step, estimator_or_predictor_type(**params)))
                logging.info(
                    f"Step {step} with {option['_name']} and {params} have been added to the pipeline.")

        return cls(steps=steps, path=path)

    @classmethod
    def from_hp_params(cls, params: Dict[str, Any], problem_type: str = None, metric: str = None,
                       path: str = None, **kwargs) -> 'Pipeline':
        """
        It loads the pipeline from a hp params.

        Parameters
        ----------
        params : Dict[str, Any]
            The hp parameters.
        problem_type: str
            problem type of the pipeline (classification or regression to pass to TabularPredictor)
        metric: str
            metric to optimize (to pass to TabularPredictor)
        path : str
            The path to the pipeline.

        Returns
        -------
        pipeline : Pipeline
            The pipeline.
        """
        unordered_steps = []
        for step, step_params in params.items():
            # get step index
            idx = step_params['idx']

            # get the estimator params
            estimator_params = step_params['params']

            # get the estimator class name
            name = estimator_params.pop('name')

            if name == 'passthrough':
                continue

            # get the estimator class
            estimator_cls = get_estimator(name)

            # if it's a predictor initialize the models too
            if is_predictor(estimator_cls):
                models = estimator_params.pop('models', None)

                if models is None:
                    estimator_params['models'] = None

                elif isinstance(models, (list, tuple)):
                    estimator_params['models'] = [
                        get_estimator(model) for model in models]

                elif isinstance(models, dict):
                    estimator_params['models'] = {get_estimator(model): model_params
                                                  for model, model_params in models.items()}

                else:
                    raise ValueError(
                        f"models must be None, list or a dict. Got {type(models)} instead.")

                if estimator_params.get('problem_type') is None:
                    estimator_params['problem_type'] = problem_type

                if estimator_params.get('metric') is None:
                    estimator_params['metric'] = metric

                if name == MultiLabelTabularPredictor.name:
                    if not kwargs.get('labels'):
                        raise ValueError(
                            'labels must be provided for MultiLabelTabularPredictor')

                    estimator_params['labels'] = kwargs.get('labels')

                estimator = estimator_cls(**estimator_params)

            else:
                estimator = estimator_cls(**estimator_params)

            unordered_steps.append((idx, step, estimator))

        # order the steps and remove the step index
        steps = sorted(unordered_steps, key=lambda x: x[0])
        steps = [(step[1], step[2]) for step in steps]

        return cls(steps=steps, path=path)

    def to_dict(self) -> Dict[str, Any]:
        """
        It saves the pipeline to a dict.

        NOTE!!!
        This method saves all estimators, models and predictors into a dict together
        with the corresponding parameters. It does not save, however, estimated parameters, model weights,
        and the pipeline path.
        This dict object can be used to recreate a new fresh pipeline with the same configuration.
        To save the pipeline, one can use the `to_pickle` or `save` methods.

        Returns
        -------
        dict : Dict[str, Any]
            The pipeline as a dict.
        """
        state = {'name': self.name, 'parameters': {'steps': []}}
        for name, transformer in self.steps:
            state['parameters']['steps'].append((name, transformer.to_dict()))
        return state

    @classmethod
    def from_dict(cls, state: Dict, path: str = None) -> 'Pipeline':
        """
        It loads a new fresh pipeline with the configuration encoded into the dict object.

        Parameters
        ----------
        state : dict
            The pipeline as a dict.

        Returns
        -------
        pipeline : Pipeline
            The pipeline.
        """
        steps = []
        for name, step in state['parameters'].get('steps', []):
            if step['name'] == 'passthrough':
                transformer = PassthroughTransformer()
            else:
                transformer = setup_estimator(
                    name=step['name'], parameters=step['parameters'])
            steps.append((name, transformer))
        return cls(steps=steps, path=path)

    def save(self, resolve: bool = True) -> bool:
        """
        It saves the pipeline to a pickle file in the path specified by `self.path`.

        Parameters
        ----------
        resolve : bool, optional (default=True)
            If True, it resolves the absolute path to export the pipeline.

        Returns
        -------
        bool : bool
            True if the object is saved successfully.
        """
        if not self.fitted:
            self._set_paths()

        folder = Path(self.path)

        if resolve:
            folder = folder.resolve()

        config = {}
        for i, (name, transformer) in enumerate(self.steps):
            if is_transformer(transformer):

                transformer_file = f'pipeline-transformer-{i}.pkl'
                transformer_path = folder.joinpath(transformer_file)

                transformer.to_pickle(transformer_path)

                # path here is relative to the pipeline folder
                config[i] = {'name': name, 'is_transformer': True,
                             'path': transformer_file}

            else:
                transformer_file = transformer.name

                transformer.save()

                config[i] = {'name': name, 'is_transformer': False,
                             'path': transformer_file}

        _write_pipeline_configuration(folder, config)

        state = {'path': self.path, '_fitted': self._fitted}
        path = folder.joinpath('pipeline.pkl')
        return write_pickle(path, state)

    @classmethod
    def load(cls, path: str, resolve: bool = True) -> 'Pipeline':
        """
        It loads the object from a pickle file.

        Parameters
        ----------
        path : str
            The path to the pickle file.
        resolve : bool, optional (default=True)
            If True, it resolves the path to the pickle file.

        Returns
        -------
        Pipeline
            The loaded object.
        """
        folder = Path(path)

        if resolve:
            folder = folder.resolve()

        if not folder.is_dir():
            raise ValueError(
                'The path is not a folder! To load a pipeline, the path must be the pipeline folder.')

        if not folder.joinpath('pipeline.pkl').exists():
            raise ValueError(
                'The pipeline.pkl file is not found in the folder!')

        if not folder.joinpath('config.json').exists():
            raise ValueError(
                'The pipeline config.json file is not found in the folder!')

        config = _read_pipeline_configuration(folder)

        state = read_pickle(folder.joinpath('pipeline.pkl'))

        steps = {}
        for i, step in config.items():
            name = step['name']
            is_transformer_ = step['is_transformer']
            path_or_name = step['path']

            if is_transformer_:

                path_or_name = folder.joinpath(path_or_name)

                transformer = read_pickle(path_or_name)
                steps[i] = (name, transformer)

            else:
                predictor_cls = get_estimator(path_or_name)
                predictor = predictor_cls.load(folder)
                steps[i] = (name, predictor)

        steps = sorted(steps.items(), key=lambda x: x[0])
        steps = [step[1] for step in steps]

        fitted = state.pop('_fitted', False)

        instance = cls(**state)
        instance._fitted = fitted
        instance.steps = steps
        return instance


if __name__ == '__main__':
    import doctest

    doctest.testmod()
