from typing import Union, List, Tuple, Dict, Any

from joblib import Parallel, delayed

from omnia.generics.setup import setup_estimator
from omnia.generics.transformation.transformer import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from omnia.generics.utils.function_transformer import PassthroughTransformer
from omnia.generics.pipeline._utils import _columns_fit_one, _columns_transform_one, _df_indexing, _item_lookup, \
    _attribute_lookup
from omnia.generics.utils import is_transformer
from omnia.generics.validation import IsPandasX
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty


class FeatureTransformer(Transformer,
                         name='FeatureTransformer',
                         category='pipeline',
                         register=True):
    """
    The FeatureTransformer can be used to handle heterogeneous data.
    This transformer receives a list of transformers and the associated columns.
    Then, this transformer can fit and transform all these transformers to the input data only in the specified columns.
    Thus, it can be used to process and transform only a selection of the input data.

    Parameters
    ----------
    transformers : List[Tuple[Union[Transformer, str], Union[str, int, List[int], List[str], slice]]]
        List of transformers to be applied to the columns.

    n_jobs : int
        Number of parallel jobs to be used.

    Examples
    --------
    >>> from omnia.generics.pipeline.feature_transformer import FeatureTransformer
    >>> from omnia.generics.dataframe import pd

    >>> df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]})
    >>> ft = FeatureTransformer(transformers=[('passthrough', ['a', 'b'])])
    >>> ft.fit_transform(df)
       a  b
    0  1  2
    1  4  5
    2  7  8
    """
    transformers: List[Tuple[Union[Transformer, str], Union[str, int, List[int], List[str], slice]]] = \
        Parameter(default=[], tunable=False)

    n_jobs: int = Parameter(default=1, tunable=False)
    _validation_property = ValidationProperty(input_tag=IsPandasX, output_tag=IsPandasX)

    def __getattr__(self, item) -> Union[Transformer, Any]:
        """
        Method to access dynamic attributes of the feature transformer.
        This method tries to perform lazy attribute access to one of the following items in the feature transformer:
            1. transformers
            2. transformers' parameters or estimated parameters

        The lookup can be performed as follows:
            1. feature_transformer.transformer_name
            2. feature_transformer.transformer_name.parameter_name
            3. feature_transformer.transformer_name__parameter_name
            4. feature_transformer.transformer_name__estimated_parameter_name

        Parameters
        ----------
        item: str
            The attribute name to be accessed.

        Returns
        -------
        value: Any
            The value of the feature transformer attribute or the value of the parameter in a given step.

        Raises
        ------
        AttributeError
            If the attribute is not found.
        """
        transformers = self.transformers_to_dict()
        value = _attribute_lookup(transformers, item)
        return value

    def __getitem__(self, item) -> Union[Transformer,
                                         List[Transformer],
                                         Any]:
        """
        Returns the transformer or predictor at the given index or key.
        This method tries to perform transformers lookup using indexes, slices or key.
        If the index is out of range, an IndexError is raised.
        If the key is not found, a KeyError is raised.

        Parameters
        ----------
        item: int, slice, str
            The index, slice or key to look up.

        Returns
        -------
        value: Any
            The transformer or predictor at the given index or key.

        Raises
        ------
        IndexError
            If the index is out of range.

        KeyError
            If the key is not found.
        """
        transformers = list(self.transformers_to_dict().items())
        # noinspection PyTypeChecker
        value = _item_lookup(transformers, item)
        return value

    def transformers_to_dict(self) -> Dict[str, Transformer]:
        """
         Returns a dictionary with the name of the transformer and the transformer.

        Returns
        -------
        steps_dict: Dict[str, Transformer]
            A dictionary containing the name of the transformer and the transformer.
        """
        return {transformer.name: transformer for transformer, _ in self.transformers}

    @property
    def validation_property(self):
        """
        Sets the validation property of the feature transformer.
        """

        def _get_all_tags_together(list_of_tags):
            if len(list_of_tags) == 1:
                return list_of_tags[0]
            elif len(list_of_tags) > 1:
                final_tag = list_of_tags[0]
                for tag in list_of_tags[1:]:
                    final_tag = final_tag & tag
                return final_tag
            else:
                return all_input_tags

        all_input_tags = set()
        all_output_tags = set()
        for transformer, _ in self.transformers:
            all_input_tags.add(transformer.validation_property.input_tag)
            all_output_tags.add(transformer.validation_property.output_tag)

        all_input_tags = list(all_input_tags)
        all_output_tags = list(all_output_tags)

        input_tag = _get_all_tags_together(all_input_tags)
        output_tag = _get_all_tags_together(all_output_tags)

        if self._validation_property.input_tag is not None:
            self._validation_property.input_tag = self._validation_property.input_tag & input_tag
        else:
            self._validation_property.input_tag = input_tag

        if self._validation_property.output_tag is not None:
            self._validation_property.output_tag = self._validation_property.output_tag & output_tag
        else:
            self._validation_property.output_tag = output_tag

        return self._validation_property

    def validate(self, x: pd.DataFrame = None, y: pd.DataFrame = None) -> bool:
        """
        The validation method performs fast and straightforward checks to the data.
        It returns a boolean value indicating whether the data is valid or not.
        Parameters
        ----------
        x : pd.DataFrame, optional
            The data used to fit the model.
        y : pd.DataFrame, optional
            The target used to fit the model.

        Returns
        -------
        bool
            True if the value is valid, False otherwise.
        """
        validations = []
        for transformer, columns in self.transformers:

            try:
                data = _df_indexing(x, columns)
                validations.append(transformer.validate(data, y))
            except (ValueError, IndexError):
                validations.append(False)

        return all(validations)

    def _set_parameters(self, **kwargs):
        """
        Set the parameters of the features transformer.

        Parameters
        ----------
        **kwargs
            The parameters to set.

        """
        descriptors = self._get_parameters()

        for name, descriptor in descriptors.items():
            value = kwargs.pop(name, descriptor.default)

            if name == 'transformers':
                new_transformers = []

                for transformer, cols in value:
                    if isinstance(transformer, str) and transformer == 'passthrough':
                        transformer = PassthroughTransformer()
                        new_transformers.append((transformer, cols))

                    else:
                        new_transformers.append((transformer, cols))

                setattr(self, name, new_transformers)

            else:
                setattr(self, name, value)

        if kwargs:
            cls_name = self.__class__.__name__
            raise TypeError(f'{cls_name} got unexpect keyword arguments: {kwargs.keys()}')

    @property
    def parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the parameters of all transformers as a dict of dicts.
        Returns
        -------
        parameters : Dict[str, Dict[str, Any]]
            The parameters of the transformers.
        """
        return {transformer.name: transformer.parameters for transformer, _ in self.transformers}

    @property
    def estimated_parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the estimated parameters of all transformers as a dict of dicts.
        Returns
        -------
        estimated_parameters : Dict[str, Dict[str, Any]]
            The estimated parameters of the transformers.
        """
        return {transformer.name: transformer.estimated_parameters for transformer, _ in self.transformers}

    @staticmethod
    def _check_columns(columns: Union[str, int, List[int], List[str], slice],
                       x: pd.DataFrame) -> bool:
        """
        Checks if the columns is in the data.

        Parameters
        ----------
        columns: string, index, list of indices, list of strings, or slices
            indices to be used to index the dataframe
        x: pandas.DataFrame
            dataframe to be indexed

        Returns
        -------
        bool
            True if the columns is in the data, False otherwise.
        """
        try:
            _df_indexing(x, columns)
            return True
        except (ValueError, IndexError):
            return False

    def _validate_transformers_and_columns(self, x: pd.DataFrame):
        """
        A method to validate whether the inputted transformers implement a fit and a transform method
        and whether the columns are in the data.
        It also verifies that the transformers are not duplicated.

        Parameters
        ----------
        x: pd.DataFrame
            dataframe to be validated

        Raises
        ------
        TypeError
            If the transformers are not omnia transformers

        ValueError
            If the columns are not in the data
        """
        transformers = set()
        validations = []
        for transformer, columns in self.transformers:

            if not is_transformer(transformer):
                raise TypeError("The type of the transformers should be a Transformer.")

            else:
                transformers.add(transformer.name)

            validations.append(self._check_columns(columns, x))

        if len(transformers) != len(self.transformers):
            raise ValueError("The transformers should be unique.")

        if not all(validations):
            raise ValueError("The columns are not in the data.")

    def _parallel_func(self, x, y, func):
        """
        Helper function for parallelization.
        Parameters
        ----------
        x: pd.DataFrame
            The data to transform.
        y: pd.DataFrame
            The target variable to try to predict in the case of supervised learning.
        func: callable
            the function to parallelize.
        Returns
        -------
        list:
            List of "func" outputs.
        """
        parallel_callback = Parallel(n_jobs=self.n_jobs)
        return parallel_callback(delayed(func)(transformer, columns, x, y)
                                 for transformer, columns in self.transformers)

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Transformer:
        """
        Method to fit all the transformers

        Parameters
        ----------
        x: pd.DataFrame
            dataframe with the data to fit the transformers
        y: pd.DataFrame
            dataframe with the labels to fit the transformers

        Returns
        -------
        list of fitted transformers: List[Transformer]
        """
        # to validate columns content and if the transformers are actually transformers
        self._validate_transformers_and_columns(x)

        # transformers
        self._parallel_func(x, y, _columns_fit_one)
        self.features = [f"{transformer.name}_{feature}"
                         for transformer, _ in self.transformers
                         for feature in transformer.features]
        self.instances = list(x.index)
        return self

    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Method to transform data using fitted Transformers.

        Parameters
        ----------
        x: pd.DataFrame
            dataframe with the data to be transformed
        y: pd.DataFrame, optional
            dataframe with the labels to be transformed # actually I don't know if this makes sense.

        Returns
        -------
        transformed_x: pd.DataFrame
            transformed dataframe
        transformed_y: pd.DataFrame
            transformed dataframe
        """
        x = x.copy()
        index = x.index.copy()

        new_x, _ = zip(*self._parallel_func(x, y, _columns_transform_one))
        new_x = list(new_x)

        # TODO: verify the performance
        for i, df in enumerate(new_x):
            new_x[i] = df.add_prefix(self.transformers[i][0].name + '_')

        data = pd.concat(new_x, axis=1).reset_index(drop=True).set_index(index)
        return data, y

    def to_dict(self) -> Dict:
        """
        Converts the feature transformer to a dictionary.

        Returns
        -------
        ft: dict
            The dictionary representation of the feature transformer.
        """
        state = {'name': self.name, 'parameters': {'transformers': []}}
        for transformer, columns in self.transformers:
            if isinstance(transformer, PassthroughTransformer):
                state['parameters']['transformers'].append({'transformer': 'passthrough', 'columns': columns})

            else:
                state['parameters']['transformers'].append({'transformer': transformer.to_dict(), 'columns': columns})

        return state

    @classmethod
    def from_dict(cls, state: Dict) -> 'FeatureTransformer':
        """
        Converts the feature transformer from a dictionary.

        Parameters
        ----------
        state:
            The dictionary representation of the estimator.

        Returns
        -------
        ft: FeatureTransformer
            The feature transformer.
        """
        transformers = []
        for transformer in state['parameters'].get('transformers', []):
            if isinstance(transformer['transformer'], str):
                transformers.append((transformer['transformer'], transformer['columns']))

            else:
                columns = transformer['columns']
                transformer = transformer['transformer']
                transformer = setup_estimator(name=transformer['name'], parameters=transformer['parameters'])
                transformers.append((transformer, columns))

        return cls(transformers=transformers)


if __name__ == '__main__':
    import doctest

    doctest.testmod()
