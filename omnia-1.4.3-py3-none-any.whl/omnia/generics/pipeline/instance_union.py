from typing import List, Dict, Tuple, Any, Union

from joblib import Parallel, delayed

from omnia.generics.transformation import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from ._utils import _fit_one, _transform_one, _attribute_lookup, _item_lookup
from omnia.generics.setup import setup_estimator
from omnia.generics.utils import is_transformer
from ..validation import IsPandasX
from ..validation.boolean_operators.base_validator import BaseValidator
from ..validation.boolean_operators.operand_holders import OperandHolder
from ..validation.validation_properties.validation_property import ValidationProperty


class InstanceUnion(Transformer,
                    name='InstanceUnion',
                    category='pipeline',
                    register=True):
    """
    The InstanceUnion can be used to generate heterogeneous data.
    This transformer receives a list of transformers.
    Then, this transform can fit and transform all these transformers to the input data.
    The results of these multiple transformations are then concatenated into a single data object.
    The concatenation is performed row-wise as well as the transformations.
    This is useful to combine several feature extraction mechanisms into a single transformer.

    Parameters
    ----------
    transformers : List[Transformer]
        List of transformers.

    n_jobs : int, optional (default=1)
        Number of parallel jobs to run.
    """

    transformers: List[Transformer] = Parameter(default=[], tunable=False)
    n_jobs: int = Parameter(default=1, tunable=False)
    validation_property = ValidationProperty(input_tag=IsPandasX, output_tag=IsPandasX)

    def __getattr__(self, item) -> Union[Transformer, Any]:
        """
        Method to access dynamic attributes of the instance union.
        This method tries to perform lazy attribute access to one of the following items in the instance union:
            1. transformers
            2. transformers' parameters or estimated parameters

        The lookup can be performed as follows:
            1. instance_union.transformer_name
            2. instance_union.transformer_name.parameter_name
            3. instance_union.transformer_name__parameter_name
            4. instance_union.transformer_name__estimated_parameter_name

        Parameters
        ----------
        item: str
            The attribute name to be accessed.

        Returns
        -------
        value: Any
            The value of the instance union attribute or the value of the parameter in a given step.

        Raises
        ------
        AttributeError
            If the attribute is not found.
        """
        transformers = self.transformers_to_dict()
        value = _attribute_lookup(transformers, item)
        return value

    def __getitem__(self, item) -> Union[Transformer,
                                         List[Transformer],
                                         Any]:
        """
        Returns the transformer or predictor at the given index or key.
        This method tries to perform transformers lookup using indexes, slices or key.
        If the index is out of range, an IndexError is raised.
        If the key is not found, a KeyError is raised.

        Parameters
        ----------
        item: int, slice, str
            The index, slice or key to look up.

        Returns
        -------
        value: Any
            The transformer or predictor at the given index or key.

        Raises
        ------
        IndexError
            If the index is out of range.

        KeyError
            If the key is not found.
        """
        transformers = list(self.transformers_to_dict().items())
        # noinspection PyTypeChecker
        value = _item_lookup(transformers, item)
        return value

    def transformers_to_dict(self) -> Dict[str, Transformer]:
        """
         Returns a dictionary with the name of the transformer and the transformer.

        Returns
        -------
        steps_dict: Dict[str, Transformer]
            A dictionary containing the name of the transformer and the transformer.
        """
        return {transformer.name: transformer for transformer in self.transformers}

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None):
        """
        Fits all transformers to "x" and "y".
        Parameters
        ----------
        x: pd.DataFrame
            The data to transform.
        y: pd.DataFrame
            The target variable to try to predict in the case of supervised learning.
        Returns
        -------
        self : Transformer
            The fitted transformers.
        """
        self._validate_transformers()

        self._parallel_func(x, y, _fit_one)

        self.features = list(x.columns)
        self.instances = [f"{transformer.name}_{instance}"
                          for transformer in self.transformers
                          for instance in transformer.instances]
        return self

    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the input data (x, y) based on the estimated parameters during the transformers fit.

        Parameters
        ----------
        x: pd.DataFrame
            The data to transform.
        y: pd.DataFrame
            The target variable to try to predict in the case of supervised learning.

        Returns
        -------
        transformed_x : pd.DataFrame
            The concatenated pd.DataFrame, result of the transformation of the original instances.
            It does not keep the original instances
        transformed_y : pd.DataFrame
            The concatenated pd.DataFrame.
        """
        x = x.copy()
        new_x, _ = zip(*self._parallel_func(x, y, _transform_one))
        new_x = list(new_x)

        for i, df in enumerate(new_x):
            new_x[i] = df.set_index(self.transformers[i].name + '_' + df.index.astype(str))

        new_x = pd.concat(new_x, axis=0)
        return new_x, y

    def parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the parameters of all transformers as a dict of dicts.
        Returns
        -------
        parameters : Dict[str, Dict[str, Any]]
            The parameters of the transformers.
        """
        return {transformer.name: transformer.parameters for transformer in self.transformers}

    def estimated_parameters(self) -> Dict[str, Dict[str, Any]]:
        """
        Gets the estimated parameters of all transformers as a dict of dicts.
        Returns
        -------
        estimated_parameters : Dict[str, Dict[str, Any]]
            The estimated parameters of the transformers.
        """
        return {transformer.name: transformer.estimated_parameters for transformer in self.transformers}

    @property
    def tags(self) -> List[Union[OperandHolder, BaseValidator, type]]:
        """
        Return the tags of the used transformers that will be used to validate the input data.
        Returns
        -------
        tags : List[Union[OperandHolder, BaseValidator, type]]
            The list of tags for the transformers.
        """
        all_tags = set()
        for transformer in self.transformers:
            all_tags.update(set(transformer.validation_property.input_tag))
        return list(all_tags)

    def _parallel_func(self, x, y, func):
        """
        Helper function for parallelization.
        Parameters
        ----------
        x: pd.DataFrame
            The data to transform.
        y: pd.DataFrame
            The target variable to try to predict in the case of supervised learning.
        func: callable
            the function to parallelize.
        Returns
        -------
        list:
            List of "func" outputs.
        """
        parallel_callback = Parallel(n_jobs=self.n_jobs)
        return parallel_callback(delayed(func)(transformer, x, y)
                                 for transformer in self.transformers)

    def _validate_transformers(self):
        """
        Validates if all transformers are valid.

        Raises
        ------
        ValueError:
            If transformers are not valid.
        """
        names = set()
        for transformer in self.transformers:
            if transformer.name in names:
                raise ValueError('Transformer names must be unique.')
            names.add(transformer.name)
            if not is_transformer(transformer):
                raise ValueError('All transformers must be a subclass of Transformer.')
        return

    def to_dict(self) -> Dict:
        """
        Converts the instance union to a dictionary.

        Returns
        -------
        iu: Dict
            The dictionary representation of the instance union.
        """
        state = {'name': self.name, 'parameters': {'transformers': []}}
        for transformer in self.transformers:
            state['parameters']['transformers'].append(transformer.to_dict())

        return state

    @classmethod
    def from_dict(cls, state: Dict) -> 'InstanceUnion':
        """
        Converts the instance union from a dictionary.

        Parameters
        ----------
        state:
            The dictionary representation of the estimator.
        Returns
        -------
        iu: InstanceUnion
            The instance union.
        """
        transformers = []
        for transformer in state['parameters'].get('transformers', []):
            transformer = setup_estimator(name=transformer['name'], parameters=transformer['parameters'])
            transformers.append(transformer)

        return cls(transformers=transformers)
