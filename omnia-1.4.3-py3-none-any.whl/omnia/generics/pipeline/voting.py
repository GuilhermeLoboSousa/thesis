import os
import warnings
from datetime import datetime
from distutils.dir_util import copy_tree
from pathlib import Path
from typing import List, Literal, Any, Union, Callable, Dict

import numpy as np

from .pipeline import Pipeline
from omnia.generics.evaluate import Evaluator
from omnia.generics.prediction import TabularPredictor, MultiLabelTabularPredictor
from omnia.generics.utils.constants import BINARY, MULTICLASS, REGRESSION
from omnia.generics.validation.task_tag import TaskTag


class VotingPipeline:
    """
    Pipeline that combines the predictions of multiple pipelines using voting.

    VotingPipeline can be used with fitted and saved pipelines or unfitted pipelines.
    """

    def __init__(self, pipelines: List[Pipeline], task_type: Union[str, TaskTag],
                 voting: Literal["hard", "soft"] = "hard", weights: List[float] = None,
                 path: str = None) -> None:
        """
        Initializes a voting pipeline.

        Parameters
        ----------
        pipelines: List[Pipeline]
            List of pipelines to be used in the voting.
        voting: Literal["hard", "soft"]
            Type of voting to be used. Either hard or soft. Only applicable for classification.
        weights: List[float]
            List of weights to be used for each pipeline. If None, all pipelines will have equal weight.
        path: str
            Path where the voting pipeline will be saved.
        """
        super().__init__()
        self.pipelines = pipelines
        if not isinstance(task_type, TaskTag):
            self.task_type = TaskTag.from_string(task_type)
        else:
            self.task_type = task_type
        self.voting = voting
        self.weights = weights
        self.path = path
        self._validate_pipelines()
        self._fitted = False
        self._problem_type = None

    def _validate_pipelines(self) -> 'VotingPipeline':
        """
        Validates the pipelines.
        It normalizes the weights and verifies that the number of weights is equal to the number of pipelines.
        It also verifies that all pipelines are prediction pipelines.
        """
        if self.weights is None:
            self.weights = np.array([1] * len(self.pipelines))
        # Normalize weights
        total_weight = sum(self.weights)
        self.weights = np.array([w / total_weight for w in self.weights])
        assert len(self.weights) == len(
            self.pipelines), "Number of weights must be equal to number of pipelines"
        assert self.voting in [
            "hard", "soft"], "Voting must be either hard or soft"
        for pipeline in self.pipelines:
            assert pipeline.is_predictor() or pipeline.is_model(
            ), "All pipelines must be prediction pipelines"
        return self

    def fit(self, x: Any, y: Any = None, x_val: Any = None, y_val: Any = None,
            problem_type: str = None) -> 'VotingPipeline':
        """
        Fits the pipelines to the training dataset. A separate validation dataset can also be provided.

        Parameters
        ----------
        x: Any
            Training data.
        y: Any
            Training labels.
        x_val: Any
            Validation data.
        y_val: Any
            Validation labels.
        problem_type: str, optional
            Problem type of the voting pipeline.
        """
        if problem_type is not None:
            self.problem_type = problem_type
        assert self.problem_type in [BINARY, MULTICLASS, REGRESSION], \
            (f"Unsupported problem type: {self.problem_type}. Supported problem types are: {BINARY}, {MULTICLASS}, "
             f"{REGRESSION}.")
        for pipeline in self.pipelines:
            pipeline.fit(x, y, x_val, y_val, problem_type=self.problem_type)
            pipeline.save()
        self._fitted = True
        return self

    @property
    def problem_type(self) -> str:
        """
        Get the problem type of the model.

        Returns
        -------
        str
            The problem type of the model.
        """
        if self.task_type in [TaskTag.BINARY, TaskTag.MULTITASK_BINARY]:
            self._problem_type = BINARY
        elif self.task_type in [TaskTag.REGRESSION, TaskTag.MULTITASK_REGRESSION]:
            self._problem_type = REGRESSION
        else:
            self._problem_type = MULTICLASS
        return self._problem_type

    @problem_type.setter
    def problem_type(self, problem_type: str) -> 'VotingPipeline':
        """
        Set the problem type of the model.

        Parameters
        ----------
        problem_type: str
            The problem type of the model.
        """
        self._problem_type = problem_type

    @property
    def fitted(self) -> bool:
        """
        Check if the model has been fitted.

        Returns
        -------
        bool
            True if the model has been fitted, False otherwise.
        """
        for pipeline in self.pipelines:
            if not pipeline.fitted:
                return False
        return True

    def _voting(self, predictions: List[np.ndarray]) -> np.ndarray:
        """
        Performs the voting. It can be either hard or soft.

        Parameters
        ----------
        predictions: List[np.ndarray]
            List of predictions from each pipeline.

        Returns
        -------
        np.ndarray
            List of predictions by voting.
        """
        if self.task_type.value in [TaskTag.BINARY.value, TaskTag.MULTICLASS.value,
                                    TaskTag.MULTITASK_BINARY.value, TaskTag.MULTITASK_MULTICLASS.value]:
            if self.voting == "hard":
                return self._hard_voting(predictions)
            else:
                return self._soft_voting(predictions)
        elif self.task_type.value == 'regression':
            return np.average(predictions, axis=0, weights=self.weights)
        else:
            raise ValueError(
                f"{self.task_type} not supported for VotingPipeline.")

    def _hard_voting(self, predictions: List[np.ndarray]) -> np.ndarray:
        """
        Performs weighted hard voting.

        Parameters
        ----------
        predictions: List[Union[List[int], List[float]]]
            List of predictions from each pipeline in the shape (n_samples, n_tasks).

        Returns
        -------
        np.ndarray
            Array of predictions by hard voting.
        """
        if self.task_type.value in [TaskTag.BINARY.value, TaskTag.MULTITASK_BINARY.value]:
            predictions = [np.where(pred >= 0.5, 1, 0) for pred in predictions]

        n_samples, n_tasks = predictions[0].shape

        # Determine the number of unique classes
        unique_classes = np.unique(np.concatenate(predictions))
        num_classes = len(unique_classes)

        # If there is only one class predicted across all pipelines, there is no need to vote
        if num_classes == 1:
            return predictions[0]

        # Initialize weighted predictions array
        weighted_votes = np.zeros(
            (n_samples, n_tasks, num_classes), dtype=np.float32)

        # Apply weights to predictions
        for i, pred in enumerate(predictions):
            for c in range(num_classes):
                weighted_votes[:, :, c] += (pred ==
                                            unique_classes[c]) * self.weights[i]

        # Find the class with the maximum weighted vote
        final_predictions = np.argmax(weighted_votes, axis=-1)

        # Map back to original class labels if necessary
        class_map = {i: unique_classes[i] for i in range(num_classes)}
        final_predictions = np.vectorize(class_map.get)(final_predictions)

        return final_predictions

    def _soft_voting(self, predictions: List[np.ndarray]) -> np.ndarray:
        """
        Performs weighted soft voting.

        Parameters
        ----------
        predictions: List[np.ndarray]
            List of predictions from each pipeline.

        Returns
        -------
        np.ndarray
            Array of predictions by soft voting.
        """
        stacked_predictions = np.stack(predictions, axis=-1)
        weighted_predictions = stacked_predictions * self.weights
        weighted_average_probabilities = np.sum(weighted_predictions, axis=-1)
        return weighted_average_probabilities

    def _make_predictions(self, x: Any) -> np.ndarray:
        """
        Makes predictions for the given dataset using the voting pipeline.

        Parameters
        ----------
        x: Any
            Dataset to be used for prediction.

        Returns
        -------
        np.ndarray
            Array of predictions.
        """
        if not self.fitted:
            raise ValueError(
                "The pipelines are not fitted yet. Fit the VotingPipeline before making predictions.")
        if self.task_type.value != TaskTag.REGRESSION.value and self.voting == 'soft':
            if not self.can_predict_proba:
                raise ValueError('At least one pipeline cannot predict probabilities! '
                                 '"soft" voting cannot be calculated!')
            predictions = [pipeline.predict_proba(
                x) for pipeline in self.pipelines]
        else:
            predictions = [pipeline.predict(x) for pipeline in self.pipelines]
        if self.task_type.value in [TaskTag.BINARY.value, TaskTag.MULTICLASS.value, TaskTag.MULTILABEL.value,
                                    TaskTag.REGRESSION.value]:
            return self._voting(predictions)
        else:
            if self.task_type.value == TaskTag.MULTITASK_REGRESSION.value:
                return np.average([prediction for prediction in predictions], axis=0, weights=self.weights)
            elif self.task_type.value in [TaskTag.MULTITASK_BINARY.value, TaskTag.MULTITASK_MULTICLASS.value,
                                          TaskTag.MULTITASK_MULTILABEL.value]:
                if isinstance(predictions, list):
                    predictions = np.array(predictions)
                voting_preds = []
                for task_index in range(predictions.shape[-1]):
                    task_array = predictions[:, :, task_index]
                    task_array = task_array.reshape(
                        task_array.shape[0], task_array.shape[1], 1)
                    voting_preds.append(self._voting(list(task_array)))
                return np.array(voting_preds).T.reshape(predictions.shape[1], predictions.shape[2])
            else:
                raise ValueError(f"Task type {self.task_type} not supported.")

    def predict(self, x: Any) -> np.ndarray:
        """
        Makes predictions for the given dataset using the voting pipeline.

        Parameters
        ----------
        x: Any
            Dataset to be used for prediction.

        Returns
        -------
        np.ndarray
            Array of predictions.
        """
        predictions = self._make_predictions(x)
        if self.task_type.value in [TaskTag.BINARY.value, TaskTag.MULTITASK_BINARY.value]:
            return np.array([np.where(pred >= 0.5, 1, 0) for pred in predictions])
        elif (self.task_type.value in [TaskTag.MULTICLASS.value, TaskTag.MULTITASK_MULTICLASS.value] and
              self.voting == 'soft'):
            return np.array([np.argmax(pred, axis=1) for pred in predictions])
        return predictions

    @property
    def can_predict_proba(self) -> bool:
        """
        Check if all the models in the VotingPipeline can predict probabilities.
        It verifies if all the model have a _can_predict_proba attribute.

        Returns
        -------
        bool
            True if the model can predict probabilities, False otherwise.
        """
        for pipeline in self.pipelines:
            if pipeline.steps[-1][1].can_predict_proba is False:
                return False
        return True

    def predict_proba(self, x: Any) -> np.ndarray:
        """
        Makes predictions for the given dataset using the voting pipeline.

        Parameters
        ----------
        x: Any
            Dataset to be used for prediction.

        Returns
        -------
        np.ndarray
            Array of predictions.
        """
        if self.voting != 'soft':
            predictions = [pipeline.predict(
                x) for pipeline in self.pipelines]

            n_classifiers = len(predictions)
            n_samples, n_tasks = predictions[0].shape
            unique_classes = np.unique(np.concatenate(predictions))
            n_classes = len(unique_classes)

            # Get the index of each prediction in unique_classes
            class_indices = np.searchsorted(unique_classes, predictions)

            probas = np.zeros((n_samples, n_tasks, n_classes))

            # return the probability of each class for each sample
            for i in range(n_samples):
                for j in range(n_tasks):
                    for k in range(n_classifiers):
                        probas[i, j, class_indices[k][i, j]
                               ] += self.weights[k] / n_classifiers

            return probas
        return self._make_predictions(x)

    def score(self, x: Any, y: Any, metrics: Union[str, Callable, List[Union[str, Callable]]],
              per_task_metrics: bool = False, w: Any = None, **kwargs) -> Dict[str, float]:
        """
        Computes the score of the voting pipeline using the specified metric.

        Parameters
        ----------
        x: Any
            Input data.
        y: Any
            Target data.
        metrics: Union[str, Callable, List[Union[str, Callable]]]
            Metrics to be used for scoring.
        per_task_metrics: bool, optional
            If true, return computed metric for each task on multitask dataset.
        w: Any, optional
            Weights for each datapoint.
        kwargs: dict
            Additional parameters for the metric.

        Returns
        -------
        float
            Score of the voting pipeline.
        """
        evaluator = Evaluator(self, x, y, w)
        return evaluator.compute_model_performance(metrics=metrics, per_task_metrics=per_task_metrics, **kwargs)

    def save(self) -> 'VotingPipeline':
        """
        Saves the voting pipeline to self.path.
        """
        if self.path is None:
            current_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
            self.path = os.path.join(
                os.getcwd(), f'omnia-pipeline-{current_time}')

        if not os.path.exists(self.path):
            Path(self.path).mkdir(parents=True, exist_ok=True)

        for pipeline in self.pipelines:
            old_path = pipeline.path
            pipeline.path = os.path.join(
                self.path, os.path.basename(os.path.normpath(pipeline.path)))
            if not os.path.exists(pipeline.path):
                os.makedirs(pipeline.path)
            predictor_step = pipeline.steps[-1][1]
            # Copy files to new path
            copy_tree(old_path, pipeline.path)

            if isinstance(predictor_step, (TabularPredictor, MultiLabelTabularPredictor)):
                # Create a list of predictors to update
                predictors_to_update = [predictor_step] if isinstance(predictor_step,
                                                                      TabularPredictor) else predictor_step._predictors

                # Update paths for all relevant predictors
                for predictor in predictors_to_update:
                    predictor._predictor_kwargs['path'] = pipeline.path
                    predictor._path = pipeline.path
                    predictor._ag_path = pipeline.path
                continue
            pipeline.steps[-1][1].path = pipeline.path
        # save json with voting and weights info
        with open(os.path.join(self.path, 'voting_pipeline.json'), 'w') as f:
            # save task type, voting and weights
            f.write(f'{{"task_type": "{self.task_type.value}", "voting": "{self.voting}", '
                    f'"weights": {self.weights.tolist()}}}')
        return self

    @classmethod
    def load(cls, path: str) -> 'VotingPipeline':
        """
        Loads a voting pipeline from the specified path.

        Parameters
        ----------
        path: str
            Path where the voting pipeline is saved.

        Returns
        -------
        VotingPipeline
            Loaded voting pipeline.
        """
        pipelines = []
        for pipeline_path in os.listdir(path):
            if pipeline_path != 'voting_pipeline.json':
                pp = os.path.join(path, pipeline_path)
                pipelines.append(Pipeline.load(pp))
        # load json with voting and weights info
        with open(os.path.join(path, 'voting_pipeline.json'), 'r') as f:
            voting_info = f.read()
        voting_info = eval(voting_info)
        task_type = TaskTag.from_string(voting_info['task_type'])
        return cls(pipelines=pipelines, task_type=task_type, voting=voting_info['voting'],
                   weights=voting_info['weights'])
