import json
from pathlib import Path
from typing import Union, List, Tuple, Dict, Any

from omnia.generics.dataframe import pd
from omnia.generics.transformation import Transformer


def _attribute_lookup(transformers: Dict[str, Transformer], item: str) -> Any:
    """
    Helper function to get attributes from transformers dicts.

    Parameters
    ----------
    transformers: Dict[str, Transformer]
        dict of objects to get attributes from
    item: str
        attribute to get

    Returns
    -------
    Any
        attribute

    Raises
    ------
    AttributeError
        If the attribute is not found.
    """
    if '__' in item:
        name, attribute = item.split('__')

        if name not in transformers:
            raise AttributeError(f"No step with name {name}")

        transformer = transformers[name]
        value = getattr(transformer, attribute)
        return value

    elif item in transformers:
        return transformers[item]

    else:
        raise AttributeError(f"No step, transformer or predictor named {item}")


def _item_lookup(transformers: List[Tuple[str, Transformer]], item: str) -> Any:
    """
    Helper function to get items from transformers lists.

    Parameters
    ----------
    transformers: List[Tuple[str, Transformer]]
        list of objects to get items from

    item: str
        item to get

    Returns
    -------
    Any
        item

    Raises
    ------
    IndexError
        If the index is out of range.

    KeyError
        If the key is not found.
    """
    if isinstance(item, int):
        try:
            return transformers[item][1]
        except IndexError:
            raise IndexError(f"Index {item} is out of range")

    elif isinstance(item, slice):
        try:
            return [transformer for _, transformer in transformers[item]]
        except IndexError:
            raise IndexError(f"Slice {item} is out of range")

    elif isinstance(item, str):
        for name, transformer in transformers:
            if name == item:
                return transformer
        raise KeyError(f"No transformer or predictor named {item}")

    else:
        raise TypeError(f"Invalid index type {type(item)}")


def _df_indexing(df: pd.DataFrame, idx: Union[str, int, List[int], List[str], slice]) -> pd.DataFrame:
    """
    Indexes a dataframe with a string, index, list of indices, list of strings, or slices

    Parameters
    ----------
    df: pd.DataFrame
        dataframe to be indexed

    idx: string, index, list of indices, list of strings, or slices
        indices to be used to index the dataframe

    Returns
    -------
    df: pd.DataFrame
        indexed dataframe

    Raises
    ------
    IndexError
        if the index is not found

    ValueError
        if the index is not a string, int, list of ints, list of strings, or slice
    """
    if isinstance(idx, str):
        try:
            return df.loc[:, [idx]]
        except KeyError:
            raise IndexError("Index not found")

    elif isinstance(idx, int):
        try:
            return df.iloc[:, [idx]]
        except IndexError:
            raise IndexError("Index not found")

    elif isinstance(idx, list) and all(isinstance(i, str) for i in idx):
        try:
            return df.loc[:, idx]
        except KeyError:
            raise IndexError("Index not found")

    elif isinstance(idx, list) and all(isinstance(i, int) for i in idx):
        try:
            return df.iloc[:, idx]
        except IndexError:
            raise IndexError("Index not found")

    elif isinstance(idx, slice):
        return df.iloc[:, idx]

    else:
        raise ValueError("Index must be a string, integer, list of strings, or list of integers")


def _fit_one(transformer: Transformer, x: pd.DataFrame, y: pd.DataFrame):
    """
    Helper function to fit transformers in Parallel.
    Fits "transformer" to "x" and "y".

    Parameters
    ----------
    transformer: Transformer
        transformer to fit
    x: pd.DataFrame
        The data to transform.
    y: pd.DataFrame
        The target variable to try to predict in the case of supervised learning.

    Returns
    -------
    self : Estimator
        The fitted transformer.
    """
    return transformer.fit(x, y)


def _transform_one(transformer: Transformer, x: pd.DataFrame, y: pd.DataFrame) -> pd.DataFrame:
    """
    Helper function to transform transformers in Parallel.
    Transforms "x" and/or "y" using "transformer".

    Parameters
    ----------
    transformer: Transformer
        transformer to transform x and/or y
    x: pd.DataFrame
        The data to transform.
    y: pd.DataFrame
        The target variable to try to predict in the case of supervised learning.

    Returns
    -------
    pd.DataFrame
        The transformed data.
    """
    return transformer.transform(x, y)


def _columns_fit_one(transformer: Transformer,
                     columns: Union[List[int], List[str]],
                     x: pd.DataFrame,
                     y: pd.DataFrame = None):
    """
    Fit only one transformer - to be passed to the Parallel class.
    This helper function selects first the columns to be processed.

    Parameters
    ----------
    transformer: Transformer
        transformer to be fitted
    columns: List[str] | List[str]
        columns to be transformed
    x: pd.DataFrame
        dataframe with the data to fit the transformers
    y: pd.DataFrame
        dataframe with the labels to fit the transformers

    Raises
    ------
    ValueError
        if no columns to fit the transformer
    """
    data = _df_indexing(x, columns)
    transformer.fit(data, y)

    assert transformer.fitted
    return


def _columns_transform_one(transformer: Transformer,
                           columns: Union[List[int], List[str]],
                           x: pd.DataFrame,
                           y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Transform with only one transformer - to be used by the Parallel class.
    This helper function selects first the columns to be processed.

    Parameters
    ----------
    transformer: Transformer
        transformer to be fitted
    columns: List[str] | List[str]
        columns to be transformed
    x: pd.DataFrame
        dataframe with the data to be transformed
    y: pd.DataFrame
        dataframe with the labels to be transformed

    Returns
    -------
    transformed_x: pd.DataFrame
        transformed x
    transformed_y : pd.DataFrame
        transformed y

    Raises
    ------
    ValueError
        if no columns to transform
    """
    assert transformer.fitted

    data = _df_indexing(x, columns)
    return transformer.transform(data, y)


def _read_pipeline_configuration(folder: Path) -> dict:
    """
    It reads the pipeline configuration file.

    Parameters
    ----------
    folder : Path
        folder to read the name from

    Returns
    -------
    config : dict
        the pipeline configuration
    """
    if not folder.joinpath('config.json').exists():
        return {}

    with open(folder.joinpath('config.json'), 'r') as file:
        config = json.load(file)
    return config


def _write_pipeline_configuration(folder: Path, config: dict) -> bool:
    """
    It writes the pipeline configuration file.

    Parameters
    ----------
    folder : Path
        folder to write the configuration to

    config : dict
        the pipeline configuration

    Returns
    -------
    bool
        True if the file was written, False otherwise
    """
    with open(folder.joinpath('config.json'), 'w') as file:
        json.dump(config, file)
        return True
