import os
import tarfile
from datetime import datetime
from os import PathLike
from pathlib import Path
import io
from typing import IO, TextIO, Union, AnyStr, Tuple, Optional
from urllib.parse import urlparse

import requests

FilePathOrBuffer = Union[str, Path, IO[AnyStr], TextIO]
DirPath = Union[str, Path]


def is_url(filepath_or_buffer: FilePathOrBuffer, **kwargs) -> bool:
    """
    Function that checks if the filepath_or_buffer is a url.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    is_url : bool
        True if the filepath_or_buffer is an url, False otherwise.
    """
    if not isinstance(filepath_or_buffer, str):
        return False

    if urlparse(filepath_or_buffer).scheme != '':
        try:

            response = requests.head(filepath_or_buffer, allow_redirects=True, **kwargs)
            if response.status_code == 200:
                return True

            return False

        except requests.exceptions.RequestException:
            return False

    return False


def is_buffer(filepath_or_buffer: FilePathOrBuffer) -> bool:
    """
    Function that checks if the filepath_or_buffer is a buffer.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    is_buffer : bool
        True if the filepath_or_buffer is a buffer, False otherwise.
    """
    return isinstance(filepath_or_buffer, (io.TextIOBase,
                                           io.BufferedIOBase,
                                           io.RawIOBase,
                                           io.IOBase))


def is_path(filepath_or_buffer: FilePathOrBuffer) -> bool:
    """
    Function that checks if the filepath_or_buffer is a path.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    is_path : bool
        True if the filepath_or_buffer is a path, False otherwise.
    """
    if isinstance(filepath_or_buffer, Path):
        return True

    path = Path(filepath_or_buffer)
    try:
        if path.exists():
            return True
        return False

    except OSError:
        return False


def is_dir(filepath_or_buffer: DirPath) -> bool:
    """
    Function that checks if the DirPath is a directory.

    Parameters
    ----------
    filepath_or_buffer : str | Path
        directory path path

    Returns
    -------
    is_path : booldir_path
        True if the dir_path is a directory, False otherwise.
    """
    if not isinstance(filepath_or_buffer, Path):
        filepath_or_buffer = Path(filepath_or_buffer)
    try:
        if filepath_or_buffer.is_dir():
            return True
        return False

    except OSError:
        return False


def is_gzip_tarball(filepath_or_buffer: FilePathOrBuffer) -> bool:
    """
    Function that checks if the FilePathOrBuffer is a gziped tarball.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        directory path path

    Returns
    -------
    is_path : bool
        True if the FilePathOrBuffer is a gziped tarball, False otherwise.
    """
    try:
        if tarfile.is_tarfile(filepath_or_buffer):
            return True
        return False

    except OSError:
        return False


def is_gzip_tarball_path(filepath_or_buffer: FilePathOrBuffer) -> bool:
    """
    Checks that the provided path is in good-faith a .tar.gz tarball.

    It only checks the path for situations where it is not possible to check the content directly, like in URL before downloading.
    This is a very unsafe assumption! As soon as you can, you must use the is_gzip_tarball() function to check the contents directly.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        directory path path

    Returns
    -------
    is_path : bool
        True if the FilePathOrBuffer is a gziped tarball, False otherwise.
    """
    suffix = ".tar.gz"

    if isinstance(filepath_or_buffer, Path):
        if filepath_or_buffer.name.endswith(suffix):
            return True
        return False
    try:
        if filepath_or_buffer.endswith(suffix):
            return True
        return False

    except OSError:
        return False


def get_timestamped_dir(parent_path: DirPath = None,
                        timestamp_format="%Y-%m-%d-%H-%M-%S",
                        dir_name="omnia-datafile") -> DirPath:
    """
    Generate timestamped directory name and path for temporary archival purposes.

    Parameters
    ----------
    parent_path: str | Path
        base path for the directory, if not provided it will be devaulted to the current working directory.
    timestamp_format: str
        datetime-like formating string for the timestamp part of the directory name.
    dir_name
        label or name added before the timestamp

    Returns
    -------
        New timestamped Path.

    """
    parent = parent_path if parent_path else os.getcwd()
    current_time = datetime.now().strftime(timestamp_format)
    dir_to_save = Path(os.path.join(parent, f'{dir_name}-{current_time}'))
    return dir_to_save


def get_path_or_buffer_or_url(filepath_or_buffer: FilePathOrBuffer) -> Tuple[Optional[Path],
                                                                             Optional[IO[AnyStr]],
                                                                             Optional[str]]:
    """
    Function that returns either the Path object or the buffer object or the url.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    path : tuple[Optional[Path], Optional[IO[AnyStr]], Optional[str]]
        path object or url string
    """
    if is_buffer(filepath_or_buffer):
        return None, filepath_or_buffer, None

    if is_url(filepath_or_buffer):
        return None, None, filepath_or_buffer

    if is_path(filepath_or_buffer):
        return Path(filepath_or_buffer), None, None

    return None, None, None


def get_path_to_read(filepath_or_buffer: FilePathOrBuffer,
                     dir_to_save: PathLike = None,
                     uncompress=False,
                     **kwargs) -> PathLike:
    """
    Function that returns the file path from the Path object.

    These function works as a fallback option when the domain specific functions cannot accept open buffers.
    All other cases should be handled by get_handle_to_read.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    dir_to_save : str | Path
        directory path to save temporary files

    uncompress : bool
        if True, the file will be uncompressed if it is compressed.

    Returns
    -------
    handler : IO[AnyStr]
        file handler

    Raises
    ------
    ValueError
        if the filepath_or_buffer is not a valid file path or buffer or url
    """
    if is_buffer(filepath_or_buffer):
        # TODO: Idealy you could save it to the cwd and then read it from there.
        raise ValueError("The function does not accept buffers, please provide a legal input : Path")

    elif is_path(filepath_or_buffer):
        if uncompress and is_gzip_tarball(filepath_or_buffer):
            comp_file = tarfile.open(filepath_or_buffer)

            if dir_to_save is None:
                dir_to_save = get_timestamped_dir()
            else:
                dir_to_save = Path(dir_to_save)

            comp_file.extractall(dir_to_save)
            return Path(dir_to_save)
        else:
            return Path(filepath_or_buffer)

    elif is_url(filepath_or_buffer, **kwargs):
        data = requests.get(filepath_or_buffer, **kwargs)
        file_name = os.path.split(filepath_or_buffer)[1]

        if dir_to_save is None:
            dir_to_save = get_timestamped_dir()
        else:
            dir_to_save = Path(dir_to_save)

        dir_to_save.mkdir(parents=True, exist_ok=True)

        if uncompress and is_gzip_tarball_path(filepath_or_buffer):
            tar = tarfile.open(fileobj=io.BytesIO(data.content))
            tar.extractall(dir_to_save)
            return Path(dir_to_save)

        else:
            path_to_save = dir_to_save / file_name
            with open(path_to_save, "wb") as f:
                f.write(data.content)
            return Path(path_to_save)

    raise ValueError("No file path or buffer or url provided.")


def get_handle_to_read(filepath_or_buffer: FilePathOrBuffer, mode: str = 'r', **kwargs) -> IO[AnyStr]:
    """
    Function that returns the file handler from the Path object or the buffer object or the url.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    mode : str, optional
        file mode, by default 'r'

    Returns
    -------
    handler : IO[AnyStr]
        file handler

    Raises
    ------
    ValueError
        if the filepath_or_buffer is not a valid file path or buffer or url
    """
    if is_buffer(filepath_or_buffer):
        return filepath_or_buffer

    elif is_path(filepath_or_buffer):
        return open(filepath_or_buffer, mode=mode)

    elif is_url(filepath_or_buffer, **kwargs):
        data = requests.get(filepath_or_buffer, **kwargs)

        if is_gzip_tarball_path(filepath_or_buffer):
            tar = tarfile.open(fileobj=io.BytesIO(data.content))
            return tar.extractfile(tar.getnames()[0])

        if mode == 'r':
            return io.StringIO(data.text)

        elif mode == 'rb':
            return io.BytesIO(data.content)

        raise ValueError("Cannot read from a url.")

    raise ValueError("No file path or buffer or url provided.")


def get_handle_to_write(filepath_or_buffer: FilePathOrBuffer, mode: str = 'r', **kwargs) -> IO[AnyStr]:
    """
    Function that returns the file handler from the Path object or the buffer object or the url.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    mode : str, optional
        file mode, by default 'r'

    Returns
    -------
    handler : IO[AnyStr]
        file handler

    Raises
    ------
    ValueError
        if the filepath_or_buffer is not a valid file path or buffer or url
    """

    if is_buffer(filepath_or_buffer):
        return filepath_or_buffer

    elif is_url(filepath_or_buffer, **kwargs):
        raise ValueError("Cannot write to a url.")

    return open(filepath_or_buffer, mode=mode)
