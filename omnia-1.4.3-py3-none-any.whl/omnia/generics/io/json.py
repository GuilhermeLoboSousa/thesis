from typing import Dict

from omnia.generics.dataframe import pd
from ._json import JSONDataFrameReader, JSONReader, JSONWriter, JSONDataFrameWriter
from ._utils import FilePathOrBuffer


def read_json_dataframe(filepath_or_buffer: FilePathOrBuffer, **kwargs) -> pd.DataFrame:
    """
    Function that reads the JSON file and returns a pandas DataFrame using pandas read_json.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    data : DataFrame
    """
    with JSONDataFrameReader(filepath_or_buffer=filepath_or_buffer, **kwargs) as reader:
        data = reader.read()
    return data


def write_json_dataframe(filepath_or_buffer: FilePathOrBuffer, data: pd.DataFrame, **kwargs) -> bool:
    """
    Function that writes a pandas DataFrame into a JSON file using pandas write_json.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    data : pd.DataFrame
        DataFrame to be written in the JSON file

    Returns
    -------
    flag : boolean
        whether the DataFrame was written without errors or not
    """
    with JSONDataFrameWriter(filepath_or_buffer=filepath_or_buffer, **kwargs) as writer:
        flag = writer.write(data)
    return flag


def read_json(filepath_or_buffer: FilePathOrBuffer, **kwargs) -> Dict:
    """
    Function that reads the JSON file and returns the data dictionary.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    data : Dict
        dictionary with the data contained in the JSON file
    """
    with JSONReader(filepath_or_buffer=filepath_or_buffer, **kwargs) as reader:
        data = reader.read()
    return data


def write_json(filepath_or_buffer: FilePathOrBuffer, data: Dict, **kwargs) -> bool:
    """
    Function that writes a data dictionary into a JSON file.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    data : Dict
        dictionary to be written in the JSON file

    Returns
    -------
    flag : boolean
        whether the data was written without errors
    """

    with JSONWriter(filepath_or_buffer=filepath_or_buffer, **kwargs) as writer:
        flag = writer.write(data=data)
    return flag
