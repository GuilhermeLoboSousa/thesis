from typing import Any, Dict, List, Union, IO, AnyStr, TextIO

from yaml import CLoader as Loader
from yaml import load, dump

from omnia.generics.io._utils import get_handle_to_read, get_handle_to_write
from omnia.generics.io.reader import Reader
from omnia.generics.io.writer import Writer


class YAMLReader(Reader):

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types that the reader can read.

        Returns
        -------
        file_types : List[str]
            file types that the reader can read.
        """
        return ['yml', 'yaml']

    def read(self) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Method to read the data from file(s) and returns a dictionary or list of dictionaries.

        Parameters
        ----------

        Returns
        -------
        data : Union[List[Dict[str, Any]], Dict[str, Any]]
        """
        if 'Loader' not in self.kwargs:
            self.kwargs['Loader'] = Loader

        mode = self.kwargs.pop('mode', 'r')
        auth = self.kwargs.pop('auth', None)
        handle = get_handle_to_read(self.f, mode=mode, auth=auth)

        with handle as f:
            return load(f, **self.kwargs)


class YAMLWriter(Writer):

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types that the writer can write.

        Returns
        -------
        file_types : List[str]
            file types that the writer can write.
        """
        return ['yml', 'yaml']

    def write(self, data: Union[List[Dict[str, Any]], Dict[str, Any]]) -> bool:
        """
        Method to write the dictionary into a YAML file.

        Parameters
        ----------
        data : Any
            object to be written (e.g., dataframe or data file)

        Returns
        -------
        flag : boolean
            whether the DataFrame was written without errors or not
        """
        mode = self.kwargs.pop('mode', 'w')
        handle = get_handle_to_write(self.f, mode=mode)
        with handle as f:
            dump(data, f, **self.kwargs)
        return True
