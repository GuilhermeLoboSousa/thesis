from typing import Any

from ._pickle import PickleReader, PickleWriter
from ._utils import FilePathOrBuffer


def read_pickle(filepath_or_buffer: FilePathOrBuffer, **kwargs) -> Any:
    """
    Method to read the data from file(s) and return the deserialized object.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path or buffer or url

    Returns
    -------
    object : Any
        the serialized object
    """
    with PickleReader(filepath_or_buffer=filepath_or_buffer, **kwargs) as reader:
        res = reader.read()
    return res


def write_pickle(filepath_or_buffer: FilePathOrBuffer, item: Any, **kwargs) -> bool:
    """
    Method to write the data to file(s) and return the serialized object.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path
    item: Any
        the object to be serialized

    Returns
    -------
    flag : boolean
        whether the DataFrame was written without errors or not
    """
    with PickleWriter(filepath_or_buffer=filepath_or_buffer, **kwargs) as writer:
        flag = writer.write(item)
    return flag
