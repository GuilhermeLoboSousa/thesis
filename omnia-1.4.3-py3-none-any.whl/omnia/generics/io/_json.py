import json
from typing import Dict, List

from omnia.generics.dataframe import pd
from ._utils import get_handle_to_write, get_handle_to_read
from .reader import Reader
from .writer import Writer


class JSONDataFrameReader(Reader):
    """
    Object responsible to load JSON data and converting them into a DataFrame.
    """
    file_types = {'json', }

    def read(self) -> pd.DataFrame:
        """
        Method to read the data from file and return a pandas DataFrame.

        Returns
        -------
        data : pd.DataFrame object
        """
        mode = self.kwargs.pop('mode', 'r')
        auth = self.kwargs.pop('auth', None)
        handle = get_handle_to_read(self.f, mode=mode, auth=auth)
        with handle as f:
            return pd.read_json(f, **self.kwargs)


class JSONDataFrameWriter(Writer):
    """
    Object responsible to write JSON data from a DataFrame.
    """

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types.

        Returns
        -------
        file_types : List[str]
            supported file types
        """
        return ['json']

    def write(self, data: pd.DataFrame) -> bool:
        """
        Method to write the DataFrame into a JSON file.

        Parameters
        ----------
        data : pd.DataFrame
            pandas DataFrame to be written

        Returns
        -------
        flag : boolean
            whether the DataFrame was written without errors
        """
        data.to_json(self.f, **self.kwargs)
        return True


class JSONReader(Reader):
    """
    Object responsible to load JSON data and converting them into a regular dictionary
    """

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types.

        Returns
        -------
        file_types : List[str]
            supported file types
        """
        return ['json']

    def read(self) -> Dict:
        """
        Method to read the data from file(s) and return a pandas DataFrame.

        Returns
        -------
        data : Dict
            dictionary with configurations
        """
        mode = self.kwargs.pop('mode', 'r')
        auth = self.kwargs.pop('auth', None)
        handle = get_handle_to_read(self.f, mode=mode, auth=auth)
        with handle as f:
            return json.load(f, **self.kwargs)


class JSONWriter(Writer):
    """
    Object responsible to write JSON data from a regular dictionary
    """

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types.

        Returns
        -------
        file_types : List[str]
            supported file types
        """
        return ['json']

    def write(self, data: Dict) -> bool:
        """
        Method to write JSON data from a regular dictionary.

        Parameters
        ----------
        data : Dict
            dictionary with the data to be written

        Returns
        -------
        flag : boolean
            whether the data was written without errors
        """
        mode = self.kwargs.pop('mode', 'w')
        handle = get_handle_to_write(self.f, mode=mode)
        with handle as f:
            json.dump(data, f, **self.kwargs)
        return True
