from typing import List

from omnia.generics.dataframe import pd
from omnia.generics.io._utils import get_handle_to_read
from omnia.generics.io.reader import Reader
from omnia.generics.io.writer import Writer


class CSVReader(Reader):
    """
    Class that implements the class Reader and reads CSV, TSV and other format files.
    """
    file_types = {'txt', 'csv', 'tsv'}

    def read(self) -> pd.DataFrame:
        """
        Method to read the data from file(s) and returns a pandas pd.DataFrame.

        Parameters
        ----------

        Returns
        -------
        data : pd.DataFrame
            Read DataFrame
        """
        mode = self.kwargs.pop('mode', 'r')
        auth = self.kwargs.pop('auth', None)
        handle = get_handle_to_read(self.f, mode=mode, auth=auth)
        with handle as f:
            return pd.read_csv(f, **self.kwargs)


class CSVWriter(Writer):
    """
    Class that implements the class Writer and writes CSV, TSV and other format files.
    """

    @property
    def file_types(self) -> List[str]:
        """
        Returns the file types that the writer can write.

        Returns
        -------
        file_types : List[str]
            the file types that the writer can write.
        """
        return ['txt', 'csv', 'tsv']

    def write(self, data: pd.DataFrame) -> bool:
        """
        Method to write the pd.DataFrame into a CSV file.

        Parameters
        ----------
        data : pd.DataFrame
            pandas DataFrame to be written

        Returns
        -------
        flag : boolean
            whether the pd.DataFrame was written without errors or not
        """
        data.to_csv(self.f, **self.kwargs)
        return True
