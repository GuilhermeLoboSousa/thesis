from abc import abstractmethod
from typing import List, Any

from ._utils import FilePathOrBuffer


class Writer:
    """
    Generic class for writing data from file(s).
    All writers must implement the read method.
    All writers must define the file_types attribute.
    """
    def __init__(self, filepath_or_buffer: FilePathOrBuffer, **kwargs):
        """
        Initializer of this class that defines instance variables such as the buffer for the file and path.

        Parameters
        ----------
        filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
            file path
        """
        self.f = filepath_or_buffer
        self.kwargs = kwargs

    def close(self):
        """
        Closes the buffer.

        Returns
        -------
        None
        """
        if hasattr(self.f, "close"):
            self.f.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    @property
    @abstractmethod
    def file_types(self) -> List[str]:
        """
        Abstract method and property that returns the file types that the writer can write.

        Returns
        -------
        file_types : List[str]
            file types that the writer can write
        """
        pass

    @abstractmethod
    def write(self, object_to_be_written: Any) -> bool:
        """
        Abstract method to read the data from file(s).

        Parameters
        ----------
        object_to_be_written : Any
            object to be written (e.g., dataframe or data file)

        Returns
        -------
        bool : True if the data was written successfully, False otherwise.
        """
        pass
