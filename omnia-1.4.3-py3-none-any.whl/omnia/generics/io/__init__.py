from ._csv import CSVReader
from ._json import JSONDataFrameReader
from ._pickle import PickleReader
from ._yaml import YAMLReader
from .csv import read_csv, write_csv
from .json import read_json_dataframe, write_json_dataframe, read_json, write_json
from .pickle import read_pickle, write_pickle
from .reader import Reader
from .yaml import read_yaml, write_yaml


def get_dataframe_reader_by_file_type(file_type: str) -> callable:
    """
    Function that returns the reader class for a given file type.

    Parameters
    ----------
    file_type : str
        the file type

    Returns
    -------
    reader : callable
        the reader class for the given file type
    """
    if file_type.lower() in CSVReader.file_types:
        return read_csv
    if file_type.lower() in JSONDataFrameReader.file_types:
        return read_json_dataframe
    if file_type.lower() in PickleReader.file_types:
        return read_pickle
    raise ValueError(f"File type '{file_type}' not supported")
