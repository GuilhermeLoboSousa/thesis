from omnia.generics.dataframe import pd
from ._csv import CSVReader, CSVWriter
from ._utils import FilePathOrBuffer


def read_csv(filepath_or_buffer: FilePathOrBuffer, sep: str = ',', **kwargs) -> pd.DataFrame:
    """
    Function that reads the CSV file and returns a pandas pd.DataFrame.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path or file handle or url to read the CSV file from

    sep : str, default ','
        separator of the CSV file (default is ',')

    Returns
    -------
    df : pd.DataFrame
        Read DataFrame
    """
    with CSVReader(filepath_or_buffer=filepath_or_buffer, sep=sep, **kwargs) as reader:
        df = reader.read()
    return df


def write_csv(filepath_or_buffer: FilePathOrBuffer, data: pd.DataFrame, **kwargs) -> bool:
    """
    Function that writes a pandas pd.DataFrame in a CSV file.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    data : pd.DataFrame
        Dataframe to be written in the CSV file

    Returns
    -------
    flag : boolean
        whether the pd.DataFrame was written without errors
    """
    with CSVWriter(filepath_or_buffer=filepath_or_buffer, **kwargs) as writer:
        flag = writer.write(data)
    return flag
