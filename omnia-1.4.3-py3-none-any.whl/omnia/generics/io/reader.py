from abc import abstractmethod
from typing import Any, List

from ._utils import FilePathOrBuffer


class Reader:
    """
    Generic class for reading data from file(s).
    All readers must implement the read method.
    All readers must define the file_types attribute.
    """
    def __init__(self, filepath_or_buffer: FilePathOrBuffer, **kwargs):
        """
        Initializer of this class that defines instance variables such as the buffer for the file and path.

        Parameters
        ----------
        filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
            file path
        """
        self.f = filepath_or_buffer
        self.kwargs = kwargs

    def close(self):
        """
        Closes the buffer.

        Returns
        -------
        None
        """
        if hasattr(self.f, "close"):
            self.f.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    @property
    @abstractmethod
    def file_types(self) -> List[str]:
        """
        Abstract method and property that returns the file types that the reader can read.

        Returns
        -------
        file_types : List[str]
            the file types that the reader can read.
        """
        pass

    @abstractmethod
    def read(self) -> Any:
        """
        Abstract method to read the data from file(s).

        Parameters
        ----------

        Returns
        -------
        data : Any
        """
        pass
