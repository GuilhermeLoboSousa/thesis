from typing import Any, Dict, List, Union

from omnia.generics.io._utils import FilePathOrBuffer
from omnia.generics.io._yaml import YAMLReader, YAMLWriter


def read_yaml(filepath_or_buffer: FilePathOrBuffer, **kwargs) -> Union[List[Dict[str, Any]], Dict[str, Any]]:
    """
    Function that reads the YAML file and returns a dictionary.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path

    Returns
    -------
    data : Union[List[Dict[str, Any]], Dict[str, Any]]
        dictionary with the information read from the YAML file
    """
    with YAMLReader(filepath_or_buffer=filepath_or_buffer, **kwargs) as reader:
        data = reader.read()
    return data


def write_yaml(filepath_or_buffer: FilePathOrBuffer,
               data: Union[List[Dict[str, Any]], Dict[str, Any]],
               **kwargs) -> bool:
    """
    Function that writes a dictionary in a YAMl file.

    Parameters
    ----------
    filepath_or_buffer : str | Path | IO[AnyStr] | TextIO
        file path
    data : Union[List[Dict[str, Any]], Dict[str, Any]]
        object with the information to be written

    Returns
    -------
    flag : boolean
        whether the DataFrame was written without errors
    """
    with YAMLWriter(filepath_or_buffer=filepath_or_buffer, **kwargs) as writer:
        flag = writer.write(data=data)
    return flag
