import pickle
from typing import Any, List

from ._utils import get_handle_to_write, get_handle_to_read
from .reader import Reader
from .writer import Writer


class PickleReader(Reader):
    """
    Reader class for pickle files.
    It performs deserialization of pickle files.
    """
    file_types = {'pickle', 'pkl'}

    def read(self) -> Any:
        """
        Method to read the data from file(s) and return the deserialized object.

        Returns
        -------
        object : Any
            the serialized object
        """
        mode = self.kwargs.pop('mode', 'rb')
        auth = self.kwargs.pop('auth', None)
        handle = get_handle_to_read(self.f, mode=mode, auth=auth)
        with handle as f:
            return pickle.load(f)


class PickleWriter(Writer):
    """
    Writer class for pickle files.
    It performs serialization of pickle files.
    """
    @property
    def file_types(self) -> List[str]:
        """
        Property that returns the file types that this reader can read.

        Returns
        -------
        file_types : List[str]
            the file types that this reader can read
        """
        return ['pickle', 'pkl']

    def write(self, data: Any) -> bool:
        """
        Method to write the data to file(s) and return the serialized object.

        Parameters
        ----------
        data : Any
            the object to be serialized

        Returns
        -------
        flag : boolean
            whether the file was written without errors
        """
        mode = self.kwargs.pop('mode', 'wb')
        handle = get_handle_to_write(self.f, mode=mode)
        with handle as f:
            pickle.dump(data, f)
        return True
