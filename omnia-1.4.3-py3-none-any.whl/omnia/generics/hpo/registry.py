import importlib
from typing import Type, List, TYPE_CHECKING

from omnia.generics.prediction.tabular_predictor import TabularPredictor
from omnia.generics.utils.registry import RegistryMixIn
from omnia.generics.utils.singleton import singleton

if TYPE_CHECKING:
    from omnia.generics.hpo.base import BaseSearchSpace
    from omnia.generics.prediction.predictor import Predictor


@singleton
class SearchSpaceRegistry(RegistryMixIn):
    pass


search_space_registry: SearchSpaceRegistry = SearchSpaceRegistry


def _import_and_setup_search_space(name: str, subpackages: List[str]):
    """
    Tries to import the subpackages and then set up the search space.

    Parameters
    ----------
    name : str
        The name of the search space.
    subpackages : List[str]
        The list of subpackages to be imported.

    Returns
    -------
    search space
        The search space configuration.
    """
    for subpackage in subpackages:
        try:

            importlib.import_module(subpackage)
            search_space_cls = search_space_registry.get(name)

            if search_space_cls is None:
                continue

            return search_space_cls

        except ImportError:
            pass

    return


def setup_search_space(preset: str, predictor: Type['Predictor'] = TabularPredictor) -> dict:
    """
    Returns the class of the search space with the preset name.

    Parameters
    ----------
    preset : str
        The name of the preset.
    predictor : Type['Predictor']
        The predictor class.

    Returns
    -------
    search_space : dict
        The search_space configuration.
    """
    search_space_cls = search_space_registry.get(preset)

    if search_space_cls is None:

        # the sub-packages might not be imported yet
        # so we import them here using the importlib module
        # and then we try to get the preset again

        # omnia.compounds
        # omnia.deep_learning
        # omnia.generative
        # omnia.genes
        # omnia.metabolomics
        # omnia.proteins
        # omnia.transcriptomics

        search_space_cls = _import_and_setup_search_space(preset,
                                                          ['omnia.compounds',
                                                           'omnia.deep_learning',
                                                           'omnia.generative',
                                                           'omnia.genes',
                                                           'omnia.metabolomics',
                                                           'omnia.proteins',
                                                           'omnia.transcriptomics'])

        if search_space_cls is None:
            raise ValueError(f'Search Space preset {preset} not found.')

    return search_space_cls(predictor).nni_search_space()


def search_space_register(cls: Type['BaseSearchSpace']) -> Type['BaseSearchSpace']:
    """
    Decorator to register a class in the registry.

    Parameters
    ----------
    cls : Type['BaseSearchSpace']
        The class to be registered.

    Returns
    -------
    cls : Type['BaseSearchSpace']
        The class to be registered.
    """
    search_space_registry.register(cls)
    return cls
