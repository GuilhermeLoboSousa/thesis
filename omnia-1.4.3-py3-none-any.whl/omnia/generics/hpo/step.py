from typing import Any


class Step:
    """
    Class that represents a step in a pipeline.
    It allows to set up the search space for the hyperparameter optimization.

    Parameters
    ----------
    name: str
        The name of the step.
    type_ : Any
        The type of the step.
    nni_params : Any
        The value of the step.
    hp_params : Any
        The value of the step for hyperopt search space.
    """
    def __init__(self,
                 name: str,
                 type_: Any,
                 nni_params: Any,
                 hp_params: Any):
        """
        Initializes a new instance of Step.

        Parameters
        ----------
        name: str
            The name of the step.
        type_ : Any
            The type of the step.
        nni_params : Any
            The value of the step.
        hp_params : Any
            The value of the step for hyperopt search space.
        """
        self.name = name
        self.type_ = type_
        self.nni_params = nni_params
        self.hp_params = hp_params

    def to_nni(self) -> dict:
        """
        Returns a dictionary representation of the step to the NNI HPO.

        Returns
        -------
        dict
            A dictionary representation of the step.
        """
        return {self.name: {'_type': self.type_, '_value': self.nni_params}}

    def to_hp(self, idx: int) -> dict:
        """
        Returns a dictionary representation of the step to the Hyperopt HPO.

        Parameters
        ----------
        idx : int
            The index of the step.

        Returns
        -------
        dict
            A dictionary representation of the step.
        """
        return {self.name: {'idx': idx, 'params': self.hp_params}}
