from abc import ABCMeta, abstractmethod


class BaseSearchSpace(metaclass=ABCMeta):

    @classmethod
    @abstractmethod
    def nni_search_space(cls):
        ...

    @classmethod
    @abstractmethod
    def hp_search_space(cls):
        ...
