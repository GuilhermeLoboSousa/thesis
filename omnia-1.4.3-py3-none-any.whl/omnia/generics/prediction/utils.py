from typing import Tuple

from omnia.generics import pd

def concatenate_x_y(x: pd.DataFrame, y: pd.DataFrame) -> Tuple[pd.DataFrame, str]:
    """
    Concatenates the given dataframes.

    Parameters
    ----------
    x : pd.DataFrame
        The features dataframe.

    y : pd.DataFrame
        The labels dataframe.

    Returns
    -------
    pd.DataFrame
        The concatenated dataframe.

    label : str
        The label of the concatenated dataframe.
    """
    # autogluon's tabular predictor requires a single pandas dataframe
    index = x.index.copy()
    x = x.reset_index(drop=True)
    y = y.reset_index(drop=True)
    data = pd.concat([x, y], axis=1).reset_index(drop=True).set_index(index)
    label = data.columns[-1]
    if (data.columns == label).sum() > 1:
        raise ValueError("The name for label columns are not unique.")
    return data, label


def concatenate_train_val(train: Tuple[pd.DataFrame, pd.DataFrame], val: Tuple[pd.DataFrame, pd.DataFrame]) -> Tuple[pd.DataFrame, str]:
    """
    Concatenates the given train and validation dataframes.

    Parameters
    ----------
    train : Tuple[pd.DataFrame, pd.DataFrame]
        The features and labels dataframes for training.

    val : Tuple[pd.DataFrame, pd.DataFrame]
        The features and labels dataframes for validation.

    Returns
    -------
    pd.DataFrame
        The concatenated dataframe.

    label : str
        The label of the concatenated dataframe.
    """
    x_train, y_train = train
    x_val, y_val = val
    x = pd.concat([x_train, x_val], axis=0)
    y = pd.concat([y_train, y_val], axis=0)
    return concatenate_x_y(x, y)
