import os
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Type, Union, Any

from autogluon.core.utils import infer_problem_type
from autogluon.tabular import TabularPredictor as AutoGluonTabularPredictor

from .utils import concatenate_x_y, concatenate_train_val
from omnia.generics.setup import get_estimator
from omnia.generics.dataframe import pd
from omnia.generics.io import write_pickle, read_pickle, write_json, read_json
from omnia.generics.model._models import _MODELS
from omnia.generics.setup.registry import class_register
from omnia.generics.utils.keywords import kwargs_only
from .predictor import Predictor
from ..validation.boolean_operators.base_validator import BaseValidator
from ..validation.boolean_operators.operand_holders import OperandHolder
from omnia.generics.model import AutoGluonBaseModel, AutoGluonModel
from omnia.generics import pd, np
from ..validation.data_tag import DataTag
from ..validation.task_tag import TaskTag

_ModelsType = Union[
    None,
    List[Type[AutoGluonBaseModel]],
    List[Type[AutoGluonModel]],
    Dict[Type[AutoGluonBaseModel], Dict],
    Dict[Type[AutoGluonModel], Dict]
]


@class_register
class TabularPredictor(Predictor):
    """
    A tabular predictor can fit several models to input data in a tabular format.
    The predictor can then predict the labels (classification) or values (regression)
    for new data using the fitted models.

    The predictor can be thought of as wrapper around a list of machine learning models.
    The predictor is capable of performing single or ensemble learning using bagging and stacking to combine multiple
    models during fit.

    Parameters
    ----------
    models : Union[str,
        List[Type[Model]],
        List[Type[AutoGluonModel]],
        Dict[Type[Model], Dict],
        Dict[Type[AutoGluonModel], Dict]], optional (default='medium_quality')
        Either a single model, a list of models, or a dict of models with custom paremters
        that the predictor will fit to the input data.

        Alternatively, a preset of models can be selected according to the quality of the models to be generated.
        If default (None), medium_quality will be used.
        The quality argument can significantly impact predictive accuracy, memory-footprint, and inference latency.
        As an example, to get the most accurate overall predictor (regardless of its efficiency) use 'best_quality'

        Options:
            -'best_quality' - Best predictive accuracy with little consideration to inference time or disk usage.
            -'high_quality' - High predictive accuracy with ~10x-200x fast inference and ~10x-200x lower disk usage.
            -'good_quality' - Good predictive accuracy with ~4x fast inference and ~4x lower disk usage.
            -'medium_quality' - Medium predictive accuracy with ~20x fast inference.
            -'optimize_for_deployment' - Optimized for deployment with ~2-4x lower disk usage.
            -'ignore_text' - Disables automated feature generation when text features are detected

    problem_type : str, optional (default=None)
        Type of problem to solve.

        If default (None), the problem_type is inferred from the data.

        Options:
            -'binary'
            -'multiclass'
            -'regression'
            -'quantile'

    metric : str, optional (default=None)
        Metric to use for evaluation.

        If default (None) the metric is inferred based on the problem_type.
        Defaults:
            -'accuracy' for binary classification
            -'accuracy' for multiclass classification
            -'root_mean_squared_error' for regression
            -'pinball_loss' for quantile

        Options for classification:
            -'accuracy'
            -'balanced_accuracy'
            -'f1'
            -'f1_macro'
            -'f1_micro'
            -'f1_weighted'
            -'roc_auc'
            -'roc_auc_ovo_macro'
            -'average_precision'
            -'precision'
            -'precision_macro'
            -'precision_micro'
            -'precision_weighted'
            -'recall'
            -'recall_macro'
            -'recall_micro'
            -'recall_weighted'
            -'log_loss'
            -'pac_score'

        Options for regression:
            -'root_mean_squared_error'
            -'mean_squared_error'
            -'mean_absolute_error'
            -'median_absolute_error'
            -'r2'

        For more information on these options,
        see `sklearn.metrics`: https://scikit-learn.org/stable/modules/classes.html#sklearn-metrics-metrics

    path : str, optional (default=None)
        Path to directory where models and intermediate outputs will be saved.
        If default (None), a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        will be created in the working directory to store all models.

    time_limit : int, optional (default=None)
        Maximum number of seconds to run the predictor. If the predictor is still running after this time,
        it will be terminated.
        If default (None), the predictor will finish when all models have been fitted to the data.

    keep_only_best : bool, optional (default=False)
        If True, only the best model and its ancestor models are saved in the outputted `predictor`.
        All other models are deleted.
        If False, all models will be kept.

    save_space : bool, optional (default=True)
        If True, reduces the memory and disk size of predictor by deleting auxiliary model files
        These models are not required for prediction on new data.
        These files are only used to optimize the predictor's refit.

    Attributes
    ----------
    learner : autogluon.tabular.TabularPredictor
        AutoGluon's tabular predictor object.
        This object is the core engine of omnia's predictors.

    models : dict of omnia.models.Model
        Dictionary of models that have been fitted to the data.
        Each model is a type of `omnia.models.Model`.
        The models are ordered by the order in which they were fitted.

    Examples
    --------
    >>> from omnia.generics import TabularPredictor
    >>> from omnia.generics import pd
    >>> from omnia.generics.model import *
    >>> predictor_path = 'predictor_folder'
    >>> predictor = TabularPredictor(models=[RandomForestModel,
                                         ...MultilayerPerceptronNN,
                                         ...CatBoostModel,
                                         ...KNNModel,
                                         ...LGBModel,
                                         ...LinearModel,
                                         ...FastAINN,
                                         ...VowpalWabbitModel,
                                         ...XGBoostModel,
                                         ...XTModel,
                                         ...SupportVectorMachineModel],
                                         ...path=predictor_path,
                                         ...time_limit=120)

    >>> x = pd.DataFrame([[1, 2, 10, 11, 12, 9], [3, 4, 10, 11, 12, 9], [5, 6, 10, 11, 12, 9]])
    >>> y = pd.DataFrame([1, 0, 0])
    >>> x_test = pd.DataFrame([[1, 2, 10, 11, 12, 9], [9, 10, 10, 11, 12, 9], [11, 12, 10, 11, 12, 9]])
    >>> y_test = pd.DataFrame([0, 0, 0])

    >>> predictor.fit(x, y)

    >>> predictor.predict(x_test)
    >>> predictor.predict_proba(x_test)
    >>> predictor.leaderboard(x_test, y_test)
    >>> predictor.score(x_test, y_test)
    """

    name = 'TabularPredictor'
    _input_type = DataTag.TABULAR
    _estimator_type = [TaskTag.BINARY, TaskTag.MULTICLASS, TaskTag.REGRESSION]

    @kwargs_only(has_self=True)
    def __init__(self,
                 models: _ModelsType = None,
                 problem_type: Optional[str] = None,
                 metric: Optional[str] = None,
                 path: Optional[str] = None,
                 hyperparameter_tune_kwargs: Optional[Dict] = None,
                 auto_stack: bool = False,
                 num_bag_folds: int = None,
                 num_bag_sets: int = None,
                 num_stack_levels: int = None,
                 time_limit: Optional[int] = None,
                 keep_only_best: bool = False,
                 save_space: bool = True,
                 num_gpus: int = None):
        """
        Initialize the predictor.

        Parameters
        ----------
        models : list or dict, optional (default to all models)
            Either a list of models (default parameters to be used) or a dict of models with custom parameters
            that the predictor will fit to the input data.
            If not specified, all models will be used with default parameters.

        problem_type : str, optional (default=None)
            Type of problem to solve.

            If default (None), the problem_type is inferred from the data.

            Options:
                -'binary'
                -'multiclass'
                -'regression'
                -'quantile'

        metric : str, optional (default=None)
            Metric to use for evaluation.

            If default (None) the metric is inferred based on the problem_type.
            Defaults:
                -'accuracy' for binary classification
                -'accuracy' for multiclass classification
                -'root_mean_squared_error' for regression
                -'pinball_loss' for quantile

            Options for classification:
                -'accuracy'
                -'balanced_accuracy'
                -'f1'
                -'f1_macro'
                -'f1_micro'
                -'f1_weighted'
                -'roc_auc'
                -'roc_auc_ovo_macro'
                -'average_precision'
                -'precision'
                -'precision_macro'
                -'precision_micro'
                -'precision_weighted'
                -'recall'
                -'recall_macro'
                -'recall_micro'
                -'recall_weighted'
                -'log_loss'
                -'pac_score'

            Options for regression:
                -'root_mean_squared_error'
                -'mean_squared_error'
                -'mean_absolute_error'
                -'median_absolute_error'
                -'r2'

            For more information on these options,
            see `sklearn.metrics`: https://scikit-learn.org/stable/modules/classes.html#sklearn-metrics-metrics

        path : str, optional (default=None)
            Path to directory where models and intermediate outputs will be saved.
            If default (None), a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
            will be created in the working directory to store all models.

        hyperparameter_tune_kwargs : dict, optional (default=False)
            Dictionary of kwargs to pass to the hyperparameter_tune function.
            If this is set None, then no hyperparameter tuning will be performed.
            Example: {'num_trials': 10,
                     'scheduler': 'local',
                     'searcher': "auto",
                    }

        auto_stack : bool, optional (default=False)
            If True, the predictor will automatically use bagging and stacking to improve predictive accuracy.
            If False, the predictor will not use bagging and stacking.
            It automatically sets `num_bag_folds` and `num_stack_levels` to adequate values for the problem and data.
            Note: This option will increase the time it takes to train the predictor.

        num_bag_folds : int, optional (default=None)
            Number of folds to use for bagging. If default (None), there is no bagging.
            Values between 5-10 can be used to increase predictive accuracy.

        num_bag_sets : int, optional (default=None)
            Number of bag sets to use for bagging. It sets up the number of repetitions of the bagging.
            If default (None), there is no repetition of the bagging.
            Values greater than 1 will result in superior predictive performance,
            especially on smaller problems and with stacking enabled (reduces overall variance)

        num_stack_levels : int, optional (default=None)
            Number of levels to use for stacking. If default (None), there is no stacking.
            Values between 1-3 can be used to increase predictive accuracy. Otherwise, the models may be overfit.

        time_limit : int, optional (default=None)
            Maximum number of seconds to run the predictor. If the predictor is still running after this time,
            it will be terminated.
            If default (None), the predictor will finish when all models have been fitted to the data.

        keep_only_best : bool, optional (default=False)
            If True, only the best model and its ancestor models are saved in the outputted `predictor`.
            All other models are deleted.
            If False, all models will be kept.

        save_space : bool, optional (default=True)
            If True, reduces the memory and disk size of predictor by deleting auxiliary model files
            These models are not required for prediction on new data.
            These files are only used to optimize the predictor's refit.
        num_gpus : int, optional (default=None)
            Number of GPUs to use for training. If None, will use CPU.
        """
        # this private attribute will be set during fit
        self._learner = None
        self._fitted = False

        if models is None:
            self._models = _MODELS.copy()

        elif isinstance(models, (list, tuple)):
            self._models = {model: {} for model in models}

        elif isinstance(models, dict):
            self._models = dict(models)

        else:
            raise ValueError('models must be a list or dict')

        self._path = None
        self._ag_path = None
        self._num_gpus = num_gpus

        self._ag_kwargs = {
            'problem_type': problem_type,
            'eval_metric': metric,
            'auto_stack': auto_stack,
            'num_bag_folds': int(num_bag_folds) if num_bag_folds is not None else None,
            'num_bag_sets': int(num_bag_sets) if num_bag_sets is not None else None,
            'num_stack_levels': int(num_stack_levels) if num_stack_levels is not None else None,
            'time_limit': int(time_limit) if time_limit is not None else None,
            'keep_only_best': keep_only_best,
            'save_space': save_space,
            'num_gpus': num_gpus,
        }

        if hyperparameter_tune_kwargs is not None:
            hpo = True
            n_trials = int(hyperparameter_tune_kwargs['num_trials'])
            hyperparameter_tune_kwargs['num_trials'] = n_trials
            self._ag_kwargs['hyperparameter_tune_kwargs'] = hyperparameter_tune_kwargs

        else:
            hpo = False
            self._ag_kwargs['hyperparameter_tune_kwargs'] = None

        self._predictor_kwargs = {
            'path': path,
            'problem_type': problem_type,
            'metric': metric,
            'hpo': hpo,
            'time_limit': time_limit,
            'keep_only_best': keep_only_best,
            'save_space': save_space
        }

    @property
    def learner(self) -> AutoGluonTabularPredictor:
        """
        It returns AutoGluon's tabular predictor object. This object is the core engine of omnia's predictors.

        Returns
        -------
        learner : AutoGluonTabularPredictor
            The AutoGluonTabularPredictor object.
        """
        return self._learner

    @property
    def models(self) -> Dict[Type[AutoGluonBaseModel], Dict]:
        """
        It returns the list of models of this predictor.

        Returns
        -------
        models : Dict[Type[AutoGluonBaseModel], Dict]
            The dict of models.
        """
        return self._models.copy()

    @property
    def problem_type(self) -> str:
        """
        It returns the problem type of this predictor.

        Returns
        -------
        problem_type : str
            The problem type.
        """
        if self.learner is None:
            return self._predictor_kwargs['problem_type']
        return self.learner.problem_type

    @property
    def metric(self) -> str:
        """
        It returns the metric of this predictor.

        Returns
        -------
        metric : str
            The metric.
        """
        if self.learner is None:
            return self._predictor_kwargs['metric']
        return self.learner.eval_metric

    @property
    def path(self) -> str or None:
        """
        It returns the path of this predictor.
        Note that a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        could have been created in the working directory to store all models.

        Returns
        -------
        path : str or None
            The path.
        """
        return self._path

    @path.setter
    def path(self, value: str):
        """
        It sets the path of this predictor.
        Note that a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        could have been created in the working directory to store all models.

        Parameters
        ----------
        value : str
            The path.
        """
        if self.fitted:
            if value == self._path:
                return

            raise Exception(
                'The predictor is already fitted. You cannot change path after fitting.')

        if value is None:
            current_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
            value = os.path.join(
                os.getcwd(), f'omnia-predictor-{current_time}')

        if not os.path.exists(value):
            Path(value).mkdir(parents=True, exist_ok=True)

        ag_path = os.path.join(value, 'autogluon')

        if not os.path.exists(ag_path):
            Path(ag_path).mkdir(parents=True, exist_ok=True)

        self._predictor_kwargs['path'] = value
        self._path = value
        self._ag_path = ag_path

    @property
    def ag_path(self) -> str or None:
        """
        It returns the path of AutoGluon's predictor.

        Returns
        -------
        ag_path : str or None
            The path.
        """
        return self._ag_path

    @property
    def time_limit(self) -> int:
        """
        It returns the time limit of this predictor.

        Returns
        -------
        time_limit : int
            The time limit.
        """
        return self._predictor_kwargs['time_limit']

    @property
    def keep_only_best(self) -> bool:
        """
        It returns whether only the best model and its ancestor models are saved in the outputted `predictor`.

        Returns
        -------
        keep_only_best : bool
            Whether only the best model and its ancestor models are saved in the outputted `predictor`.
        """
        return self._predictor_kwargs['keep_only_best']

    @property
    def save_space(self) -> bool:
        """
        It returns whether the predictor saves space by removing intermediate files.

        Returns
        -------
        save_space : bool
            Whether the predictor saves space by removing intermediate files.
        """
        return self._predictor_kwargs['save_space']

    @property
    def hyperparameter_tune_kwargs(self) -> bool:
        """
        It returns whether the predictor is hyperparameter optimized.

        Returns
        -------
        hpo : bool
            Whether the predictor is hyperparameter optimized.
        """
        return self._ag_kwargs['hyperparameter_tune_kwargs']

    @property
    def hpo(self) -> bool:
        """
        It returns whether the predictor is hyperparameter optimized.

        Returns
        -------
        hpo : bool
            Whether the predictor is hyperparameter optimized.
        """
        return self._predictor_kwargs['hpo']

    @property
    def auto_stack(self) -> bool:
        """
        It returns whether the predictor is auto-stacked.

        Returns
        -------
        auto_stack : bool
            Whether the predictor is auto-stacked.
        """
        return self._ag_kwargs['auto_stack']

    @property
    def num_bag_folds(self) -> int:
        """
        It returns the number of bagging folds of this predictor.

        Returns
        -------
        num_bag_folds : int
            The number of bagging folds.
        """
        return self._ag_kwargs['num_bag_folds']

    @property
    def num_bag_sets(self) -> int:
        """
        It returns the number of bagging sets of this predictor.

        Returns
        -------
        num_bag_sets : int
            The number of bagging sets.
        """
        return self._ag_kwargs['num_bag_sets']

    @property
    def num_stack_levels(self) -> int:
        """
        It returns the number of stacking levels of this predictor.

        Returns
        -------
        num_stack_levels : int
            The number of stacking levels.
        """
        return self._ag_kwargs['num_stack_levels']

    @property
    def fitted(self) -> bool:
        """
        It returns whether the predictor is fitted.

        Returns
        -------
        fitted : bool
            Whether the predictor is fitted.
        """
        return self._fitted

    @property
    def can_predict_proba(self) -> bool:
        """
        Return True if predictor can return prediction probabilities via `.predict_proba`, otherwise return False.
        Raises an AssertionError if called before fitting.
        """
        return self.learner.can_predict_proba

    @property
    def tags(self) -> List[Type]:
        """
        Return the tags of the used models that will be used to validate the input data.

        Returns
        -------
        tags : list
            The list of tags for the models.
        """
        all_tags = set()
        for model in self._models:
            all_tags.update(set(model.tags))
        return list(all_tags)

    def get_models_hyperparameters(self):
        # see the fix below
        # from omnia.generics import VowpalWabbitModel
        # from autogluon.tabular.models.vowpalwabbit.vowpalwabbit_model import logger as vw_logger

        hpo = self._predictor_kwargs.get('hpo', False)
        use_default = not hpo

        hyperparameters = {}
        for model, custom in self._models.items():

            model_hyperparameters = model.get_hyperparameters(default=use_default,
                                                              problem_type=self._ag_kwargs['problem_type'],
                                                              use_alias=True)
            hyperparameters[model] = {**model_hyperparameters, **custom}

        return hyperparameters

    def is_tag_compatible(self, previous_output: Union[OperandHolder, BaseValidator]) -> bool:
        """
        Check if tag is compatible with input tag

        Parameters
        ----------
        previous_output: OperandHolder | BaseValidator

        Returns
        -------
        bool
            Whether the tag is compatible with input tag.
        """
        validations = []
        for model in self._models:
            validations.append(model.is_tag_compatible(
                previous_output=previous_output))
        return all(validations)

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        The validation method performs fast and straightforward checks to the data.
        It returns a boolean value indicating whether the data is valid or not.

        Parameters
        ----------

        x : Any, optional
            The data used to fit the model.

        y : Any, optional
            The target used to fit the model.

        Returns
        -------
        bool
            True if the value is valid, False otherwise.
        """
        validations = []
        for model in self._models:
            validations.append(model.validate(x, y))
        return all(validations)

    def fit(self,
            x: Any,
            y: Any,
            x_val: Any = None,
            y_val: Any = None,
            problem_type: str = None) -> 'TabularPredictor':
        """
        It fits the predictor to the given data.
        In detail, it calls `fit` method of AutoGluon's tabular predictor object.
        This object is the core engine of omnia's predictors that will fit a series of models to the given data.

        Parameters
        ----------
        x : Any
            The training data.

        y : Any
            The target variable.

        x_val : Any, optional
            The validation data.

        y_val : Any, optional
            The validation target.
        problem_type: str
            NOT USED IN TABULAR PREDICTOR!
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        predictor : Predictor
            The fitted predictor.
        """
        # build paths
        self.path = self._predictor_kwargs['path']

        if isinstance(x, np.ndarray):
            x = pd.DataFrame(
                x, columns=[f'col_{i}' for i in range(x.shape[1])])
        if isinstance(x_val, np.ndarray):
            x_val = pd.DataFrame(
                x_val, columns=[f'col_{i}' for i in range(x_val.shape[1])])
        if isinstance(y, np.ndarray):
            y = pd.DataFrame(y, columns=['target'])
        if isinstance(y_val, np.ndarray):
            y_val = pd.DataFrame(y_val, columns=['target'])

        # build train data
        data, label = concatenate_x_y(x, y)

        # build validation data
        if x_val is not None and y_val is not None and not self._ag_kwargs['auto_stack']:
            data_val, _ = concatenate_x_y(x_val, y_val)
        elif x_val is not None and y_val is not None and self._ag_kwargs['auto_stack']:
            data, label = concatenate_train_val((x, y), (x_val, y_val))
            data_val, _ = None, None
        else:
            data_val, _ = None, None

        # infer problem type using AUTOGLUON
        if not self._ag_kwargs['problem_type']:
            self._ag_kwargs['problem_type'] = problem_type or infer_problem_type(
                data[label].copy(), silent=True)

        # build the autogluon's predictor
        init_kwargs = {
            'label': label,
            'problem_type': self._ag_kwargs['problem_type'],
            'eval_metric': self._ag_kwargs['eval_metric'],
            'path': self.ag_path
        }
        self._learner = AutoGluonTabularPredictor(**init_kwargs)

        # fit the autogluon's predictor
        hyperparameters = self.get_models_hyperparameters()

        fit_kwargs = {
            'train_data': data,
            'hyperparameters': hyperparameters,
            'auto_stack': self._ag_kwargs['auto_stack'],
            'num_bag_folds': self._ag_kwargs['num_bag_folds'],
            'num_bag_sets': self._ag_kwargs['num_bag_sets'],
            'num_stack_levels': self._ag_kwargs['num_stack_levels'],
            'time_limit': self._ag_kwargs['time_limit'],
            'keep_only_best': self._ag_kwargs['keep_only_best'],
            'save_space': self._ag_kwargs['save_space']}

        if data_val is not None:
            fit_kwargs['tuning_data'] = data_val

        if self.hpo:
            fit_kwargs['hyperparameter_tune_kwargs'] = self._ag_kwargs['hyperparameter_tune_kwargs']

        # TODO: verbosity=3 was a workaround to solve issues with autogluon version 1.1.0 (check alternative later)
        self._learner.fit(**fit_kwargs, verbosity=3)
        self._fitted = True
        return self

    def predict(self, x: Any, model: str = None) -> Any:
        """
        It predicts the target variable for the given data.
        In detail, it calls `predict` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.

        Returns
        -------
        y_pred : Any
            The predicted target variable.
        """
        x = x.copy()
        predictions = self.learner.predict(x, model=model)
        if predictions.ndim == 1:
            predictions = np.expand_dims(predictions, axis=1)
        return predictions

    def predict_proba(self, x: Any, model: str = None) -> Any:
        """
        It predicts the probabilities of the target variable for the given data.
        In detail, it calls `predict_proba` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.

        Returns
        -------
        y_pred : pd.DataFrame
            The predicted probabilities of the target variable.
        """
        x = x.copy()
        if isinstance(x, np.ndarray):
            x = pd.DataFrame(
                x, columns=[f'col_{i}' for i in range(x.shape[1])])

        pred = self.learner.predict_proba(x, model=model).values
        # handle binary tasks -> turn [x y] where x+y=1 into [y]
        if pred.shape[-1] == 2:
            if pred.ndim == 2:
                pred = pred[:, 1].reshape(-1, 1)
            else:
                pred = pred[:, :, 1]
        else:  # handle multiclass tasks
            pred = np.expand_dims(pred, axis=1)
        return pred

    def leaderboard(self, x: Any = None, y: Any = None) -> pd.DataFrame:
        """
        It returns the leaderboard according to the fit process or for the given data.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.

        Returns
        -------
        leaderboard : pd.DataFrame
            The leaderboard.
        """
        if x is None and y is None:
            return self.learner.leaderboard()

        index = x.index.copy()
        x = x.reset_index(drop=True)
        y = y.reset_index(drop=True)
        data = pd.concat([x, y], axis=1).reset_index(
            drop=True).set_index(index)

        return self.learner.leaderboard(data)

    def score(self, x: Any, y: Any, model: str = None) -> Dict[str, float]:
        """
        It returns the score of the given model.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.
        model : str, optional (default=None)
            The model name to be used for prediction.
            If None, it uses the best model.

        Returns
        -------
        score : Dict[str, float]
            It returns a dictionary where keys are metrics and values are performance along each metric.
        """
        # autogluon's tabular predictor requires a single pandas dataframe
        if isinstance(y, np.ndarray):
            y = pd.DataFrame(y)
        index = x.index.copy()
        x = x.reset_index(drop=True)
        y = y.reset_index(drop=True)
        data = pd.concat([x, y], axis=1).reset_index(
            drop=True).set_index(index)

        return self.learner.evaluate(data, model=model, silent=True)

    @property
    def best_model(self) -> str:
        """
        It returns the best model name.

        Returns
        -------
        best_model : str
            The best model name.
        """
        return self.learner.get_model_best()

    def __getstate__(self):
        state = self.__dict__.copy()
        state.pop("_learner", None)
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)

    def save(self) -> bool:
        """
        It saves the object to a pickle file in the path specified by `self.path`.

        Returns
        -------
        bool : bool
            True if the object is saved successfully.
        """
        self.learner.save()
        path = os.path.join(self.path, 'tabular_predictor.pkl')
        return write_pickle(path, self)

    @classmethod
    def load(cls, path: str) -> 'TabularPredictor':
        """
        It loads the object from a pickle file.

        Parameters
        ----------
        path : str
            The path to the predictor folder.

        Returns
        -------
        TabularPredictor
            The loaded object.
        """
        predictor_path = os.path.join(path, 'tabular_predictor.pkl')
        ag_path = os.path.join(path, 'autogluon')

        learner = AutoGluonTabularPredictor.load(ag_path)
        instance = read_pickle(predictor_path)

        instance._learner = learner
        return instance

    def to_dict(self) -> Dict:
        """
        It returns the dictionary representation of the object.

        Returns
        -------
        dict : Dict
            The dictionary representation of the object.
        """
        hyperparameters = self.get_models_hyperparameters()
        models = [{'name': model.name, 'parameters': model_hyperparameters}
                  for model, model_hyperparameters in hyperparameters.items()]

        parameters = {'models': models,
                      'problem_type': self.problem_type,
                      'metric': str(self.metric),
                      'hyperparameter_tune_kwargs': self.hyperparameter_tune_kwargs,
                      'time_limit': self.time_limit,
                      'keep_only_best': self.keep_only_best,
                      'save_space': self.save_space}

        return {'name': 'TabularPredictor',
                'parameters': parameters}

    @classmethod
    def from_dict(cls, state: Dict) -> 'TabularPredictor':
        """
        It returns the object from the dictionary representation.

        Parameters
        ----------
        state : Dict
            The dictionary representation of the object.

        Returns
        -------
        TabularPredictor
            The object.
        """
        parameters = state['parameters']

        models = parameters.get('models')
        problem_type = parameters.get('problem_type')
        metric = parameters.get('metric')
        path = parameters.get('path')
        hyperparameter_tune_kwargs = parameters.get(
            'hyperparameter_tune_kwargs')
        time_limit = parameters.get('time_limit')
        keep_only_best = parameters.get('keep_only_best', False)
        save_space = parameters.get('save_space', True)

        models = {get_estimator(model['name'])                  : model['parameters'] for model in models}

        instance = cls(models=models,
                       problem_type=problem_type, metric=metric,
                       path=path,
                       hyperparameter_tune_kwargs=hyperparameter_tune_kwargs, time_limit=time_limit,
                       keep_only_best=keep_only_best, save_space=save_space)
        return instance

    def to_json(self, file_path: str):
        """
        Saves an estimator object into a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        success : bool
            True if the operation was successful, False otherwise.
        """
        state = self.to_dict()
        return write_json(file_path, state)

    @classmethod
    def from_json(cls, file_path: str) -> 'TabularPredictor':
        """
        Loads an estimator object from a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        estimator : estimator object
            The estimator object.

        """
        state = read_json(file_path)
        return cls.from_dict(state)
