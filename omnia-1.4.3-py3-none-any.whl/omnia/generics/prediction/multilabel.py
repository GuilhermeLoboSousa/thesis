import os
from datetime import datetime
from typing import List, Dict, Type, Union, Any

from omnia.generics import np
from omnia.generics.dataframe import pd
from autogluon.tabular import TabularPredictor as AutoGluonTabularPredictor
from sklearn.metrics import jaccard_score

from omnia.generics.model import AutoGluonBaseModel, AutoGluonModel
from omnia.generics.prediction.predictor import Predictor
from omnia.generics.setup.registry import class_register
from omnia.generics.setup import get_estimator
from omnia.generics.prediction import TabularPredictor
from omnia.generics.io import write_pickle, read_pickle, write_json, read_json
from omnia.generics.utils.keywords import kwargs_only

_ModelsType = Union[
    None,
    List[Type[AutoGluonBaseModel]],
    List[Type[AutoGluonModel]],
    Dict[Type[AutoGluonBaseModel], Dict],
    Dict[Type[AutoGluonModel], Dict]
]


@class_register
class MultiLabelTabularPredictor(Predictor):
    """
    A multilabel predictor can fit several models to the same training dataset in a tabular format.
    The predictor can then predict several labels (classification) for new data using the fitted models.

    The predictor can be thought of as wrapper around a list of machine learning models for a list of labels.
    The predictor is capable of performing single or ensemble learning using bagging and stacking to combine multiple
    models during fit, similarly to the Tabular predictor it is based on

    Parameters
    ----------
    models : Union[str,
        List[Type[Model]],
        List[Type[AutoGluonModel]],
        Dict[Type[Model], Dict],
        Dict[Type[AutoGluonModel], Dict]], optional (default='medium_quality')
        Either a single model, a list of models, or a dict of models with custom paremters
        that the predictor will fit to the input data.

        Alternatively, a preset of models can be selected according to the quality of the models to be generated.
        If default (None), medium_quality will be used.
        The quality argument can significantly impact predictive accuracy, memory-footprint, and inference latency.
        As an example, to get the most accurate overall predictor (regardless of its efficiency) use 'best_quality'

        Options:
            -'best_quality' - Best predictive accuracy with little consideration to inference time or disk usage.
            -'high_quality' - High predictive accuracy with ~10x-200x fast inference and ~10x-200x lower disk usage.
            -'good_quality' - Good predictive accuracy with ~4x fast inference and ~4x lower disk usage.
            -'medium_quality' - Medium predictive accuracy with ~20x fast inference.
            -'optimize_for_deployment' - Optimized for deployment with ~2-4x lower disk usage.
            -'ignore_text' - Disables automated feature generation when text features are detected

        All label predictors will share this list of models.

    problem_type : Union[str, List[str]], optional (default=None)
        Type of problem to solve.

        If default (None), the problem_type is inferred from the data.
        A different problem type for each kind of data can be provided in the form a array.

        Options:
            -'binary'
            TODO: Implement multiple problem score metrics

    metric : str, optional (default=None)
        Metric to use for evaluation of the overall multilabel strategy.

        Defaults:
            -'jaccard_score_macro' for binary classification

    problem_metrics :  Union[str, List[str]], optional (default=None)
        Metric to use for evaluation of each label predictor.
        Refer to the TablularPredictor Documentation for an updated list.

    path : str, optional (default=None)
        Path to directory where models and intermediate outputs will be saved.
        If default (None), a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        will be created in the working directory to store all models.

    time_limit : int, optional (default=None)
        Maximum number of seconds to run each label predictor predictor. If the predictor is still running after this time,
        it will be terminated, and the following predictor initiated.
        If default (None), all predictors will finish when all models have been fitted to the data.

    keep_only_best : bool, optional (default=False)
        If True, only the best model and its ancestor models are saved in the outputted `predictor`.
        All other models are deleted.
        If False, all models will be kept.

    save_space : bool, optional (default=True)
        If True, reduces the memory and disk size of predictor by deleting auxiliary model files
        These models are not required for prediction on new data.
        These files are only used to optimize the predictor's refit.

    Attributes
    ----------
    learner : Dict[str, autogluon.tabular.TabularPredictor]
        AutoGluon's tabular predictor object for each label.
        This object is the core engine of omnia's predictors.

    models : dict of dict of omnia.models.Model
        Dictionary of models that have been fitted to the data for each label.
        Each model is a type of `omnia.models.Model`.
        The models are ordered by the order in which they were fitted.

    Examples
    --------
    >>> from omnia.generics import MultiLabelTabularPredictor
    >>> from omnia.generics import pd
    >>> from omnia.generics.model import *
    >>> predictor_path = 'predictor_folder'
    >>> predictor = MultiLabelTabularPredictor(labels=["1", "2"],
                                        ...models=[RandomForestModel,
                                        ...MultilayerPerceptronNN,
                                        ...CatBoostModel,
                                        ...KNNModel,
                                        ...LGBModel,
                                        ...LinearModel,
                                        ...FastAINN,
                                        ...VowpalWabbitModel,
                                        ...XGBoostModel,
                                        ...XTModel,
                                        ...SupportVectorMachineModel],
                                        ...path=predictor_path,
                                        ...time_limit=120)
    >>> x = pd.DataFrame([[1, 2, 10, 11, 12, 9], [3, 4, 10, 11, 12, 9], [5, 6, 10, 11, 12, 9]])
    >>> y = pd.DataFrame([[1, 0],[0,1], [1,1]], columns=["1", "2"])
    >>> x_test = pd.DataFrame([[1, 2, 10, 11, 12, 9], [9, 10, 10, 11, 12, 9], [11, 12, 10, 11, 12, 9]])
    >>> y_test = pd.DataFrame([[0, 1],[0,1], [0,1]], columns=["1", "2"])

    >>> predictor.fit(x, y)

    >>> predictor.predict(x_test)
    >>> predictor.predict_proba(x_test)
    >>> predictor.leaderboard(x_test, y_test)
    >>> predictor.score(x_test, y_test)
    """

    name = 'MultiLabelTabularPredictor'

    @kwargs_only(has_self=True)
    def __init__(self,
                 labels: List[str],
                 models: _ModelsType = None,
                 metric: str = "jaccard_score_macro",
                 problem_type: Union[str, List[str]] = None,
                 problem_metrics: Union[str, List[str]] = None,
                 path=None,
                 **kwargs):
        """
        Initialize the predictor.

        Parameters
        ----------
        models : list or dict, optional (default to all models)
            Either a list of models (default parameters to be used) or a dict of models with custom parameters
            that the predictor will fit to the input data.
            If not specified, all models will be used with default parameters.

            All label predictors will share this list of models.

        problem_type : List[str], optional (default=None)
            Type of problem to solve.

            If default (None), the problem_type is inferred from the data.
            A different problem type for each kind of data can be provided in the form a array.

            Options:
                -'binary'

        metric : str, optional (default=None)
            Metric to use for evaluation of the overall multilabel strategy.

            If default (None) the metric is inferred based on the problem_type.
            Defaults:
                -'jaccard_score_macro' for binary classification

        problem_metrics :  Union[str, List[str]], optional (default=None)
            Metric to use for evaluation of each label predictor.
            Refer to the TablularPredictor Documentation for an updated list.

        path : str, optional (default=None)
            Path to directory where models and intermediate outputs will be saved.
            If default (None), a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
            will be created in the working directory to store all models.

        hyperparameter_tune_kwargs : dict, optional (default=False)
            Dictionary of kwargs to pass to the hyperparameter_tune function.
            If this is set None, then no hyperparameter tuning will be performed.
            Example: {'num_trials': 10,
                     'scheduler': 'local',
                     'searcher': "auto"}

        auto_stack : bool, optional (default=False)
            If True, the predictor will automatically use bagging and stacking to improve predictive accuracy.
            If False, the predictor will not use bagging and stacking.
            It automatically sets `num_bag_folds` and `num_stack_levels` to adequate values for the problem and data.
            Note: This option will increase the time it takes to train the predictor.

        num_bag_folds : int, optional (default=None)
            Number of folds to use for bagging. If default (None), there is no bagging.
            Values between 5-10 can be used to increase predictive accuracy.

        num_bag_sets : int, optional (default=None)
            Number of bag sets to use for bagging. It sets up the number of repetitions of the bagging.
            If default (None), there is no repetition of the bagging.
            Values greater than 1 will result in superior predictive performance,
            especially on smaller problems and with stacking enabled (reduces overall variance)

        num_stack_levels : int, optional (default=None)
            Number of levels to use for stacking. If default (None), there is no stacking.
            Values between 1-3 can be used to increase predictive accuracy. Otherwise, the models may be overfit.

        time_limit : int, optional (default=None)
            Maximum number of seconds to run eacf predictor. If the predictor is still running after this time,
            it will be terminated and the next predictor in the queue initiated.
            If default (None), the predictor will finish when all models have been fitted to the data.

        keep_only_best : bool, optional (default=False)
            If True, only the best model and its ancestor models are saved in the outputted `predictor`.
            All other models are deleted.
            If False, all models will be kept.

        save_space : bool, optional (default=True)
            If True, reduces the memory and disk size of predictor by deleting auxiliary model files
            These models are not required for prediction on new data.
            These files are only used to optimize the predictor's refit.
        num_gpus : int, optional (default=None)
            Number of GPUs to use for training. If None, will use CPU.
        """
        # init the different predictors
        self._labels = labels
        self._fitted = False
        self._path = path
        self._metric = metric

        if problem_type:
            if isinstance(problem_type, list):
                non_binary_labels = [label for label, problem in zip(self._labels, problem_type) if problem != "binary"]
                # This method uses series based APIs so selection if y[label] and not y[[label]]
                # as in places where DF with col names are needed
                if non_binary_labels:
                    raise ValueError("There are label that present problem types other than binary."
                                     "These problem types are not currently fully supported."
                                     f"The labels are: {non_binary_labels}"
                                     )
            elif problem_type != "binary":
                raise ValueError("Only the binary problem type is supported currently.")

        self._predictors = {label: TabularPredictor(
            models=models,
            problem_type=problem_type[index] if isinstance(problem_type, list) else problem_type if isinstance(
                problem_type, str) else None,
            metric=problem_metrics[index] if isinstance(problem_metrics, list) else problem_metrics if isinstance(
                problem_metrics, str) else None,
            path=os.path.join(self._path, label) if path else None,
            **kwargs
        )
            for index, label in enumerate(self._labels)
        }

    @property
    def learner(self) -> Dict[str, AutoGluonTabularPredictor]:
        """
        It returns AutoGluon's tabular predictor objects for all labels.
        This object is the core engine of omnia's predictors.

        Returns
        -------
        learner : Dict[str, AutoGluonTabularPredictor]
            The AutoGluonTabularPredictor object.
        """
        return {label: predictor.learner for label, predictor in self._predictors.items()}

    def get_learner(self, label) -> AutoGluonTabularPredictor:
        """
        It returns AutoGluon's tabular predictor object for a specific label.
        This object is the core engine of omnia's predictors.

        Returns
        -------
        learner : AutoGluonTabularPredictor
            The AutoGluonTabularPredictor object.
        """
        return self._predictors.get(label).learner

    @property
    def models(self) -> Dict[str, Dict[Type[AutoGluonBaseModel], Dict]]:
        """
        It returns the dict of models for each label predictor.

        Returns
        -------
        models : Dict[str, Dict[Type[AutoGluonBaseModel], Dict]]
            The dict of models.
        """
        return {label: predictor.models for label, predictor in self._predictors.items()}

    @property
    def problem_type(self) -> Dict[str, str]:
        """
        It returns the problem type for each label predictor.

        Returns
        -------
        problem_type : Dict[str, str]
            The problem type.
        """
        return {label: predictor.problem_type for label, predictor in self._predictors.items()}

    @property
    def metric(self) -> str:
        """
        It returns the metric to use for evaluation of the overall multilabel strategy.

        Returns
        -------
        metric :  str
            The metric to use for evaluation of the overall multilabel strategy.
        """
        return self._metric

    @property
    def overall_metrics(self) -> Dict[str, str]:
        """
        It returns the metric for each label predictor.

        Returns
        -------
        metric :  Dict[str, str]
            The metric of each predictor.
        """
        return {label: predictor.metric for label, predictor in self._predictors.items()}

    @property
    def path(self) -> str or None:
        """
        It returns the path of this meta-predictor.
        Note that a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        could have been created in the working directory to store all models.

        Returns
        -------
        path : str or None
            The path.
        """
        return self._path

    @path.setter
    def path(self, value: str):
        """
        It sets the path of this predictor.
        Note that a time-stamped folder called "omnia-predictor-[TIMESTAMP]"
        could have been created in the working directory to store all models.

        Parameters
        ----------
        value : str
            The path.
        """
        if self._fitted:
            raise Exception('The predictor is already fitted. You cannot change path after fitting.')

        if value is None:
            current_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
            value = os.path.join(os.getcwd(), f'omnia-predictor-{current_time}')

        if not os.path.exists(value):
            os.makedirs(value)

        if self._predictors:
            # Checks if the predictors have been initiated yet
            for label, predictor in self._predictors.items():
                predictor.path = os.path.join(value, label)

        self._path = value

    @property
    def fitted(self) -> bool:
        """
        It returns whether the predictor is fitted.

        Returns
        -------
        fitted : bool
            Whether the predictor is fitted.
        """
        return self._fitted

    @property
    def can_predict_proba(self) -> bool:
        """
        Return True if predictor can return prediction probabilities via `.predict_proba`, otherwise return False.
        Raises an AssertionError if called before fitting.
        """
        return all([predictor.can_predict_proba for predictor in self._predictors.values()])

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        The validation method performs fast and straightforward checks to the data.
        It returns a boolean value indicating whether the data is valid or not.

        Parameters
        ----------

        x : Any, optional
            The data used to fit the model.

        y : Any, optional
            The target used to fit the model.

        Returns
        -------
        bool
            True if the value is valid, False otherwise.
        """
        validations = []
        for label, predictor in self._predictors.items():
            validations.append(predictor.validate(x, y[[label]]))
        return all(validations)

    def fit(self,
            x: Any,
            y: Any,
            x_val: Any = None,
            y_val: Any = None,
            problem_type: str = None) -> 'MultiLabelTabularPredictor':
        """
        It fits the different label predictors to the given dataset.
        In detail, it calls `fit` method of AutoGluon's tabular predictor object for each label predictor.
        This object is the core engine of omnia's predictors that will fit a series of models to the given data.

        Parameters
        ----------
        x : Any
            The training data.

        y : Any
            The target variable.

        x_val : Any, optional
            The validation data.

        y_val : Any, optional
            The validation target.
        problem_type: str
            NOT USED IN Multilabel TABULAR PREDICTOR!
            The problem type of the model. Should be one of the following:
                - "binary"
                - "multiclass"
                - "regression"

        Returns
        -------
        predictor : Predictor
            The fitted predictor.
        """
        # TODO: REMOVE WHEN THE NEW METRICS ARE ADDED
        # Check if the all the predictors about to be trained are binary, else error to prevent Pipeline Optimizations
        # to go on with problem types that cannot be assessed globally.
        from autogluon.core.utils import infer_problem_type

        non_binary_labels = [label for label in self._labels if
                             infer_problem_type(y=y[label], silent=True) != "binary"]
        # This method uses series based APIs so selection if y[label] and not y[[label]]
        # as in places where DF with col names are needed

        if non_binary_labels:
            raise ValueError("There are label that present problem types other than binary. "
                             "These problem types are not currently fully supported and will be terminated early."
                             f"The labels are: {non_binary_labels}"
                             )

        self.path = self._path

        for label in self._labels:
            self._predictors[label].fit(
                x=x,
                y=y[[label]],
                x_val=x_val,
                y_val=y_val[[label]] if y_val is not None else None
            )
        self._fitted = True
        return self

    def predict(self, x: Any, label: str = None, model: str = None) -> Any:
        """
        It predicts single or all target variables for the given data.
        In detail, it calls `predict` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        label : str, optional (default=None)
            The label name to be used for prediction.
            If None, it uses the best model.
        model : str, optional (default=None)
            The model name to be used for prediction if a specific label has been provided.
            If None, it uses the best model.
        Returns
        -------
        y_pred : Any
            The predicted target variable.
        """
        if label:
            if label in self._predictors:
                return self._predictors[label].predict(x, model=model)
            else:
                raise ValueError('The label provided is not available in the predictor.')
        else:
            return np.array([predictor.predict(x).reshape(-1) for _, predictor in self._predictors.items()]).T

    def predict_proba(self, x: Any, label: str = None, model: str = None) -> Any:
        """
        It predicts the probabilities of single or all target variables for the given data.
        In detail, it calls `predict_proba` method of AutoGluon's tabular predictor object.

        Parameters
        ----------
        x : Any
            The data.
        label : str, optional (default=None)
            The label name to be used for prediction.
            If None, it uses the best model.
        model : str, optional (default=None)
            The model name to be used for prediction if a specific label has been provided.
            If None, it uses the best model.

        Returns
        -------
        y_pred : pd.DataFrame
            The predicted probabilities of the target variable.
        """
        if label:
            if label in self._predictors:
                return self._predictors[label].predict_proba(x, model=model)
            else:
                raise ValueError('The label provided is not available in the predictor.')
        else:
            predictions = [predictor.predict_proba(x) for _, predictor in self._predictors.items()]
            return np.array(predictions).T.squeeze()

    def leaderboard(self, x: Any = None, y: Any = None) -> pd.DataFrame:
        """
        It returns the leaderboard according to the fit process or for the given data.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.

        Returns
        -------
        leaderboard : pd.DataFrame
            The leaderboard.
        """
        if x is None and y is None:
            leaderboard = []
            for label, predictor in self._predictors.items():
                label_leaderboard = predictor.leaderboard()
                label_leaderboard.insert(0, 'label', label)
                leaderboard.append(label_leaderboard)
            return pd.concat(leaderboard, ignore_index=True)

        x = x
        y = y
        leaderboard = []
        for label, predictor in self._predictors.items():
            label_leaderboard = predictor.leaderboard(x, y[[label]])
            label_leaderboard.insert(0, 'label', label)
            leaderboard.append(label_leaderboard)
        return pd.concat(leaderboard, ignore_index=True)

    def overall_score(self, x: Any, y: Any) -> pd.DataFrame:
        """
        It returns the score of the best model for each label.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.

        Returns
        -------
        score : pd.Dataframe
            It returns a dataframe where rows are metric performance values for the labels.
        """
        scores = []
        for label, predictor in self._predictors.items():
            label_score = predictor.score(x, y[[label]])
            label_score["label"] = label
            scores.append(label_score)
        return pd.DataFrame.from_records(scores)

    def score(self, x, y, model: str = None) -> Dict[str, float]:
        """
        It returns the overall score of the best models for each label.

        Parameters
        ----------
        x : Any
            The data.
        y : Any
            The target variable.
        model : str, optional (default=None)
            The model name to be used for prediction.
            In the multilabel predictor it is ignored.


        Returns
        -------
        score : Dict[str, float]
            It returns a dictionary where keys are metrics and values are performance along each metric.
        """
        pred_y = self.predict(x)
        score = jaccard_score(y, pred_y, average="macro")
        return {"jaccard_score_macro": score}

    @property
    def best_model(self) -> Dict[str, str]:
        """
        It returns the best model name for each label.

        Returns
        -------
        best_model : str
            The best model name.
        """
        return {label: predictor.best_model for label, predictor in self._predictors.items()}

    def save(self) -> bool:
        """
        It saves the object to a pickle file in the path specified by `self.path`.

        Returns
        -------
        bool : bool
            True if the object is saved successfully.
        """
        for predictor in self._predictors.values():
            predictor.save()
        path = os.path.join(self._path, 'multilabel_predictor.pkl')
        return write_pickle(path, self)

    @classmethod
    def load(cls, path) -> 'MultiLabelTabularPredictor':
        """
        It loads the object from a pickle file.

        Parameters
        ----------
        path : str
            The path to the predictor folder.

        Returns
        -------
        MultiLabelTabularPredictor
            The loaded object.
        """
        predictor_path = os.path.join(path, 'multilabel_predictor.pkl')

        instance = read_pickle(predictor_path)
        predictors = {}
        for label in instance._labels:
            sub_path = os.path.join(path, label)
            predictors[label] = TabularPredictor.load(sub_path)
        instance._predictors = predictors
        return instance

    def to_dict(self) -> Dict:
        """
        It returns the dictionary representation of the object.

        Returns
        -------
        dict : Dict
            The dictionary representation of the object.
        """
        # the models are the same for all the predictors, so we can just take the models of the first predictor
        first_predictor = next(iter(self._predictors.values()))
        hyperparameters = first_predictor.get_models_hyperparameters()
        models = [{'name': model.name, 'parameters': model_hyperparameters}
                  for model, model_hyperparameters in hyperparameters.items()]

        parameters = {
            'labels': list(self._labels),
            'models': models,
            'metric': str(self.metric),
            'problem_type': list(self.problem_type.values()),
            'problem_metrics': list(self.overall_metrics.values()),
            'hyperparameter_tune_kwargs': first_predictor.hyperparameter_tune_kwargs,
            'time_limit': first_predictor.time_limit,
            'keep_only_best': first_predictor.keep_only_best,
            'save_space': first_predictor.save_space
        }

        return {'name': 'MultiLabelTabularPredictor',
                'parameters': parameters}

    @classmethod
    def from_dict(cls, state: Dict) -> 'MultiLabelTabularPredictor':
        """
        It returns the object from the dictionary representation.

        Parameters
        ----------
        state : Dict
            The dictionary representation of the object.

        Returns
        -------
        MultiLabelTabularPredictor
            The object.
        """
        parameters = state['parameters']

        labels = parameters.get('labels')
        models = parameters.get('models')
        metric = parameters.get('metric')
        problem_type = parameters.get('problem_type')
        problem_metrics = parameters.get('problem_metrics')
        path = parameters.get('path')
        hyperparameter_tune_kwargs = parameters.get('hyperparameter_tune_kwargs')
        time_limit = parameters.get('time_limit')
        keep_only_best = parameters.get('keep_only_best', False)
        save_space = parameters.get('save_space', True)

        models = {get_estimator(model['name']): model['parameters'] for model in models}

        instance = cls(labels=labels,
                       models=models,
                       metric=metric,
                       problem_type=problem_type,
                       problem_metrics=problem_metrics,
                       path=path,
                       hyperparameter_tune_kwargs=hyperparameter_tune_kwargs,
                       time_limit=time_limit,
                       keep_only_best=keep_only_best,
                       save_space=save_space)
        return instance

    def to_json(self, file_path: str):
        """
        Saves an estimator object into a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        success : bool
            True if the operation was successful, False otherwise.
        """
        state = self.to_dict()
        return write_json(file_path, state)

    @classmethod
    def from_json(cls, file_path: str) -> 'MultiLabelTabularPredictor':
        """
        Loads an estimator object from a json file.

        Parameters
        ----------
        file_path : str
            Path to the json file.

        Returns
        -------
        estimator : MultiLabelTabularPredictor
            The predictor.

        """
        state = read_json(file_path)
        return cls.from_dict(state)
