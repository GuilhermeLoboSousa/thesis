from abc import ABCMeta, abstractmethod


class Predictor(metaclass=ABCMeta):
    """
    The predictor can be thought of as wrapper around a list of machine learning models.
    """

    @property
    @abstractmethod
    def can_predict_proba(self):
        ...

    @abstractmethod
    def predict_proba(self, x, **kwargs):
        ...

    @abstractmethod
    def leaderboard(self, x=None, y=None):
        ...

    @abstractmethod
    def predict(self, x, **kwargs):
        ...

    @abstractmethod
    def validate(self, x=None, y=None):
        ...

    @abstractmethod
    def score(self, x, y, model=None):
        ...

    @abstractmethod
    def fit(self, x, y, x_val=None, y_val=None):
        ...

    @property
    @abstractmethod
    def best_model(self):
        ...

    @property
    @abstractmethod
    def path(self):
        ...

    @abstractmethod
    def save(self) -> bool:
        ...

    @classmethod
    @abstractmethod
    def load(cls, path: str) -> 'Predictor':
        ...
