from typing import Type

from omnia.generics.utils.registry import RegistryMixIn
from omnia.generics.utils.singleton import singleton


@singleton
class Registry(RegistryMixIn):
    """
    A dictionary-like object that maps estimator, model and predictor names to the corresponding classes.
    It can be used to look up estimator, model and predictor classes by their name.

    More importantly, it can be used in the factory pattern to create new objects from these classes.
    """


registry: Registry = Registry


def class_register(cls: Type):
    """
    Decorator to register a class in the registry.

    Parameters
    ----------
    cls : Type
        The class to be registered.

    Returns
    -------

    """
    registry.register(cls)
    return cls
