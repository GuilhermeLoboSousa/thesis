from typing import Dict, Any, TYPE_CHECKING, Union, Type

from .registry import registry

if TYPE_CHECKING:
    from omnia.generics import Estimator
    from omnia.generics import AutoGluonBaseModel
    from omnia.generics import TabularPredictor


def setup_estimator(name: str, parameters: Dict[str, Any] = None) -> Union['Estimator', 'AutoGluonBaseModel', 'TabularPredictor']:
    """
    It builds an instance of an estimator, model or predictor with the given name and parameters.

    Parameters
    ----------
    name : str
        The name of the estimator.

    parameters : Dict[str, Any], optional
        The parameters of the estimator.
        The default is None. If None, the default parameters of the estimator are used.

    Returns
    -------
    instance : Union['Estimator', 'Model', 'TabularPredictor']
        The instance of the estimator, model or predictor.

    """
    cls = get_estimator(name)

    if not parameters:
        parameters = {}

    state = {'name': name, 'parameters': parameters}
    return cls.from_dict(state)


def get_estimator(name: str) -> Union[Type['Estimator'], Type['AutoGluonBaseModel'], Type['TabularPredictor']]:
    """
    Returns the class of the estimator, model or predictor with the given name.

    Parameters
    ----------
    name : str
        The name of the estimator, model or predictor.

    Returns
    -------
    cls : Union[Type['Estimator'], Type['Model'], Type['TabularPredictor']]
        The class of the estimator, model or predictor.
    """
    return registry.get(name)


def register_estimator(cls: Type):
    """
    Registers an estimator, model or predictor class in the registry.

    Parameters
    ----------
    cls : Type
        The class to be registered.
    """
    registry.register(cls)
