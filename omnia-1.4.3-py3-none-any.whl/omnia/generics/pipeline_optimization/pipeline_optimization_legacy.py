import functools
import logging
import os
import shutil
import sys
import time
from typing import Tuple

import nni
from nni import Experiment
from nni.experiment import ExperimentConfig, TrialResult

from omnia.generics import Pipeline
from omnia.generics.io import read_yaml, get_dataframe_reader_by_file_type
from omnia.generics.pipeline_optimization._config import PipelineOptimizationConfig
from omnia.generics.pipeline_optimization._utils import _generate_search_space, _generate_nni_config
from omnia.generics.utils import is_predictor, is_model
from omnia.generics.utils.importing import get_class


class PipelineOptimizationLegacy(Experiment):
    """
    Pipeline optimization class. It inherits from the NNI Experiment class.
    Allows managing hyperparameter optimization NNI experiments.

    When configuration is completed, use :meth:`Experiment.run` or :meth:`Experiment.start` to launch the experiment.

    Attributes
    ----------
    config
        Experiment configuration.
    id
        Experiment ID.
    port
        Web portal port. Or ``None`` if the experiment is not running.
    """

    def __init__(self, config_path: str, output_dir: str = None) -> None:
        """
        Initializes the pipeline optimization class with the experiment configuration file.

        Parameters
        ----------
        config_path : str
            Path to the experiment configuration file.
        output_dir : str
            Path to the output directory. If ``None``, the output directory will be the same as the configuration file.
        """
        self.global_config = {}
        self.config = self._setup_configs(config_path, output_dir)
        self._validate_config()
        self.maximize = self._is_maximization_hpo()
        nni_config = os.path.join(output_dir, 'nni_config.yml')
        experiment_config = ExperimentConfig.load(nni_config)
        super().__init__(experiment_config)
        self._best_trial = None

    @property
    def best_trial(self) -> TrialResult:
        """
        Returns the best trial found by the experiment.

        Returns
        -------
        best_trial : TrialResult
            TrialResult object containing the best trial found by the experiment.
        """
        return self._get_best_trial()

    def _setup_configs(self, config_path: str, output_dir: str = None) -> dict:
        """
        Set up the experiment configuration files and output directory.
        It creates the pipeline optimization configuration file, the search space configuration file and the NNI
        configuration file. It also creates the output directory.

        Parameters
        ----------
        config_path : str
            Path to the experiment configuration file.
        output_dir : str
            Path to the output directory. If ``None``, the output directory will be the same as the configuration file.
        """
        # read config file
        config = read_yaml(config_path)

        # set the global config (yaml config file content)
        self.global_config = config

        # create the required files and configurations for nni
        config['nniConfig'].update({'configFile': config_path})
        if output_dir is None:
            output_dir = os.path.dirname(config_path)
            output_dir = os.path.join(output_dir, config['nniConfig']['experimentName'])
        os.makedirs(output_dir, exist_ok=True)
        shutil.copy(config_path, dst=output_dir)
        self.output_dir = output_dir
        self._generate_configs(config, output_dir)
        return config

    def _is_maximization_hpo(self) -> bool:
        """
        Returns whether the hyperparameter optimization is a maximization or minimization problem.

        Returns
        -------
        maximize : bool
            Boolean indicating whether the hyperparameter optimization is a maximization (True) or minimization problem
            (False).
        """
        if self.config['pipeline']['optimize_mode'] == 'maximize':
            return True
        elif self.config['pipeline']['optimize_mode'] == 'minimize':
            return False
        else:
            raise ValueError(
                f"optimize_mode must be 'maximize' or 'minimize'. Got {self.config['pipeline']['optimize_mode']}.")

    @staticmethod
    def _generate_configs(experiment_spec: dict, out_dir: str) -> Tuple[dict, dict]:
        """
        Generate the search space and NNI config files.

        Parameters
        ----------
        experiment_spec : dict
            Dictionary containing the experiment specification.
        out_dir : str
            Path to the output directory.

        Returns
        -------
        search_space : dict
            Dictionary containing the search space in the format required by NNI.
        nni_config : dict
            Dictionary containing the NNI config in the format required by NNI.
        """
        logging.debug(f"Writing search_space.json to {out_dir} ...")
        search_space = _generate_search_space(experiment_spec['searchSpace'], out_dir)

        logging.debug(f"Writing config.yml to {out_dir} ...")
        nni_config = _generate_nni_config(experiment_spec['nniConfig'], out_dir)

        return search_space, nni_config

    def _validate_config(self) -> None:
        """
        Validates the configuration file to assure mandatory fields are provided and types are correct.
        """
        PipelineOptimizationConfig(**self.config)

    def _get_best_trial(self) -> TrialResult:
        """
        Returns the best trial found by the experiment.

        Returns
        -------
        best_trial : TrialResult
            TrialResult object containing the best trial found by the experiment.
        """
        data = self.export_data()
        if not data:
            # return an empty trial if no data is available
            return TrialResult(trialJobId='error-id', parameter={}, value='0')

        if self.maximize:
            return max(data, key=lambda x: x.value)

        return min(data, key=lambda x: x.value)

    def get_problem_type(self) -> str or None:
        """
        Get the problem type.

        Returns
        -------
        problem_type : str or None
            String containing the problem type.
        """
        if 'pipeline' not in self.global_config:
            return

        return self.global_config['pipeline'].get('problem_type', None)

    def get_metric(self) -> str or None:
        """
        Get the metric.

        Returns
        -------
        metric : str or None
            String containing the metric.
        """
        if 'pipeline' not in self.global_config:
            return

        return self.global_config['pipeline'].get('metric', None)

    def get_best_parameters(self) -> dict:
        """
        Get the best parameters found by the experiment.

        Returns
        -------
        best_parameters : dict
            Dictionary containing the best parameters found by the experiment.
        """
        return self.best_trial.parameter

    def get_best_trial_id(self) -> str:
        """
        Get the best trial ID found by the experiment.

        Returns
        -------
        best_trial_id : str
            String containing the best trial ID found by the experiment.
        """
        return self.best_trial.trialJobId

    def get_all_trials(self):
        """
        Get all trials found by the experiment.

        Returns
        -------
        all_trials : list
            List containing all trials found by the experiment.
        """
        return self.export_data()


@functools.lru_cache(maxsize=None)
def cached_data_loading(config_path: str):
    experiment_spec = read_yaml(config_path)

    path = experiment_spec['data']['path']
    extension = path.split('.')[-1]
    data = get_dataframe_reader_by_file_type(extension)(filepath_or_buffer=path, **experiment_spec['data']['params'])

    target = experiment_spec['splitter']['target']
    stratify = experiment_spec['splitter']['params'].pop('stratify', False)
    splitter_name = experiment_spec['splitter']['name']
    splitter = get_class(splitter_name)

    if stratify and 'sklearn.model_selection.train_test_split' == splitter_name:
        x_train, x_val, y_train, y_val = splitter(data.drop(target, axis=1), data[target],
                                                  stratify=data[target], **experiment_spec['splitter']['params'])

    else:
        x_train, x_val, y_train, y_val = splitter(data.drop(target, axis=1), data[target],
                                                  **experiment_spec['splitter']['params'])

    return x_train, x_val, y_train, y_val


def run_experiment():
    """
    Run the experiment.
    Main interface to use the hyperparameter optimization from NNI on Omnia Pipelines.
    """
    # Get the config path
    config_path = sys.argv[1]
    working_dir = os.getcwd()
    logging.info(f"Working directory is {working_dir} ..")

    # read the config file
    experiment_spec = read_yaml(config_path)

    # if not pipeline attribute in the config file, raise an error
    if 'pipeline' not in experiment_spec:
        raise ValueError(f"Missing pipeline attribute in the config file {config_path} ..")

    # get the data
    x_train, x_val, y_train, y_val = cached_data_loading(config_path)

    # get the next nni parameters
    nni_hparams = nni.get_next_parameter()
    logging.info(f"Received from NNI -> {nni_hparams}")

    # create the pipeline
    problem_type = experiment_spec['pipeline'].get('problem_type')
    metric = experiment_spec['pipeline'].get('metric')
    metric_kwargs = experiment_spec['pipeline'].get('metric_kwargs', {})
    # todo: ADD A GROUP BASED PROBLEM TYPE
    pipeline = Pipeline.from_nni_hparams(hparams=nni_hparams, problem_type=problem_type, metric=metric)

    # check if the last step is a predictor
    if not is_predictor(pipeline.steps[-1][1]) and not is_model(pipeline.steps[-1][1]):
        raise ValueError(f"Last step of the pipeline must be a predictor or a model, got {pipeline.steps[-1][1]}")

    if is_predictor(pipeline.steps[-1][1]):
        metric = pipeline.steps[-1][1].metric
    else:
        metric = metric
    logging.info(f"Metric to be used is {metric} ..")

    # fit
    logging.info(f"Fitting the Pipeline ..")
    start_time = time.time()
    pipeline.fit(x_train, y_train)
    time_taken = time.time() - start_time
    logging.info(f'Fitting took {time_taken:.5f} sec to train')

    # score
    logging.info(f"Scoring Pipeline ..")
    start_time = time.time()
    score = pipeline.score(x_val, y_val, metrics=metric, **metric_kwargs)[metric]
    logging.info(f"Final score from the pipeline is {score}")
    time_taken = time.time() - start_time
    logging.info(f'Scoring took {time_taken:.5f} sec to train')
    logging.info(f'Score is {score}')

    logging.info("Done!")

    # clean the pipeline folders
    logging.info(f"Cleaning up the pipeline folders ..")
    shutil.rmtree(pipeline.path, ignore_errors=True)

    # report the score
    nni.report_final_result(score)


if __name__ == '__main__':
    run_experiment()
