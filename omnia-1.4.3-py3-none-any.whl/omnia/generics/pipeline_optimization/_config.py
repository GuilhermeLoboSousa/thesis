from typing import Union, List, Optional

from pydantic import BaseModel


class DataConfig(BaseModel):
    path: str
    params: Optional[dict] = {}


class SplitterConfig(BaseModel):
    name: str
    target: Union[str, List[str]]
    params: Optional[dict] = {}


class PipelineConfig(BaseModel):
    name: str
    problem_type: str
    metric: str
    metric_kwargs: Optional[dict] = {}
    optimize_mode: str


class SearchSpaceConfig(BaseModel):
    preset: str


class TunerConfig(BaseModel):
    name: str
    classArgs: Optional[dict] = {}


class AssessorConfig(BaseModel):
    name: str
    classArgs: Optional[dict] = {}


class TrainingServiceConfig(BaseModel):
    platform: str


class NNIConfig(BaseModel):
    experimentName: Optional[str] = None
    trialConcurrency: Optional[int] = 1
    trialGpuNumber: Optional[int] = None
    maxExperimentDuration: Optional[str] = None
    maxTrialNumber: Optional[int] = None
    maxTrialDuration: Optional[str] = None
    nniManagerIp: Optional[str] = None
    useAnnotation: Optional[bool] = False
    debug: Optional[bool] = False
    logLevel: Optional[str] = None
    experimentWorkingDirectory: Optional[str] = '~/nni-experiments'
    tunerGpuIndices: Optional[List[int]] = None
    tuner: Optional[TunerConfig] = None
    assessor: Optional[AssessorConfig] = None
    trainingService: TrainingServiceConfig
    sharedStorage: Optional[dict] = None


class PipelineOptimizationConfig(BaseModel):
    data: DataConfig
    splitter: SplitterConfig
    pipeline: PipelineConfig
    searchSpace: Union[List, SearchSpaceConfig]
    nniConfig: NNIConfig
