import os
import warnings
from typing import Union, List, Any, Literal

import optuna
from optuna.storages import BaseStorage
from optuna.samplers import BaseSampler
from optuna.pruners import BasePruner
from optuna.study import StudyDirection

from omnia.generics import np, Pipeline, pd
from omnia.generics.metrics import Metric
from omnia.generics.pipeline_optimization.objectives import Objective, TrainEvalObjective
from omnia.generics.pipeline_optimization._utils import _get_preset, _get_task_type
from omnia.generics.pipeline.voting import VotingPipeline


class PipelineOptimization:
    """
    Pipeline optimization using Optuna.
    """

    def __init__(self, storage: Union[str, BaseStorage] = None, sampler: BaseSampler = None, pruner: BasePruner = None,
                 study_name: str = None, direction: Union[str, StudyDirection] = None, load_if_exists: bool = False,
                 directions: List[Union[str, StudyDirection]] = None, n_jobs: int = 1) -> None:
        """
        Initializes the pipeline optimization.

        Parameters
        ----------
        storage: str or optuna.storages.BaseStorage
            Database URL such as sqlite:///example.db or a BaseStorage object.
        sampler: optuna.samplers.BaseSampler
            Sampler object.
        pruner: optuna.pruners.BasePruner
            Pruner object.
        study_name: str
            Study name.
        direction: str or optuna.study.StudyDirection
            Direction of optimization.
        load_if_exists: bool
            Whether to load the study if it already exists.
        directions: list of str or optuna.study.StudyDirection
            Directions of optimization.
        n_jobs: int
            Number of parallel jobs.
        """
        self._voting_pipeline = None
        self.direction = direction if direction is not None else directions
        self.study = optuna.create_study(storage=storage, sampler=sampler, pruner=pruner, study_name=study_name,
                                         direction=direction, load_if_exists=load_if_exists, directions=directions)
        self.study.set_user_attr('best_scores', {})
        self.study.set_user_attr('successful_trials', 0)
        self.n_jobs = n_jobs
        self.task_type = None
        self.n_voting_pipelines = None
        self._voting_score = None
        self.voting_pipelines_trials = None

    def optimize(self, search_space: Union[callable, str], x: Any, y: Any, x_val: Any, y_val: Any,
                 metric: Union[str, Metric], task_type: str, n_trials: int, save_top_n: int = 1,
                 n_voting_pipelines: int = None, voting: Literal["hard", "soft"] = "hard",
                 objective: Objective = TrainEvalObjective, trial_timeout: int = 86400,
                 **kwargs) -> 'PipelineOptimization':
        """
        Optimizes the pipeline.

        Parameters
        ----------
        search_space: callable or str
            Search space.
        x: Any
            Features.
        y: Any
            Labels.
        x_val: Any
            Validation features.
        y_val: Any
            Validation labels.
        metric: str or omnia.generics.metrics.Metric
            Metric to optimize.
        task_type: str
            Task type.
        n_trials: int
            Number of trials.
        save_top_n: int
            Number of top pipelines to save.
        n_voting_pipelines: int
            Number of pipelines to ensemble.
        voting: Literal["hard", "soft"]
            Voting type.
        objective: omnia.generics.pipeline_optimization.objectives.Objective
            Objective function.
        trial_timeout: int
            Timeout for each trial.
        kwargs: dict
            Additional parameters to pass to the pipeline.
        """
        if isinstance(search_space, str):
            search_space = _get_preset(search_space)
        # TODO: this is a temporary solution until the OmniaDataset is implemented
        n_tasks = 1 if task_type in ['binary', 'multiclass', 'multilabel', 'regression'] else y.shape[1]
        if task_type in ['binary', 'multiclass', 'multilabel']:
            n_classes = len(np.unique(y))
        elif task_type in ['multitask_binary', 'multitask_multiclass', 'multitask_multilabel']:
            n_classes = len(np.unique(y.iloc[:, 0])) #assuming pandas df
        else:
            n_classes = None
        objective = objective(search_space, x, y, x_val, y_val, metric, task_type, n_tasks, n_classes,
                              self.study, self.direction, save_top_n, trial_timeout)
        self.study.optimize(objective, n_trials=n_trials, catch=(TimeoutError,), n_jobs=self.n_jobs, **kwargs)
        if self.best_value in [np.float_('-inf'), np.float_('inf')]:
            raise ValueError('The best value is -inf or inf. No trials completed successfully.')
        if n_voting_pipelines:
            self.n_voting_pipelines = n_voting_pipelines
            if save_top_n < self.n_voting_pipelines:
                warnings.warn(f'The number of pipelines to ensemble is greater than the number of pipelines saved. '
                              f'Ensemble will be performed with the top {save_top_n} pipelines.')
                self.n_voting_pipelines = save_top_n
            if self.study.user_attrs['successful_trials'] < self.n_voting_pipelines:
                warnings.warn(f'The number of pipelines to ensemble is greater than the number of successful trials. '
                              f'Ensemble will be performed with the top {self.study.user_attrs["successful_trials"]} pipelines.')
                self.n_voting_pipelines = self.study.user_attrs['successful_trials']
            self.task_type = _get_task_type(task_type)
            self.run_voting_pipeline(x_val, y_val, metric, voting=voting)
        return self

    def run_voting_pipeline(self, x_val: Any, y_val: Any, metric: str,
                            voting: Literal["hard", "soft"] = "hard") -> 'PipelineOptimization':
        """
        Returns the best pipelines ensemble.

        Parameters
        ----------
        x_val: Any
            Validation data.
        y_val: Any
            Validation target.
        metric: str
            Metric to be used for scoring.
        voting: Literal["hard", "soft"]
            Voting type.
        """
        trials_df = self.trials_dataframe()
        ascending = True if self.direction == 'minimize' else False
        best_trials = (trials_df[trials_df['state'] == 'COMPLETE'].
                       sort_values('value', ascending=ascending))
        pipelines = []
        self.voting_pipelines_trials = []
        i = 0
        while len(pipelines) < self.n_voting_pipelines:
            path_exists = False
            while not path_exists:
                number = best_trials.iloc[i]['number']
                path = os.path.join(self.study.study_name, f'trial_{number}')
                if os.path.exists(path):
                    pipelines.append(Pipeline.load(path))
                    path_exists = True
                    self.voting_pipelines_trials.append(number)
                i += 1

        voting_pipeline = VotingPipeline(pipelines=pipelines, task_type=self.task_type, voting=voting,
                                         path=os.path.join(self.study.study_name, 'voting_pipeline'))
        voting_pipeline.save()
        self._voting_pipeline = voting_pipeline
        self._voting_score = voting_pipeline.score(x_val, y_val, metrics=metric, per_task_metrics=False)[metric]
        return self

    @property
    def pipelines_ensemble(self) -> 'VotingPipeline':
        """
        Returns the pipelines ensemble.

        Returns
        -------
        omnia.generics.pipeline_optimization.ensemble.VotingPipeline
            Pipelines ensemble.
        """
        if self._voting_pipeline is None:
            raise AttributeError('pipelines_ensemble attribute is not available. '
                                 'Set a number to pipeline.n_voting_pipelines and run pipeline.run_voting_pipeline().')
        return self._voting_pipeline

    @property
    def best_params(self) -> dict:
        """
        Returns the best hyperparameters.

        Returns
        -------
        dict
            Best hyperparameters.
        """
        if self._voting_score is not None and self._voting_score > self.study.best_value:
            best_trials_numbers = self.voting_pipelines_trials
            params = {n: self.trials[n].params for n in best_trials_numbers}
            return {'pipelines': params, 'voting': self._voting_pipeline.voting,
                    'weights': self._voting_pipeline.weights}
        return self.study.best_params

    @property
    def best_trial(self) -> dict:
        """
        Returns the best trial.

        Returns
        -------
        dict
            Best trial.
        """
        best_trial = self.study.best_trial
        if self._voting_score is not None and self._voting_score > best_trial.value:
            return {'number': 'voting_pipeline', 'value': self._voting_score}
        return self.study.best_trial

    @property
    def best_value(self) -> float:
        """
        Returns the best value (score of the best trial).

        Returns
        -------
        float
            Best value.
        """
        if self._voting_score is not None and self._voting_score > self.study.best_value:
            return self._voting_score
        return self.study.best_value

    @property
    def trials(self) -> List[optuna.trial.Trial]:
        """
        Returns all trials.

        Returns
        -------
        list of optuna.trial.Trial
            Trials.
        """
        if self._voting_pipeline is not None:
            warnings.warn('Voting pipeline is not included in the trials.')
        return self.study.trials

    @property
    def best_pipeline(self) -> 'Pipeline':
        """
        Returns the best pipeline.

        Returns
        -------
        omnia.generics.Pipeline
            Best pipeline.
        """
        if self._voting_pipeline is not None and self._voting_score > self.study.best_trial.value:
            return self._voting_pipeline
        best_trial_id = self.study.best_trial.number
        path = os.path.join(self.study.study_name, f'trial_{best_trial_id}')
        return Pipeline.load(path)

    def trials_dataframe(self, cols: List[str] = None) -> pd.DataFrame:
        """
        Returns the trials dataframe.

        Parameters
        ----------
        cols : list of str
            Columns to be returned.

        Returns
        -------
        pd.DataFrame
            Trials dataframe.
        """
        if cols is not None:
            return self.study.trials_dataframe(attrs=tuple(cols))
        return self.study.trials_dataframe()

    def get_param_importances(self) -> Union[None, dict]:
        """
        Returns the parameter importances.

        Returns
        -------
        dict
            Parameter importances.
        """
        try:
            return optuna.importance.get_param_importances(self.study)
        except RuntimeError:
            return None
