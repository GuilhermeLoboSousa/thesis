import os
import shutil
import warnings
from abc import abstractmethod
from copy import copy
from typing import Union, Any

from optuna import Trial
from optuna.study import StudyDirection
from timeout_decorator import timeout_decorator

from omnia.generics import Pipeline
from omnia.generics.metrics import Metric
from omnia.generics.pipeline_optimization._utils import _get_input_type, _get_task_type


class Objective:
    """
    Wrapper for the objective function of the pipeline optimization.
    It creates, saves and evaluates pipelines for each trial.

    Parameters
    ----------
    objective_steps: callable or str
        Steps to be used in the pipeline.
    task_type: str
        Task type.
    study: optuna.study.Study
        Study object.
    direction: str or optuna.study.StudyDirection
        Direction of optimization.
    save_top_n: int
        Number of top pipelines to save.
    trial_timeout: int
        Timeout for each trial.
    """

    def __init__(self, objective_steps: Union[callable, str], task_type: str, n_tasks: int, n_classes: int,
                 study: 'Study', direction: Union[str, StudyDirection], save_top_n: int, trial_timeout: int):
        self.objective_steps = objective_steps
        self.task_type = _get_task_type(task_type)
        self.n_tasks = n_tasks
        self.n_classes = n_classes
        self.study = study
        self.direction = direction
        self.save_top_n = save_top_n
        self.trial_timeout = trial_timeout
        self.save_dir = study.study_name

    @abstractmethod
    def __call__(self, trial: Trial) -> float:
        """"""


class TrainEvalObjective(Objective):
    """
    Objective that trains and evaluates a pipeline for a given trial using a training and validation set.
    """

    def __init__(self, objective_steps: Union[callable, str], x: Any, y: Any, x_val: Any, y_val: Any,
                 metric: Union[str, Metric], task_type: str, n_tasks: int, n_classes: int, study: 'Study',
                 direction: Union[str, StudyDirection], save_top_n: int, trial_timeout: int, **kwargs) -> None:
        """
        Initializes the objective.

        Parameters
        ----------
        objective_steps: callable or str
            Steps to be used in the pipeline.
        x: Any
            Features.
        y: Any
            Labels.
        x_val: Any
            Validation features.
        y_val: Any
            Validation labels.
        metric: str or omnia.generics.metrics.Metric
            Metric to optimize.
        task_type: str
            Task type.
        n_tasks: int
            Number of tasks.
        n_classes: int
            Number of classes.
        study: optuna.study.Study
            Study object.
        direction: str or optuna.study.StudyDirection
            Direction of optimization.
        save_top_n: int
            Number of top pipelines to save.
        trial_timeout: int
            Timeout for each trial.
        kwargs: dict
            Additional keyword arguments to pass to the pipeline.
        """
        super(TrainEvalObjective, self).__init__(objective_steps, task_type, n_tasks, n_classes, study, direction,
                                                 save_top_n, trial_timeout)
        self.x = x
        self.y = y
        self.x_val = x_val
        self.y_val = y_val
        self.metric = metric
        self.kwargs = kwargs

    def __call__(self, trial: Trial):
        """
        Create and evaluate a pipeline for a given trial.

        Parameters
        ----------
        trial : optuna.trial.Trial
            Trial object that stores the hyperparameters.
        """
        try:
            @timeout_decorator.timeout(self.trial_timeout, exception_message='Trial timeout reached!')
            def run_with_timeout():
                x = copy(self.x)
                y = copy(self.y)
                x_val = copy(self.x_val)
                y_val = copy(self.y_val)
                trial_id = str(trial.number)
                path = os.path.join(self.save_dir, f'trial_{trial_id}')
                input_type = _get_input_type(self.x)
                pipeline = Pipeline(steps=self.objective_steps.get_steps(trial, task_type=self.task_type,
                                                                         n_tasks=self.n_tasks,
                                                                         n_classes=self.n_classes,
                                                                         input_type=input_type,
                                                                         **self.kwargs), path=path)
                pipeline.fit(x, y, x_val=x_val, y_val=y_val)
                score = pipeline.score(x_val, y_val, metrics=self.metric)[self.metric]
                if score is None:
                    score = float('-inf') if self.direction == 'maximize' else float('inf')
                else:
                    self.study.set_user_attr('successful_trials', self.study.user_attrs.get('successful_trials', 0) + 1)

                best_scores = self.study.user_attrs['best_scores']
                min_score = min(best_scores.values()) if len(best_scores) > 0 else float('inf')
                max_score = max(best_scores.values()) if len(best_scores) > 0 else float('-inf')
                update_score = (self.direction == 'maximize' and score > min_score) or (
                        self.direction == 'minimize' and score < max_score)

                if len(best_scores) < self.save_top_n or update_score:
                    pipeline.save()
                    best_scores.update({trial_id: score})

                    if len(best_scores) > self.save_top_n:
                        if self.direction == 'maximize':
                            min_score_id = min(best_scores, key=best_scores.get)
                            del best_scores[min_score_id]
                            if os.path.exists(os.path.join(self.save_dir, f'trial_{min_score_id}')):
                                shutil.rmtree(os.path.join(self.save_dir, f'trial_{min_score_id}'))
                        else:
                            max_score_id = max(best_scores, key=best_scores.get)
                            del best_scores[max_score_id]
                            if os.path.exists(os.path.join(self.save_dir, f'trial_{max_score_id}')):
                                shutil.rmtree(os.path.join(self.save_dir, f'trial_{max_score_id}'))

                self.study.set_user_attr('best_scores', best_scores)
                return score

            return run_with_timeout()
        # TODO: check which exceptions should be caught
        except Exception as e:
            warnings.warn(f"Trial failed with error: {e}")
            trial.set_user_attr("error", f'Trial failed with error: {e}')
            return float('inf') if self.direction == 'minimize' else float('-inf')
