import json
import os
from concurrent import futures
from typing import Union, Any

import yaml

from omnia.generics import search_space_registry, pd, np
from omnia.generics.hpo import setup_search_space
from omnia.generics.hpo.registry import _import_and_setup_search_space
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag


def _generate_nni_config(nni_config: dict, out_dir: str) -> dict:
    """
    Generate a NNI config file.
    The 'searchSpaceFile', 'trialCommand' and 'trialCodeDirectory' fields required by NNI are added to the config file.
    The config file is saved in the working directory as nni_config.yml.

    Parameters
    ----------
    nni_config : dict
        dictionary containing the NNI config
    out_dir : str
        path to the output directory

    Returns
    -------
    nni_config : dict
        dictionary containing the NNI config in the format required by NNI.
    """
    # make a copy of the dictionary to avoid modifying the original one
    nni_config = nni_config.copy()

    # all we got to do is to update this dictionary with missing items
    nni_config.update({
        'searchSpaceFile': 'search_space.json',
        'trialCommand': f'python -m omnia.generics.pipeline_optimization.pipeline_optimization_legacy {nni_config["configFile"]}',
        'trialCodeDirectory': '.'
    })

    # remove the 'configFile' key
    del nni_config['configFile']

    path_to_config_file = os.path.join(out_dir, 'nni_config.yml')
    with open(path_to_config_file, 'w+') as outfile:
        yaml.dump(nni_config, outfile)

    return nni_config


def _generate_search_space(search_space: Union[dict, str], out_dir: str) -> dict:
    """
    Generate a search space file for NNI.
    The search space is saved in the working directory as search_space.json.

    Parameters
    ----------
    search_space : Union[dict, str]
        search_space preset name or dictionary containing the search space
    out_dir : str
        path to the output directory

    Returns
    -------
    complete_dict : dict
        dictionary containing the search space in the format required by NNI.
    """
    if 'preset' in search_space:
        # if a preset is specified, populate from the preset
        complete_dict = setup_search_space(search_space['preset'])

    else:
        # otherwise populate from the dictionary of search space
        complete_dict = {}
        for param in search_space:
            param_key = str(list(param.keys())[0])
            param_values = list(param.values())[0]

            complete_dict[param_key] = param_values

    path_to_search_space_file = os.path.join(out_dir, 'search_space.json')
    with open(path_to_search_space_file, 'w+') as outfile:
        json.dump(complete_dict, outfile)

    return complete_dict


def _get_preset(preset: str) -> dict:
    """
    Returns the class of the search space with the preset name.

    Parameters
    ----------
    preset : str
        The name of the preset.

    Returns
    -------
    search_space : dict
        The search_space configuration.
    """
    search_space_cls = search_space_registry.get(preset)

    if search_space_cls is None:

        # the sub-packages might not be imported yet
        # so we import them here using the importlib module
        # and then we try to get the preset again

        # omnia.compounds
        # omnia.deep_learning
        # omnia.generative
        # omnia.genes
        # omnia.metabolomics
        # omnia.proteins
        # omnia.transcriptomics

        search_space_cls = _import_and_setup_search_space(preset,
                                                          ['omnia.compounds',
                                                           'omnia.deep_learning',
                                                           'omnia.generative',
                                                           'omnia.genes',
                                                           'omnia.metabolomics',
                                                           'omnia.proteins',
                                                           'omnia.transcriptomics'])

        if search_space_cls is None:
            raise ValueError(f'Search Space preset {preset} not found.')

    return search_space_cls()


def _get_input_type(x: Any) -> DataTag:
    """
    Returns the input type of the data.

    Parameters
    ----------
    x : Any
        The input data.
        Can be tabular, 2D or text data.

    Returns
    -------
    DataTag
        The input type of the data.
    """
    if isinstance(x, pd.DataFrame):
        x = x.values

    if (isinstance(x, list) and all(isinstance(item, str) for item in x)) or (isinstance(x, np.ndarray) and np.issubdtype(x.dtype, np.str_)):
        return DataTag.TEXT

    if isinstance(x, pd.Series) or (isinstance(x, np.ndarray) and x.ndim == 2) or (isinstance(x, list) and all(isinstance(item, (int, float)) for item in x)):
        return DataTag.TABULAR

    if isinstance(x, np.ndarray) and x.ndim >= 3 or (isinstance(x, list) and all(isinstance(item, list) for item in x)):
        return DataTag.MATRIX

    raise ValueError('Data type not supported.')


def _get_task_type(task_type: str) -> TaskTag:
    """
    Returns the task type.

    Parameters
    ----------
    task_type : str
        The task type.

    Returns
    -------
    DataTag
        The task type.
    """
    return TaskTag.from_string(task_type)


def timeout(timelimit: int) -> callable:
    """
    Decorator to set a timeout for a function.

    Parameters
    ----------
    timelimit: int
        Time limit in seconds.

    Returns
    -------
    function
        Decorated function.
    """
    def decorator(func):
        def decorated(*args, **kwargs):
            with futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(func, *args, **kwargs)
                try:
                    result = future.result(timelimit)
                except futures.TimeoutError:
                    raise TimeoutError(
                        f"Function {func.__name__} timed out after {timelimit} seconds.")
                executor._threads.clear()
                futures.thread._threads_queues.clear()
                return result
        return decorated
    return decorator
