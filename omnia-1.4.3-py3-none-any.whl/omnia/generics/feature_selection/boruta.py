from typing import Tuple, List

from omnia.generics.transformation import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.validation import NumericalX, NotAllowNaN, RequiresY, IsPandasX
from omnia.generics.parameter import Parameter, EstimatedParameter
from omnia.generics.validation.validation_properties.validation_property import ValidationProperty
from omnia.generics.parameter.space import Int, Categorical

from ._boruta_py import run_boruta


class BorutaTransformer(Transformer,
                        name='Boruta',
                        category='feature_selection',
                        register=True):
    """
    Transformer class to apply the Boruta Feature Selection method to the normalized dataframe.
    The BorutaTransformer operates only over pandas DataFrame.

    The dataframe must not have any NaN values. X must be a dataframe containing only numerical values.
    A metadata dataframe containing the labels for each sample is mandatory to use this transformer.

    | **Samples** |   GeneA   |   GeneB   |    Labels     |
    |------------|------------|-----------|---------------|
    | SampleA   | 0.1        | 0.2        | WT            |
    | SampleB   | 0.3        | 0.4        | KO            |

    Parameters
    ----------
    random_forest_n_estimators : int, default=100
        Random Forest Classifier parameter.
        The number of trees in the forest.

    random_forest_max_depth : int, default=None
        Random Forest Classifier parameter.
        The maximum depth of the tree. If None nodes will be expanded until either the leaves are pure
        or the samples in the leafs are less than random_forest_min_samples_split.

    random_forest_min_samples_split : int or float, default=2
        Random Forest Classifier parameter.
        Minimum number of samples required to split an internal node.

    random_forest_min_samples_leaf : int or float, default=1
        Random Forest Classifier parameter.
        Number of samples required to be a leaf node.

    random_forest_max_features : {"sqrt", "log2", None}, int or float, default="sqrt"
        Random Forest Classifier parameter.
        Maximum number of features to consider when looking for the best split.

    random_forest_oob_score : bool, default=False
        Random Forest Classifier parameter.
        Whether to use out-of-bag samples to estimate the generalization score.

    random_forest_n_jobs : int, default=1
        Random Forest Classifier parameter.
        The number of jobs to run in parallel.

    random_forest_random_state : int or None, default=0
        Random Forest Classifier parameter.
        Controls both the randomness of the bootstrapping of the samples used when building trees and the
        sampling of the features to consider when looking for the best split at each node.

    boruta_n_estimators : int or string; default = 1000
        Parameter for the Boruta method.
        - If int sets the number of estimators in the chosen ensemble method.
        - If 'auto' this is determined automatically based on the size of the dataset.

    boruta_perc : int; default = 100
        Parameter for the Boruta method.
        Instead of the max BorutaPy uses the percentile defined by the user, to pick the threshold for
        comparison between shadow and real features. The lower the boruta_perc is the more false positives
        will be picked as relevant but also the less relevant features will be left out.

    boruta_alpha : float; default = 0.05
        Parameter for the Boruta method.
        Level to reject the corrected p-values in the correction steps.

    boruta_two_step : Boolean; default = True
        Parameter for the Boruta method.
        - If false the Boruta method will use the Bonferroni correction, which was implemented in the original
          implementation of Boruta.

    boruta_max_iter : int; default = 100
        Parameter for the Boruta method.
        The number of maximum iterations to perform.

    boruta_random_state : int or None; default=0
        Parameter for the Boruta method.
        - If int, random_state is the seed used by the random number generator;
        - If e RandomState instance, random_statis the random number generator;
        - If None, the random number generator is the RandomState instance used by `np.random`.

    boruta_verbose : int; default=0
        Parameter for the Boruta method.

    Attributes
    ----------
    features_mask : list of boolean
        Mask of the features that are relevant.

    Examples
    --------
    >>> from omnia.generics.feature_selection.boruta import BorutaTransformer

    >>> data = pd.DataFrame({'feat1': [1,0,1,0,0], 'feat2': [0,1,0,1,1], 'feat3': [1,0,1,0,0], 'feat4': [0,1,0,1,1]},
    ...                     index=['a', 'b', 'c', 'd', 'e'])
    >>> labels = pd.DataFrame({'Labels': [1,0,1,0,0]})

    >>> boruta_transformer = BorutaTransformer()
    >>> boruta_transformer.fit(data, labels)

    >>> transformed_x, transformed_y = boruta_transformer.transform(data, labels)
    """
    validation_property = ValidationProperty(input_tag=IsPandasX & (NumericalX & NotAllowNaN & RequiresY),
                                             output_tag=IsPandasX & (NumericalX & NotAllowNaN & RequiresY))

    random_forest_n_estimators: int = Parameter(default=100, tunable=True, space=Int(lower=100, upper=300, default=100))
    random_forest_max_depth: int = Parameter(default=None)
    random_forest_min_samples_split: int or float = Parameter(default=2)
    random_forest_min_samples_leaf: int or float = Parameter(default=1)
    random_forest_max_features: str or int or float = Parameter(default="sqrt")
    random_forest_oob_score: bool = Parameter(default=False)
    random_forest_n_jobs: int = Parameter(default=1)
    random_forest_random_state: int or None = Parameter(default=0)
    boruta_n_estimators: int or str = Parameter(default=1000, tunable=True,
                                                space=Int(lower=1000, upper=1500, default=1000))
    boruta_perc: int = Parameter(default=100, tunable=True, space=Int(lower=1, upper=100, default=100))
    boruta_alpha: float = Parameter(default=0.05, tunable=True, space=Categorical(0.05, 0.01, 0.005, 0.001))
    boruta_two_step: bool = Parameter(default=True, tunable=True, space=Categorical(True, False))
    boruta_max_iter: int = Parameter(default=100, tunable=True, space=Int(lower=100, upper=200, default=100))
    boruta_random_state: int or None = Parameter(default=0)
    boruta_verbose: int = Parameter(default=0)

    features_mask: List[bool] = EstimatedParameter()

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> "BorutaTransformer":
        """
        This method is used to fit the Boruta transformer.

        Parameters
        ----------
        x : pd.DataFrame
            The Normalized Transcriptomics Data.

        y : pd.DataFrame, default=None
            The Labels for each sample of the dataset.

        Returns
        -------
        BorutaTransformer
            The Boruta transformer.
        """
        if y is None:
            raise ValueError('Sample Labels must be provided for the Boruta Transformer.')

        original_x = x.copy()

        # TODO: Save shadow values for each feature
        x = run_boruta(dataset=original_x, labels=y,
                       random_forest_n_estimators=self.random_forest_n_estimators,
                       random_forest_max_depth=self.random_forest_max_depth,
                       random_forest_min_samples_split=self.random_forest_min_samples_split,
                       random_forest_min_samples_leaf=self.random_forest_min_samples_leaf,
                       random_forest_max_features=self.random_forest_max_features,
                       random_forest_oob_score=self.random_forest_oob_score,
                       random_forest_n_jobs=self.random_forest_n_jobs,
                       random_forest_random_state=self.random_forest_random_state,
                       boruta_n_estimators=self.boruta_n_estimators,
                       boruta_perc=self.boruta_perc,
                       boruta_alpha=self.boruta_alpha,
                       boruta_two_step=self.boruta_two_step,
                       boruta_max_iter=self.boruta_max_iter,
                       boruta_random_state=self.boruta_random_state,
                       boruta_verbose=self.boruta_verbose)

        self.instances = list(x.index)

        self.features = list(x.columns)

        self.features_mask = list(original_x.columns.isin(self.features))

        return self

    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        This method is used to transform the Transcriptomics data.

        Parameters
        ----------
        x : pd.DataFrame
            The Normalized Transcriptomics Data.

        y : pd.DataFrame, Optional, default=None
            The Labels for each sample of the dataset.

        Returns
        -------
        transformed_x : pd.DataFrame
            The transformed Transcriptomics Data.

        transformed_y : pd.DataFrame
            The transformed Labels for each sample of the dataset.
        """
        return x.loc[:, self.features_mask].copy(), y
