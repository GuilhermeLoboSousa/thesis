from abc import abstractmethod
from typing import Union, List, Tuple
from hyperopt import hp
from optuna import Trial
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.preprocessing import StandardScaler

import omnia.generics.model as models
from omnia.generics import BorutaTransformer, ScikitLearnBaseModel, TorchModel
from omnia.generics.model import Model, KerasModel
from omnia.generics.model.callbacks import EarlyStopping
from omnia.generics.prediction import TabularPredictor
from omnia.generics.hpo.step import Step
from omnia.generics.hpo.registry import search_space_register
from omnia.generics.hpo.base import BaseSearchSpace
from omnia.generics.prediction.predictor import Predictor
from omnia.generics.utils.drop_duplicates import drop_duplicates
from omnia.generics.utils.function_transformer import PassthroughTransformer, FunctionTransformer
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag

_AG_MODELS = [
    models.RandomForestModel,
    models.MultilayerPerceptronNN,
    models.CatBoostModel,
    models.KNNModel,
    models.LGBModel,
    models.LinearModel,
    models.FastAINN,
    models.VowpalWabbitModel,
    models.XGBoostModel,
    models.XTModel,
    # models.SupportVectorMachineModel, # Takes too long, doesn't produce good results
]

_OMNIA_MODELS = [
    models.GradientBoostingClassifier,
    models.RandomForestClassifier,
    models.LogisticRegression,
    models.MLPClassifier,
    # models.TabularTransformerClassifier,
    models.LinearRegression,
    models.MLPRegressor,
    # models.TabularTransformerRegressor,
    models.RandomForestClassifier,
    # models.TabularTransformerClassifier,
    # models.TabularTransformerRegressor,
    models.AutoEncoderMLPRegressor,
    models.AutoEncoderMLPClassifier,
    models.ConvRNNModelClassifier,
    models.ConvRNNModelRegressor,
    models.CNN1DModelRegressor,
    models.CNN1DModelClassifier,
    models.RNNModelRegressor,
    models.RNNModelClassifier,
]

_CLASSIFIERS = [md for md in _OMNIA_MODELS if issubclass(md, models.ClassifierMixin)]
_REGRESSORS = [md for md in _OMNIA_MODELS if issubclass(md, models.RegressorMixin)]
_MULTITASK_CLASSIFIERS = [md for md in _OMNIA_MODELS if issubclass(md, models.MultiOutputMixin) and
                          issubclass(md, models.ClassifierMixin)]
_MULTITASK_REGRESSORS = [md for md in _OMNIA_MODELS if issubclass(md, models.MultiOutputMixin) and
                         issubclass(md, models.RegressorMixin)]

_IMPUTERS = {'simple': SimpleImputer, 'knn_imputer': KNNImputer}

_SCALERS = {'standard': StandardScaler, 'passthrough': PassthroughTransformer}

_FEATURE_SELECTORS = {'boruta': BorutaTransformer,
                      'passthrough': PassthroughTransformer}


def _to_optuna(trial: Trial, params: dict) -> dict:
    """
    Convert the parameters to optuna search space.

    Parameters
    ----------
    trial: optuna.trial.Trial
        The optuna trial object
    params: dict
        The parameters to convert to optuna search space.

    Returns
    -------
    dict
        The parameters with the optuna search space.
    """
    # remove non tunable parameters
    params = {k: v for k, v in params.items() if v.tunable}
    # make suggestions based on param space using optuna
    for name, descriptor in params.items():
        space = descriptor.space
        if space is None:
            continue
        if space.name == 'Real':
            params[name] = trial.suggest_float(
                name, space.lower, space.upper, log=space.log)
        elif space.name == 'Int':
            params[name] = trial.suggest_int(name, space.lower, space.upper)
        elif space.name == 'Categorical':
            params[name] = trial.suggest_categorical(name, space.data)
        elif space.name == 'Bool':
            params[name] = trial.suggest_categorical(name, [True, False])
    return params


class _PredictorMixIn:

    @staticmethod
    def _nni_search_space(predictor,
                          autostack=False,
                          hyperparameter_tune_kwargs=False,
                          bagging_stacking=False):
        _models_nni = {
            "_type": 'choice',
            "_value": [[f'{model.__module__}.{model.__name__}' for model in _AG_MODELS]]
        }

        _predictor_params = {'_name': f'{predictor.__module__}.{predictor.__name__}',
                             'models': _models_nni}

        if autostack:
            _predictor_params['auto_stack'] = {
                '_type': 'choice', '_value': [True, False]}

        if hyperparameter_tune_kwargs:
            _predictor_params['hyperparameter_tune_kwargs'] = {
                '_type': 'choice',
                '_value': [{'num_trials': 10,
                            'scheduler': 'local',
                            'searcher': "random"},
                           {'num_trials': 20,
                            'scheduler': 'local',
                            'searcher': "random"}]
            }

        if bagging_stacking:
            _predictor_params['num_bag_folds'] = {
                '_type': 'choice', '_value': [0, 2, 5]}
            _predictor_params['num_bag_sets'] = {
                '_type': 'choice', '_value': [0, 1, 2, 5]}
            _predictor_params['num_stack_levels'] = {
                '_type': 'choice', '_value': [0, 1, 2]}

        return [_predictor_params]

    @staticmethod
    def _hp_search_space(predictor,
                         autostack=False,
                         hyperparameter_tune_kwargs=False,
                         bagging_stacking=False):
        _models_hp = [model.name for model in _AG_MODELS]

        _predictor_params = {'name': predictor.name,
                             'models': _models_hp}

        if autostack:
            _predictor_params['auto_stack'] = hp.choice(
                f'{predictor.name}.auto_stack', [True, False])

        if hyperparameter_tune_kwargs:
            _predictor_params['hyperparameter_tune_kwargs'] = {
                'num_trials': hp.qloguniform(f'{predictor.name}.num_trials', 2, 3, 1),
                'scheduler': 'local',
                'searcher': "random",
            }

        if bagging_stacking:
            _predictor_params['num_bag_folds'] = hp.quniform(
                f'{predictor.name}.num_bag_folds', 2, 10, 1)
            _predictor_params['num_bag_sets'] = hp.qloguniform(
                f'{predictor.name}.num_bag_sets', 0, 1, 1)
            _predictor_params['num_stack_levels'] = hp.qloguniform(
                f'{predictor.name}.num_stack_levels', 0, 1, 1)

        return hp.choice('predictor', [_predictor_params])

    def nni_search_space(self: Union['_PredictorMixIn', 'LightSearchSpace', 'MediumSearchSpace', 'HeavySearchSpace']):
        return self.predictor.to_nni()

    def hp_search_space(self: Union['_PredictorMixIn', 'LightSearchSpace', 'MediumSearchSpace', 'HeavySearchSpace']):
        return self.predictor.to_hp(idx=0)


class OmniaPresetBase:

    @staticmethod
    def get_imputer(trial: Trial, impute: bool = True, **kwargs) -> 'Transformer':
        """
        Get the imputer to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        impute: bool
            Whether to impute the data or not.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Transformer
            The imputer to use in the pipeline.
        """
        if not impute:
            return PassthroughTransformer()
        imputer = trial.suggest_categorical('imputer', list(_IMPUTERS.keys()))
        return _IMPUTERS[imputer]()

    @staticmethod
    def get_scaler(trial: Trial, scale: bool = False, **kwargs) -> 'Transformer':
        """
        Get the scaler to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        scale: bool
            Whether to scale the data or not.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Transformer
            The scaler to use in the pipeline.
        """
        if not scale:
            return PassthroughTransformer()
        scaler = trial.suggest_categorical('scaler', list(_SCALERS.keys()))
        return _SCALERS[scaler]()

    @staticmethod
    def get_feature_selector(trial: Trial, select: bool = False, **kwargs) -> 'Transformer':
        """
        Get the feature selector to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        select: bool
            Whether to select the features or not.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Transformer
            The feature selector to use in the pipeline.
        """
        if not select:
            return PassthroughTransformer()
        feature_selectors = list(_FEATURE_SELECTORS.keys())
        if kwargs.get('task_type') not in ['classification', 'multiclass', 'binary']:
            feature_selectors.remove('boruta')
        feature_selector = trial.suggest_categorical(
            'feature_selector', feature_selectors)
        return _FEATURE_SELECTORS[feature_selector]()

    @staticmethod
    def get_predictor(trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                      hpo: bool = False, autostack: bool = False, hyperparameter_tune_kwargs: bool = False,
                      bagging_stacking: bool = False,
                      **kwargs) -> Union[Predictor, Model]:
        """
        Get the predictor to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type to use.
        hpo: bool
            Whether to perform hyperparameter optimization or not in TabularPredictor.
        autostack: bool
            Whether to use auto stack in TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs in TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging_stacking in TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Union[Predictor, Model]
            The predictor or model to use in the pipeline.
        """
        # check task type and input type
        if task_type.value in [TaskTag.BINARY.value, TaskTag.MULTICLASS.value]:
            available_models = _CLASSIFIERS + [TabularPredictor]
            args = {'n_classes': n_classes}
        elif task_type.value == TaskTag.REGRESSION.value:
            available_models = _REGRESSORS + [TabularPredictor]
            args = {}
        elif task_type.value in [TaskTag.MULTITASK_BINARY.value, TaskTag.MULTITASK_MULTICLASS.value]:
            available_models = _MULTITASK_CLASSIFIERS
            args = {'n_tasks': n_tasks, 'n_classes': n_classes}
        elif task_type.value == TaskTag.MULTITASK_REGRESSION.value:
            available_models = _MULTITASK_REGRESSORS
            args = {'n_tasks': n_tasks}
        else:
            raise ValueError(f"Task type {kwargs.get('task_type')} not supported. Must be one of "
                             f"['classification', 'multiclass', 'binary', 'regression', 'multitask_classification', "
                             f"'multitask_regression']")
        # input type
        if input_type.value is not None:
            available_models = {model.name: model for model in available_models if
                                model._input_type.value == input_type.value}
        else:
            available_models = {
                model.name: model for model in available_models}
        predictor = trial.suggest_categorical(
            f'model_{input_type.value}', list(available_models.keys()))
        if predictor == TabularPredictor.name:
            if hyperparameter_tune_kwargs:
                hyperparameter_tune_kwargs = {'num_trials': 20,
                                              'scheduler': 'local',
                                              'searcher': "random"}
            else:
                hyperparameter_tune_kwargs = None
            if bagging_stacking:
                num_bag_folds = trial.suggest_categorical(
                    'num_bag_folds', [2, 5])
                num_bag_sets = trial.suggest_categorical(
                    'num_bag_sets', [1, 2, 5])
                num_stack_levels = trial.suggest_categorical(
                    'num_stack_levels', [1, 2])
            else:
                num_bag_folds, num_bag_sets, num_stack_levels = None, None, None
            return TabularPredictor(models=_AG_MODELS, auto_stack=autostack,
                                    hyperparameter_tune_kwargs=hyperparameter_tune_kwargs, num_bag_folds=num_bag_folds,
                                    num_bag_sets=num_bag_sets, num_stack_levels=num_stack_levels)
        params = {}
        if hpo:
            params = available_models[predictor]._get_parameters()
            params = _to_optuna(trial, params)
        model = available_models[predictor]
        if not issubclass(model, ScikitLearnBaseModel):
            if 'binary' in task_type.value:
                if model.name == 'AutoEncoderMLPClassifier':
                    args.update({'loss': ['mse', 'binary_crossentropy']})
                else:
                    args.update({'loss': 'binary_crossentropy'})
                args.update({'last_layer_activation': 'sigmoid'})
            elif 'multiclass' in task_type.value:
                if model.name == 'AutoEncoderMLPClassifier':
                    args.update({'loss': ['mse', 'categorical_crossentropy']})
                else:
                    args.update({'loss': 'categorical_crossentropy'})
                args.update({'last_layer_activation': 'softmax'})
            # add additional arguments
            params.update(args)
        # TODO: EarlyStopping somehow messes up with the PipelineOptimization process by ending it whenever EarlyStopping is used
        # if issubclass(model, KerasModel) or issubclass(model, TorchModel):
        #     callbacks = [EarlyStopping(model=model, monitor='val_loss', patience=15)]
        #     return model(callbacks=callbacks, **params)
        return model(**params)

    def _get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag, hpo: bool,
                   autostack: bool, hyperparameter_tune_kwargs: bool, bagging_stacking: bool, impute: bool, scale: bool,
                   select: bool, **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type to use.
        hpo: bool
            Whether to perform hyperparameter optimization or not in TabularPredictor.
        autostack: bool
            Whether to use auto stack in TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs in TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging_stacking in TabularPredictor.
        impute: bool
            Whether to impute the data or not.
        scale: bool
            Whether to scale the data or not.
        select: bool
            Whether to select the features or not.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps to use in the pipeline.
        """
        perform_tag = input_type.value == DataTag.TABULAR.value
        impute = impute and perform_tag
        scale = scale and perform_tag
        select = select and perform_tag
        imputer = self.get_imputer(trial, impute=impute, **kwargs)
        drop_fun = PassthroughTransformer() if not perform_tag else FunctionTransformer(function=drop_duplicates)
        scaler = self.get_scaler(trial, scale=scale, **kwargs)
        feature_selector = self.get_feature_selector(
            trial, select=select, **kwargs)
        predictor = self.get_predictor(trial, task_type=task_type, n_tasks=n_tasks, n_classes=n_classes,
                                       input_type=input_type, hpo=hpo, autostack=autostack,
                                       hyperparameter_tune_kwargs=hyperparameter_tune_kwargs,
                                       bagging_stacking=bagging_stacking, **kwargs)
        return [
            ('imputer', imputer),
            ('drop_duplicates', drop_fun),
            ('scaler', scaler),
            ('feature_selector', feature_selector),
            ('predictor', predictor)
        ]

    @abstractmethod
    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps to use in the pipeline.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type to use.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps to use in the pipeline.
        """
        ...


@search_space_register
class LightSearchSpace(_PredictorMixIn, OmniaPresetBase, BaseSearchSpace):
    """
    Light search space for the HPO.
    It tests all models using the default parameters.
    """
    name = 'omnia.generics.light'

    def __init__(self, predictor=TabularPredictor, *args, **kwargs):
        super().__init__(*args, **kwargs)

        _nni_params = self._nni_search_space(predictor)
        _hp_params = self._hp_search_space(predictor)

        self.predictor = Step(
            name='predictor',
            type_='choice',
            nni_params=_nni_params,
            hp_params=_hp_params
        )

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps to use in the pipeline for the light search space.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type to use.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps to use in the pipeline.
        """
        return self._get_steps(trial, task_type, n_tasks, n_classes, input_type, hpo=False, autostack=False,
                               hyperparameter_tune_kwargs=False, bagging_stacking=False, impute=True, scale=False,
                               select=False, **kwargs)


@search_space_register
class MediumSearchSpace(_PredictorMixIn, OmniaPresetBase, BaseSearchSpace):
    """
    Medium search space for the HPO.
    It tests all models using the following:
        - default parameters + auto_stack
    """
    name = 'omnia.generics.medium'

    def __init__(self, predictor=TabularPredictor, *args, **kwargs):
        super().__init__(*args, **kwargs)

        _nni_params = self._nni_search_space(predictor, autostack=True)
        _hp_params = self._hp_search_space(predictor, autostack=True)

        self.predictor = Step(
            name='predictor',
            type_='choice',
            nni_params=_nni_params,
            hp_params=_hp_params
        )

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps to use in the pipeline for the medium search space.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type to use.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps to use in the pipeline.
        """
        return self._get_steps(trial, task_type, n_tasks, n_classes, input_type, hpo=False, autostack=True,
                               hyperparameter_tune_kwargs=False, bagging_stacking=False, impute=True, scale=True,
                               select=True, **kwargs)


@search_space_register
class HeavySearchSpace(_PredictorMixIn, OmniaPresetBase, BaseSearchSpace):
    """
    Heavy search space for the HPO.
    It tests all models using the following strategies:
        - default parameters + auto_stack
        - default parameters + stack (several options)
        - default search space and AutoGluon random search
    """
    name = 'omnia.generics.heavy'

    def __init__(self, predictor=TabularPredictor, *args, **kwargs):
        super().__init__(*args, **kwargs)

        _nni_params = self._nni_search_space(predictor,
                                             autostack=True,
                                             hyperparameter_tune_kwargs=True,
                                             bagging_stacking=True)
        _hp_params = self._hp_search_space(predictor,
                                           autostack=True,
                                           hyperparameter_tune_kwargs=True,
                                           bagging_stacking=True)

        self.predictor = Step(
            name='predictor',
            type_='choice',
            nni_params=_nni_params,
            hp_params=_hp_params
        )

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps to use in the pipeline for the heavy search space.

        Parameters
        ----------
        trial: optuna.trial.Trial
            The optuna trial object
        task_type: TaskTag
            The task type to perform.
        n_tasks: int
            The number of tasks to perform.
        n_classes: int
            The number of classes to predict.
        input_type: DataTag
            The input type to use.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps to use in the pipeline.
        """
        return self._get_steps(trial, task_type, n_tasks, n_classes, input_type, hpo=True, autostack=True,
                               hyperparameter_tune_kwargs=True, bagging_stacking=True, impute=True, scale=True,
                               select=True, **kwargs)
