from typing import Optional
from omnia.generics import np


def threshold_predictions(y: np.ndarray, threshold: Optional[float] = None) -> np.ndarray:
    """
    Threshold predictions from classification model.

    Parameters
    ----------
    y: np.ndarray
        Must have shape `(n_samples, n_classes)` and be class probabilities.
    threshold: float, default None
        The threshold probability for the positive class. Note that this
        threshold will only be applied for binary classifiers (where
        `n_classes==2`). If specified for multiclass problems, or if
        `threshold` is None, the threshold is ignored and argmax(y) is
        returned.

    Returns
    -------
    y_out: np.ndarray
        A numpy array of shape `(n_samples,)` with class predictions as integers ranging from 0
        to `n_classes-1`.
    """
    if not isinstance(y, np.ndarray) or not len(y.shape) == 2:
        raise ValueError("y must be a ndarray of shape (n_samples, n_classes)")
    n_samples = y.shape[0]
    n_classes = y.shape[1]
    if n_classes != 2 or threshold is None:
        return np.argmax(y, axis=1)
    else:
        return np.where(y[:, 1] >= threshold, np.ones(n_samples), np.zeros(n_samples))


def normalize_weight_shape(w: Optional[np.ndarray], n_samples: int, n_tasks: int) -> np.ndarray:
    """
    A utility function to correct the shape of the weight array.

    This utility function is used to normalize the shapes of a given
    weight array.

    Parameters
    ----------
    w: np.ndarray
        `w` can be `None` or a scalar or a `np.ndarray` of shape
        `(n_samples,)` or of shape `(n_samples, n_tasks)`. If `w` is a
        scalar, it's assumed to be the same weight for all samples/tasks.
    n_samples: int
        The number of samples in the dataset. If `w` is not None, we should
        have `n_samples = w.shape[0]` if `w` is a ndarray
    n_tasks: int
        The number of tasks. If `w` is 2d ndarray, then we should have
        `w.shape[1] == n_tasks`.

    Examples
    --------
    >>> import numpy as np
    >>> w_out = normalize_weight_shape(None, n_samples=10, n_tasks=1)
    >>> (w_out == np.ones((10, 1))).all()
    True

    Returns
    -------
    w_out: np.ndarray
        Array of shape `(n_samples, n_tasks)`
    """
    if w is None:
        w_out = np.ones((n_samples, n_tasks))
    elif isinstance(w, np.ndarray):
        if len(w.shape) == 0:
            # scalar case
            w_out = w * np.ones((n_samples, n_tasks))
        elif len(w.shape) == 1:
            if len(w) != n_samples:
                raise ValueError("Length of w isn't n_samples")
            # per-example case
            # This is a little arcane but it repeats w across tasks.
            w_out = np.tile(w, (n_tasks, 1)).T
        elif len(w.shape) == 2:
            if w.shape == (n_samples, 1):
                # If w.shape == (n_samples, 1) handle it as 1D
                w = np.squeeze(w, axis=1)
                w_out = np.tile(w, (n_tasks, 1)).T
            elif w.shape != (n_samples, n_tasks):
                raise ValueError(
                    "Shape for w doens't match (n_samples, n_tasks)")
            else:
                # w.shape == (n_samples, n_tasks)
                w_out = w
        else:
            raise ValueError("w must be of dimension 1, 2, or 3")
    else:
        # scalar case
        w_out = w * np.ones((n_samples, n_tasks))
    return w_out


def normalize_labels_shape(y: np.ndarray, mode: Optional[str] = None, n_tasks: Optional[int] = None,
                           n_classes: Optional[int] = None) -> np.ndarray:
    """
    A utility function to correct the shape of the labels.

    Parameters
    ----------
    y: np.ndarray
        `y` is an array of shape `(n_samples,)` or `(n_samples, n_tasks)` or `(n_samples, n_tasks, 1)`.
    mode: str, default None
        If `mode` is "classification" or "regression", attempts to apply
        data transformations.
    n_tasks: int, default None
        The number of tasks this class is expected to handle.
    n_classes: int, default None
        If specified use this as the number of classes. Else will try to
        impute it as `n_classes = max(y) + 1` for arrays and as
        `n_classes=2` for the case of scalars. Note this parameter only
        has value if `mode=="classification"`

    Returns
    -------
    y_out: np.ndarray
        If `mode=="classification"`, `y_out` is an array of shape `(n_samples,
        n_tasks, n_classes)`. If `mode=="regression"`, `y_out` is an array
        of shape `(n_samples, n_tasks)`.
    """
    if n_tasks is None:
        raise ValueError("n_tasks must be specified")
    if mode not in ["classification", "regression"]:
        raise ValueError("mode must be either classification or regression.")
    if mode == "classification" and n_classes is None:
        raise ValueError("n_classes must be specified")
    if not isinstance(y, np.ndarray):
        raise ValueError("y must be a np.ndarray")
    # Handle n_classes/n_task shape ambiguity
    if mode == "classification" and len(y.shape) == 2:
        if n_classes == y.shape[1] and n_tasks != 1 and n_classes != n_tasks:
            raise ValueError("Shape of input doesn't match expected n_tasks=1")
        elif n_classes == y.shape[1] and n_tasks == 1:
            # Add in task dimension
            y = np.expand_dims(y, 1)
    if len(y.shape) == 1 and n_tasks != 1:
        raise ValueError("n_tasks must equal 1 for a 1D set of labels.")
    if (len(y.shape) == 2 or len(y.shape) == 3) and n_tasks != y.shape[1]:
        raise ValueError("Shape of input doesn't match expected n_tasks=%d" % n_tasks)
    if len(y.shape) >= 4:
        raise ValueError(
            "Labels y must be a float scalar or a ndarray of shape `(n_samples,)` or "
            "`(n_samples, n_tasks)` or `(n_samples, n_tasks, 1)` for regression problems and "
            "of shape `(n_samples,)` or `(n_samples, n_tasks)` or `(n_samples, n_tasks, 1)` for classification problems"
        )
    if len(y.shape) == 1:
        # Insert a task dimension (we know n_tasks=1 from above0
        y_out = np.expand_dims(y, 1)
    elif len(y.shape) == 2:
        y_out = y
    elif len(y.shape) == 3:
        # If 3D and last dimension isn't 1, assume this is one-hot encoded and return as-is.
        if y.shape[-1] != 1:
            return y
        y_out = np.squeeze(y, axis=-1)
    # Handle classification. We need to convert labels into one-hot representation.
    if mode == "classification":
        all_y_task = []
        for task in range(n_tasks):
            y_task = y_out[:, task]
            # check whether n_classes is int or not
            assert isinstance(n_classes, int)
            y_hot = to_one_hot(y_task, n_classes=n_classes)
            y_hot = np.expand_dims(y_hot, 1)
            all_y_task.append(y_hot)
        y_out = np.concatenate(all_y_task, axis=1)
    return y_out


def normalize_prediction_shape(y: np.ndarray, mode: Optional[str] = None, n_tasks: Optional[int] = None,
                               n_classes: Optional[int] = None) -> np.ndarray:
    """
    A utility function to correct the shape of provided predictions.

    The metric computation classes expect that inputs for classification
    have the uniform shape `(n_samples, n_tasks, n_classes)` and inputs for
    regression have the uniform shape `(n_samples, n_tasks)`. This function
    normalizes the provided input array to have the desired shape.

    Examples
    --------
    >>> import numpy as np
    >>> y = np.random.rand(10)
    >>> y_out = normalize_prediction_shape(y, "regression", n_tasks=1)
    >>> y_out.shape
    (10, 1)

    Parameters
    ----------
    y: np.ndarray
        If `mode=="classification"`, `y` is an array of shape `(n_samples,)` or
        `(n_samples, n_tasks)` or `(n_samples, n_tasks, n_classes)`. If
        `mode=="regression"`, `y` is an array of shape `(n_samples,)` or `(n_samples,
        n_tasks)`or `(n_samples, n_tasks, 1)`.
    mode: str, default None
        If `mode` is "classification" or "regression", attempts to apply
        data transformations.
    n_tasks: int, default None
        The number of tasks this class is expected to handle.
    n_classes: int, default None
        If specified use this as the number of classes. Else will try to
        impute it as `n_classes = max(y) + 1` for arrays and as
        `n_classes=2` for the case of scalars. Note this parameter only
        has value if `mode=="classification"`

    Returns
    -------
    y_out: np.ndarray
      If `mode=="classification"`, `y_out` is an array of shape `(n_samples,
      n_tasks, n_classes)`. If `mode=="regression"`, `y_out` is an array
      of shape `(n_samples, n_tasks)`.
    """
    if n_tasks is None:
        raise ValueError("n_tasks must be specified")
    if mode == "classification" and n_classes is None:
        raise ValueError("n_classes must be specified")
    if not isinstance(y, np.ndarray):
        raise ValueError("y must be a np.ndarray")
    # Handle n_classes/n_task shape ambiguity
    if mode == "classification" and len(y.shape) == 2:
        if n_classes == y.shape[1] and n_tasks != 1 and n_classes != n_tasks:
            raise ValueError("Shape of input doesn't match expected n_tasks=1")
        elif n_classes == y.shape[1] and n_tasks == 1:
            # Add in task dimension
            y = np.expand_dims(y, 1)
    if (len(y.shape) == 2 or len(y.shape) == 3) and n_tasks != y.shape[1]:
        raise ValueError("Shape of input doesn't match expected n_tasks=%d" %
                         n_tasks)
    if len(y.shape) >= 4:
        raise ValueError(
            "Predictions y must be a float scalar or a ndarray of shape `(n_samples,)` or "
            "`(n_samples, n_tasks)` or `(n_samples, n_tasks, 1)` for regression problems and "
            "of shape `(n_samples,)` or `(n_samples, n_tasks)` or `(n_samples, n_tasks, n_classes)` for "
            "classification problems"
        )
    if mode == "classification":
        if n_classes is None:
            raise ValueError("n_classes must be specified.")
        if len(y.shape) == 1 or len(y.shape) == 2:
            # Make everything 2D so easy to handle
            if len(y.shape) == 1:
                y = y[:, np.newaxis]
            # Handle each task separately.
            all_y_task = []
            for task in range(n_tasks):
                y_task = y[:, task]
                if len(np.unique(y_task)) > n_classes:
                    # Handle continuous class probabilites of positive class for binary
                    if n_classes > 2:
                        raise ValueError(
                            "Cannot handle continuous probabilities for multiclass problems."
                            "Need a per-class probability")
                    # Fill in class 0 probabilities
                    y_task = np.array([1 - y_task, y_task]).T
                    # Add a task dimension to concatenate on
                    y_task = np.expand_dims(y_task, 1)
                    all_y_task.append(y_task)
                else:
                    # Handle binary labels
                    # make y_hot of shape (n_samples, n_classes)
                    y_task = to_one_hot(y_task, n_classes=n_classes)
                    # Add a task dimension to concatenate on
                    y_task = np.expand_dims(y_task, 1)
                    all_y_task.append(y_task)
            y_out = np.concatenate(all_y_task, axis=1)
        elif len(y.shape) == 3:
            y_out = y
    elif mode == "regression":
        if len(y.shape) == 1:
            # Insert a task dimension
            y_out = np.expand_dims(y, 1)
        elif len(y.shape) == 2:
            y_out = y
        elif len(y.shape) == 3:
            if y.shape[-1] != 1:
                raise ValueError(
                    "y must be a float scalar or a ndarray of shape `(n_samples,)` or "
                    "`(n_samples, n_tasks)` or `(n_samples, n_tasks, 1)` for regression problems."
                )
            y_out = np.squeeze(y, axis=-1)
    else:
        raise ValueError("mode must be either classification or regression.")
    return y_out


def handle_classification_mode(y: np.ndarray, classification_handling_mode: Optional[str],
                               threshold_value: Optional[float] = None) -> np.ndarray:
    """
    Handle classification mode.

    Transform predictions so that they have the correct classification mode.

    Parameters
    ----------
    y: np.ndarray
        Must be of shape `(n_samples, n_tasks, n_classes)`
    classification_handling_mode: str, default None
        Models by default predict class probabilities for
        classification problems. This means that for a given singletask
        prediction, after shape normalization, the prediction will be a
        numpy array of shape `(n_samples, n_classes)` with class probabilities.
        `classification_handling_mode` is a string that instructs this method
        how to handle transforming these probabilities. It can take on the
        following values:
        - None: default value. Pass in `y_pred` directy into `self.metric`.
        - "threshold": Use `threshold_predictions` to threshold `y_pred`. Use
          `threshold_value` as the desired threshold.
        - "threshold-one-hot": Use `threshold_predictions` to threshold `y_pred`
          using `threshold_values`, then apply `to_one_hot` to output.
    threshold_value: float, default None
        If set, and `classification_handling_mode` is "threshold" or
        "threshold-one-hot" apply a thresholding operation to values with this
        threshold. This option isj only sensible on binary classification tasks.
        If float, this will be applied as a binary classification value.

    Returns
    -------
    y_out: np.ndarray
        If `classification_handling_mode` is "direct", then of shape `(n_samples, n_tasks, n_classes)`.
        If `classification_handling_mode` is "threshold", then of shape `(n_samples, n_tasks)`.
        If `classification_handling_mode is "threshold-one-hot", then of shape `(n_samples, n_tasks, n_classes)"
    """
    if len(y.shape) != 3:
        raise ValueError("y must be of shape (n_samples, n_tasks, n_classes)")
    n_samples, n_tasks, n_classes = y.shape
    if classification_handling_mode == "direct":
        return y
    elif classification_handling_mode == "threshold":
        thresholded = []
        for task in range(n_tasks):
            task_array = y[:, task, :]
            # Now of shape (n_samples,)
            task_array = threshold_predictions(task_array, threshold_value)
            # Now of shape (n_samples, 1)
            task_array = np.expand_dims(task_array, 1)
            thresholded.append(task_array)
        # Returns shape (n_samples, n_tasks)
        return np.concatenate(thresholded, axis=1)
    elif classification_handling_mode == "threshold-one-hot":
        thresholded = []
        for task in range(n_tasks):
            task_array = y[:, task, :]
            # Now of shape (n_samples,)
            task_array = threshold_predictions(task_array, threshold_value)
            # Now of shape (n_samples, n_classes)
            task_array = to_one_hot(task_array, n_classes=n_classes)
            # Now of shape (n_samples, 1, n_classes)
            task_array = np.expand_dims(task_array, 1)
            thresholded.append(task_array)
        # Returns shape (n_samples, n_tasks, n_classes)
        return np.concatenate(thresholded, axis=1)
    else:
        raise ValueError(
            "classification_handling_mode must be one of direct, threshold, threshold-one-hot"
        )


def to_one_hot(y: np.ndarray, n_classes: int = 2) -> np.ndarray:
    """
    Transforms label vector into one-hot encoding.

    Turns y into vector of shape `(n_samples, n_classes)` with a one-hot
    encoding. Assumes that `y` takes values from `0` to `n_classes - 1`.

    Parameters
    ----------
    y: np.ndarray
        A vector of shape `(n_samples,)` or `(n_samples, 1)`
    n_classes: int, default 2
        If specified use this as the number of classes. Else will try to
        impute it as `n_classes = max(y) + 1` for arrays and as
        `n_classes=2` for the case of scalars. Note this parameter only
        has value if `mode=="classification"`

    Returns
    -------
    np.ndarray
        A numpy array of shape `(n_samples, n_classes)`.
    """
    if len(y.shape) > 2:
        raise ValueError("y must be a vector of shape (n_samples,) or (n_samples, 1)")
    if len(y.shape) == 2 and y.shape[1] != 1:
        raise ValueError("y must be a vector of shape (n_samples,) or (n_samples, 1)")
    if len(np.unique(y)) > n_classes:
        raise ValueError("y has more than n_class unique elements.")
    n_samples = np.shape(y)[0]
    y_hot = np.zeros((n_samples, n_classes))
    y_hot[np.arange(n_samples), y.astype(np.int64)] = 1
    return y_hot


def from_one_hot(y: np.ndarray, axis: int = 1) -> np.ndarray:
    """
    Transforms label vector from one-hot encoding.

    Parameters
    ----------
    y: np.ndarray
        A vector of shape `(n_samples, num_classes)`
    axis: int, optional (default 1)
        The axis with one-hot encodings to reduce on.

    Returns
    -------
    np.ndarray
        A numpy array of shape `(n_samples,)`
    """
    return np.argmax(y, axis=axis)
