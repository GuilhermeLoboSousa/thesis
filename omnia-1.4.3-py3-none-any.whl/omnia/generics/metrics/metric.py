from typing import Any, Callable, Optional
from omnia.generics import np
from omnia.generics.metrics._utils import (handle_classification_mode,
                                           normalize_labels_shape,
                                           normalize_prediction_shape,
                                           normalize_weight_shape)
import inspect


class Metric:
    """
    Wrapper class for computing user-defined metrics.

    The `Metric` class provides a wrapper for standardizing the API
    around different classes of metrics that may be useful for Omnia
    models. The implementation provides a few non-standard conveniences
    such as built-in support for multitask and multiclass metrics.

    There are a variety of different metrics this class aims to support.
    Metrics for classification and regression that assume that values to
    compare are scalars are supported.

    At present, this class doesn't support metric computation on models
    which don't present scalar outputs. For example, if you have a
    generative model which predicts images or molecules, you will need
    to write a custom evaluation and metric setup.
    """

    def __init__(self, metric: Callable[..., float], task_averager: Optional[Callable[..., Any]] = None,
                 name: Optional[str] = None, mode: Optional[str] = None,
                 classification_handling_mode: Optional[str] = None, threshold_value: Optional[float] = None, **kwargs):
        """
        Parameters
        ----------
        metric: function
            Function that takes args y_true, y_pred (in that order) and
            computes desired score. If sample weights are to be considered,
            `metric` may take in an additional keyword argument
            `sample_weight`.
        task_averager: function, default None
            If not None, should be a function that averages metrics across
            tasks.
        name: str, default None
            Name of this metric
        mode: str, default None
            Should usually be "classification" or "regression."
        classification_handling_mode: str, default None
            Models by default predict class probabilities for
            classification problems. This means that for a given singletask
            prediction, after shape normalization, the labels and prediction will be
            numpy arrays of shape `(n_samples, n_tasks, n_classes)` with class probabilities.
            `classification_handling_mode` is a string that instructs this method
            how to handle transforming these probabilities. It can take on the
            following values:
            - "direct": Pass `y_true` and `y_pred` directy into `self.metric`.
            - "threshold": Use `threshold_predictions` to threshold `y_true` and `y_pred`.
              Use `threshold_value` as the desired threshold. This converts them into
              arrays of shape `(n_samples, n_tasks)`, where each element is a class index.
            - "threshold-one-hot": Use `threshold_predictions` to threshold `y_true` and `y_pred`
              using `threshold_values`, then apply `to_one_hot` to output.
            - None: Select a mode automatically based on the metric.
        threshold_value: float, default None
            If set, and `classification_handling_mode` is "threshold" or
            "threshold-one-hot", apply a thresholding operation to values with this
            threshold. This option is only sensible on binary classification tasks.
            For multiclass problems, or if `threshold_value` is None, argmax() is used
            to select the highest probability class for each task.
        """

        self.metric = metric
        if task_averager is None:
            self.task_averager = np.mean
        else:
            self.task_averager = task_averager
        if name is None:
            if task_averager is None:
                if hasattr(self.metric, '__name__'):
                    self.name = self.metric.__name__
                else:
                    self.name = "unknown metric"
            else:
                if hasattr(self.metric, '__name__'):
                    self.name = task_averager.__name__ + "-" + self.metric.__name__
                else:
                    self.name = "unknown metric"
        else:
            self.name = name

        if mode is None:
            # These are some smart defaults
            if self.metric.__name__ in [
                    "roc_auc_score", "matthews_corrcoef", "recall_score",
                    "accuracy_score", "kappa_score", "cohen_kappa_score",
                    "precision_score", "precision_recall_curve",
                    "balanced_accuracy_score", "prc_auc_score", "f1_score",
                    "bedroc_score", "jaccard_score", "jaccard_index",
                    "pixel_error"
            ]:
                mode = "classification"
            elif self.metric.__name__ in [
                    "pearson_r2_score", "r2_score", "mean_squared_error",
                    "mean_absolute_error", "rms_score", "mae_score", "pearsonr",
                    "concordance_index", "root_mean_squared_error"
            ]:
                mode = "regression"
            else:
                raise ValueError(
                    "Please specify the mode of this metric. mode must be 'regression' or 'classification'"
                )
        if mode == "classification":
            if classification_handling_mode is None:
                # These are some smart defaults corresponding to sklearn's required
                # behavior
                if self.metric.__name__ in [
                        "matthews_corrcoef", "cohen_kappa_score", "kappa_score",
                        "balanced_accuracy_score", "recall_score",
                        "jaccard_score", "jaccard_index", "pixel_error",
                        "f1_score"
                ]:
                    classification_handling_mode = "threshold"
                elif self.metric.__name__ in [
                        "accuracy_score", "precision_score", "bedroc_score"
                ]:
                    classification_handling_mode = "threshold-one-hot"
                elif self.metric.__name__ in [
                        "roc_auc_score", "prc_auc_score",
                        "precision_recall_curve"
                ]:
                    classification_handling_mode = "direct"
            if classification_handling_mode not in [
                    "direct", "threshold", "threshold-one-hot"
            ]:
                raise ValueError(
                    "classification_handling_mode must be one of 'direct', 'threshold', 'threshold_one_hot'"
                )

        self.mode = mode
        self.classification_handling_mode = classification_handling_mode
        self.threshold_value = threshold_value

    def compute_metric(self, y_true: np.typing.ArrayLike, y_pred: np.typing.ArrayLike, n_tasks: Optional[int] = None,
                       n_classes: int = 2, w: Optional[np.typing.ArrayLike] = None, per_task_metrics: bool = False,
                       **kwargs) -> Any:
        """
        Compute a performance metric for each task.

        Parameters
        ----------
        y_true: ArrayLike
            An ArrayLike containing true values for each task. Must be of shape
            `(N,)` or `(N, n_tasks)` or `(N, n_tasks, n_classes)` if a
            classification metric. If of shape `(N, n_tasks)` values can either be
            class-labels or probabilities of the positive class for binary
            classification problems. If a regression problem, must be of shape
            `(N,)` or `(N, n_tasks)` or `(N, n_tasks, 1)` if a regression metric.
        y_pred: ArrayLike
            An ArrayLike containing predicted values for each task. Must be
            of shape `(N, n_tasks, n_classes)` if a classification metric,
            else must be of shape `(N, n_tasks)` if a regression metric.
        n_tasks: int, default None
            The number of tasks this class is expected to handle.
        n_classes: int, default 2
            Number of classes in data for classification tasks.
        per_task_metrics: bool, default False
            If true, return computed metric for each task on multitask dataset.
        w: ArrayLike, default None
            An ArrayLike containing weights for each datapoint. If
            specified,  must be of shape `(N, n_tasks)`.
        kwargs: dict
            Will be passed on to self.metric

        Returns
        -------
        np.ndarray
            A numpy array containing metric values for each task.
        """
        # Attempt some limited shape imputation to find n_tasks
        y_true_arr = np.asarray(y_true)
        y_pred_arr = np.asarray(y_pred)
        use_weights = w is not None
        if n_tasks is None and isinstance(y_true_arr, np.ndarray):
            if len(y_true_arr.shape) == 1:
                n_tasks = 1
            elif len(y_true_arr.shape) >= 2:
                n_tasks = y_true_arr.shape[1]

        # check whether n_tasks is int or not
        # This is because `normalize_weight_shape` require int value.
        assert isinstance(n_tasks, int)

        y_true_arr = normalize_labels_shape(
            y_true_arr, mode=self.mode, n_tasks=n_tasks, n_classes=n_classes)
        y_pred_arr = normalize_prediction_shape(
            y_pred_arr, mode=self.mode, n_tasks=n_tasks, n_classes=n_classes)
        if self.mode == "classification":
            y_true_arr = handle_classification_mode(
                y_true_arr, self.classification_handling_mode, self.threshold_value)
            y_pred_arr = handle_classification_mode(
                y_pred_arr, self.classification_handling_mode, self.threshold_value)
        n_samples = y_true_arr.shape[0]
        w = normalize_weight_shape(
            None if w is None else np.asarray(w), n_samples, n_tasks)

        computed_metrics = []
        for task in range(n_tasks):
            y_task = y_true_arr[:, task]
            y_pred_arr_task = y_pred_arr[:, task]
            w_task = w[:, task]

            metric_value = self.compute_singletask_metric(
                y_task, y_pred_arr_task, w_task, use_weights, **kwargs)
            computed_metrics.append(metric_value)
        if n_tasks == 1:
            computed_metrics = computed_metrics[0]

        if not per_task_metrics:
            return self.task_averager(computed_metrics)
        else:
            return self.task_averager(computed_metrics), computed_metrics

    def compute_singletask_metric(self, y_true: np.typing.ArrayLike, y_pred: np.typing.ArrayLike,
                                  w: Optional[np.typing.ArrayLike] = None, use_weights: bool = False, **kwargs) -> float:
        """Compute a metric value.

        Parameters
        ----------
        y_true: ArrayLike
            True values array. This array must be of shape `(N,
            n_classes)` if classification and `(N,)` if regression.
        y_pred: ArrayLike
            Predictions array. This array must be of shape `(N, n_classes)`
            if classification and `(N,)` if regression.
        w: ArrayLike, default None
            Sample weight array. This array must be of shape `(N,)`.
        use_weights: bool, default False
            If True, use the sample weights.
        kwargs: dict
            Will be passed on to self.metric

        Returns
        -------
        metric_value: float
            The computed value of the metric.
        """
        # Attempt to convert both into the same type
        y_true_arr = np.asarray(y_true)
        y_pred_arr = np.asarray(y_pred)
        if self.mode == "regression":
            if len(y_true_arr.shape) != 1 or len(y_pred_arr.shape) != 1 or y_true_arr.shape != y_pred_arr.shape:
                raise ValueError(
                    "For regression metrics, y_true and y_pred must both be of shape (N,)")
        elif self.mode == "classification":
            pass
            # if len(y_true.shape) != 2 or len(y_pred.shape) != 2 or y_true.shape != y_pred.shape:
            # raise ValueError("For classification metrics, y_true and y_pred must both be of shape (N, n_classes)")
        else:
            raise ValueError(
                "Only classification and regression are supported for metrics calculations."
            )

        # w will be a np.ones array if w is None
        if use_weights and 'sample_weight' not in inspect.signature(self.metric).parameters:
            raise ValueError("Cannot use sample weights with this metric.")
        else:
            try:
                metric_value = self.metric(
                    y_true_arr, y_pred_arr, sample_weight=w, **kwargs)
            except Exception as e:
                raise ValueError(
                    f"Error calculating metric: {self.metric.__name__} with error: {e}"
                )

        return metric_value
