from typing import Callable, Union, Any

from omnia.generics.parameter.space import Space, Categorical, Real, Int
from omnia.generics.utils.constants import PROBLEM_TYPES


class Parameter:
    """
    Class that represents a parameter of an estimator or model.
    Parameter instances are Python descriptors that can be used to retrieve/assign values to parameters.

    The descriptor protocol requires the implementation of the following methods:
        __get__(self, instance, owner)
        __set__(self, instance, value)
        __delete__(self, instance)
    Descriptors that only implement __get__ are called non-data descriptors (read-only).
    For more details, see: https://docs.python.org/3/howto/descriptor.html

    Parameter uses the autogluon.core.space.Space class to represent the parameter space.
    For more details, https://auto.gluon.ai/stable/tutorials/tabular_prediction/tabular-custom-model.html#hyperparameter-tuning-a-custom-model-with-tabularpredictor

    Finally, a Parameter descriptor can be used to serialize and deserialize a parameter.

    Parameters
    ----------
    default : Any
            The default value of the parameter.
    tunable : bool, optional (default=False)
        Whether the parameter can be tuned.
    space : Space, Categorical, Real, Int, Bool
            The space of the parameter. This space must represent a basic search space describing set
            of possible candidate values for this hyperparameter.
    serializer : Callable
        A function that can be used to serialize the parameter value.
    deserializer : Callable
        A function that can be used to deserialize the parameter value.
    description : str
        A description of the parameter.
    """

    def __init__(self,
                 default: Any,
                 tunable: bool = False,
                 space: Union[Space, Categorical, Real, Int] = None,
                 alias: str = None,
                 serializer: Callable = None,
                 deserializer: Callable = None,
                 description: str = None,
                 **kwargs):
        """
        Initializes a parameter descriptor at the class level.

        Parameters
        ----------
        default : Any
            The default value of the parameter.
        tunable : bool, optional (default=False)
            Whether the parameter can be tuned.
        space : Space, Categorical, Real, Int
            The space of the parameter. This space must represent a basic search space describing set
            of possible candidate values for this hyperparameter.
        alias : str, optional (default=None)
            An alias for the parameter to be used in the hyperparameter search space routines and model initialization.
        serializer : Callable
            A function that can be used to serialize the parameter value.
        deserializer : Callable
            A function that can be used to deserialize the parameter value.
        description : str
            A description of the parameter.
        """
        if tunable and space is None:
            raise ValueError('Parameter must have a valid space to be tunable.')

        if tunable and space.default != default:
            raise ValueError('Parameter default value must match the space default value.')

        self.default = default
        self.tunable = tunable
        self.space = space
        self.alias = alias
        self.serializer = serializer
        self.deserializer = deserializer
        self.description = description
        self.problem_based_parameters = {}
        self.problem_based_spaces = {}

        self._set_problem_based_parameters_and_spaces(kwargs)

    def _set_problem_based_parameters_and_spaces(self, kwargs):
        """
        Validates and sets the problem based parameters.

        Parameters
        ----------
        kwargs : dict
            The problem based parameters.

        Raises
        ------
        ValueError
            If the problem based parameters are not valid.
        """
        for key, value in kwargs.items():
            problem_type, space_or_default = key.split('__')

            if space_or_default not in ['space', 'default']:
                raise ValueError(f'Invalid problem based parameter: {key}')

            if problem_type not in PROBLEM_TYPES:
                raise ValueError(f'Invalid problem type: {problem_type}')

            if space_or_default == 'space':
                self.problem_based_spaces[problem_type] = value

            elif space_or_default == 'default':
                self.problem_based_parameters[problem_type] = value

            else:
                raise ValueError(f'Invalid problem based parameter: {key}')

    def parameter_name(self) -> str:
        """
        Returns the name of the parameter.

        Returns
        -------
        str
            The name of the parameter.
        """
        if self.alias is None:
            return self.name
        return self.alias

    def get_default(self, problem_type: str = None) -> Any:
        """
        Returns the default value of the parameter based on the problem type (if provided).

        Parameters
        ----------
        problem_type : str, optional (default=None)
            The problem type.

        Returns
        -------
        Any
            The default value of the parameter.
        """
        if problem_type is None:

            return self.default

        return self.problem_based_parameters.get(problem_type, self.default)

    def get_default_space(self, problem_type: str = None) -> Space:
        """
        Returns the default space of the parameter based on the problem type (if provided).

        Parameters
        ----------
        problem_type : str, optional (default=None)
            The problem type.

        Returns
        -------
        Space
            The default space of the parameter.
        """
        if problem_type is None:

            return self.space

        return self.problem_based_spaces.get(problem_type, self.space)

    # TODO: this can be used to avoid overriding some internal attributes in the AutoGluon models.
    #  So far, it has not been used for that purpose. Thus, I have changed the name of the parameter on purpose.
    def __set_name__(self, owner, name):
        """
        Sets the name of the parameter.

        Parameters
        ----------
        owner : Any
            The class that owns the parameter.
        name : str
            The name of the parameter.
        """
        if name == 'name':
            raise AttributeError('Parameter name cannot be "name".')

        self.name = name

    def __get__(self, instance, owner) -> Any:
        """
        Retrieves the value of the parameter.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        owner : Any
            The class that owns the parameter.

        Returns
        -------
        Any
            The value of the parameter.

        """
        if instance is None:
            return self

        return instance.__dict__[self.name]

    def __set__(self, instance, value):
        """
        Sets the value of the parameter.
        It sends a refit event to the instance.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        value : Any
            The value to assign to the parameter.
        """

        # ensures that the estimator is to be fitted with the correct type of parameter
        if hasattr(instance, '_fitted'):
            instance._fitted = False

        instance.__dict__[self.name] = value

    def __delete__(self, instance):
        """
        Deletes the value of the parameter.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        """
        del instance.__dict__[self.name]

    def serialize(self, instance) -> Any:
        """
        Serializes the parameter value after retrieving it from the instance.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.

        Returns
        -------
        Any
            The serialized parameter.
        """
        value = self.__get__(instance, None)
        if self.serializer is None:
            return value

        return self.serializer(value)

    def deserialize(self, instance, value) -> Any:
        """
        Deserializes the parameter and sets it.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        value : Any
            The serialized parameter.

        Returns
        -------
        Any
            The deserialized parameter.
        """
        if self.deserializer is not None:
            value = self.deserializer(value)

        return self.__set__(instance, value)


class ModelParameter(Parameter):
    """
    A parameter descriptor for a model.
    As models follow a different class architecture than other components,
    the parameter descriptor must be different too.
    For instance, model parameters are not available at the instance dictionary.
    """
    def __init__(self,
                 default: Any,
                 tunable: bool = False,
                 space: Union[Space, Categorical, Real, Int] = None,
                 alias: str = None,
                 serializer: Callable = None,
                 deserializer: Callable = None,
                 description: str = None,
                 **kwargs):
        """
        Initializes a parameter descriptor at the class level.

        Parameters
        ----------
        default : Any
            The default value of the parameter.
        tunable : bool, optional (default=False)
            Whether the parameter can be tuned.
        space : Space, Categorical, Real, Int
            The space of the parameter. This space must represent a basic search space describing set
            of possible candidate values for this hyperparameter.
        alias : str, optional (default=None)
            An alias for the parameter to be used in the hyperparameter search space routines and model initialization.
        serializer : Callable
            A function that can be used to serialize the parameter value.
        deserializer : Callable
            A function that can be used to deserialize the parameter value.
        description : str
            A description of the parameter.
        """
        super().__init__(default, tunable, space, alias, serializer, deserializer, description, **kwargs)

    def __get__(self, instance, owner) -> Any:
        """
        Retrieves the value of the parameter.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        owner : Any
            The class that owns the parameter.

        Returns
        -------
        Any
            The value of the parameter.

        """
        if instance is None:
            return self

        if self.name in instance.__dict__:
            return instance.__dict__[self.name]

        if '_init_parameters' in instance.__dict__:
            if self.name in instance.__dict__['_init_parameters']:
                return instance.__dict__['_init_parameters'][self.name]

        return self.default

    def __set__(self, instance, value):
        """
        It raises an error because model parameters cannot be set.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        value : Any
            The value to assign to the parameter.
        """
        raise AttributeError('Model parameters cannot be set.')
