from typing import Callable, Any


class EstimatedParameter:
    """
    Class that represents an estimated parameter of an estimator or model.
    Estimated parameter instances are Python descriptors that can be used to retrieve/assign values to estimated
    parameters.

    The descriptor protocol requires the implementation of the following methods:
        __get__(self, instance, owner)
        __set__(self, instance, value)
        __delete__(self, instance)
    Descriptors that only implement __get__ are called non-data descriptors (read-only).
    For more details, see: https://docs.python.org/3/howto/descriptor.html

    Finally, a Parameter descriptor can be used to serialize and deserialize a parameter.

    Parameters
    ----------
    serializer : Callable
        A function that can be used to serialize the parameter value.
    deserializer : Callable
        A function that can be used to deserialize the parameter value.
    description : str
        A description of the parameter.

    Attributes
    ----------
    name: str
        Name of the parameter.
    serializer : Callable
        A function that can be used to serialize the parameter value.
    deserializer : Callable
        A function that can be used to deserialize the parameter value.
    description: str
        Description of the parameter.
    """

    def __init__(self,
                 serializer: Callable = None,
                 deserializer: Callable = None,
                 description: str = None):
        """
        Initializes a parameter descriptor at the class level.

        Parameters
        ----------
        serializer : Callable
            A function that can be used to serialize the parameter value.
        deserializer : Callable
            A function that can be used to deserialize the parameter value.
        description : str
            A description of the parameter.
        """
        self.serializer = serializer
        self.deserializer = deserializer
        self.description = description

    def __set_name__(self, owner, name):
        """
        Sets the name of the parameter.

        Parameters
        ----------
        owner : Any
            The class that owns the parameter.
        name : str
            The name of the parameter.
        """
        if name == 'name':
            raise AttributeError('EstimatedParameter name cannot be "name".')

        self.name = name

    def __get__(self, instance, owner) -> Any:
        """
        Retrieves the value of the parameter.
        But it checks if the fit method has been called on the instance.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        owner : Any
            The class that owns the parameter.

        Returns
        -------
        Any
            The value of the parameter.

        """
        if instance is None:
            return self

        if not hasattr(instance, 'fitted'):
            raise AttributeError('This parameter is not bound to an estimator.')

        if not instance.fitted:
            raise AttributeError('The fit method has not been called for this estimator.')

        return instance.__dict__[self.name]

    def __set__(self, instance, value):
        """
        Sets the value of the parameter.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        value : Any
            The value to assign to the parameter.
        """

        instance.__dict__[self.name] = value

    def __delete__(self, instance):
        """
        Deletes the value of the parameter.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        """
        del instance.__dict__[self.name]

    def serialize(self, instance) -> Any:
        """
        Serializes the parameter value after retrieving it from the instance.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.

        Returns
        -------
        Any
            The serialized parameter.
        """
        value = self.__get__(instance, None)
        if self.serializer is None:
            return value

        return self.serializer(value)

    def deserialize(self, instance, value) -> Any:
        """
        Deserializes the parameter and sets it.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the parameter.
        value : Any
            The serialized parameter.

        Returns
        -------
        Any
            The deserialized parameter.
        """
        if self.deserializer is not None:
            value = self.deserializer(value)

        return self.__set__(instance, value)
