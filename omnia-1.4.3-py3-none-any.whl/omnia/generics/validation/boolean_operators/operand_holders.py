"""
The OperationHolderMixin, OperandHolder, and SingleOperandHolder classes are used to create the boolean operators.
These classes have been heavily inspired by the Django REST framework.
All credits go to the Django REST framework team.
More details available at: https://www.django-rest-framework.org/ & https://github.com/encode/django-rest-framework
"""
from copy import deepcopy
from typing import Any, Union, List, TYPE_CHECKING

from omnia.generics.validation.boolean_operators.boolean_operators import NOT, OR, AND


try:
    from pyeda.boolalg.expr import expr

except ImportError:
    expr = None


if TYPE_CHECKING:
    from .base_validator import BaseValidator


class OperationHolderMixin:
    """
    This class is used to create a mixin for the boolean operators.
    """

    def __and__(self, other: Union['BaseValidator', 'OperandHolder']) -> 'OperationHolderMixin':
        """
        This method is used to create the AND operator.

        Parameters
        ----------
        other: BaseValidator
            The other operand.

        Returns
        -------
        OperandHolder
            The resultant operand holder.
        """

        return OperandHolder(AND, self, other)

    def __or__(self, other: Union['BaseValidator', 'OperandHolder']) -> 'OperationHolderMixin':
        """
        This method is used to create the OR operator.

        Parameters
        ----------
        other: BaseValidator
            The other operand.

        Returns
        -------
        OperandHolder
            The resultant operand holder.
        """
        return OperandHolder(OR, self, other)

    def __rand__(self, other: Union['BaseValidator', 'OperandHolder']) -> 'OperationHolderMixin':
        """
        This method is used to create the AND operator.

        Parameters
        ----------
        other: BaseValidator
            The other operand.

        Returns
        -------
        OperandHolder
            The resultant operand holder.
        """
        return OperandHolder(AND, other, self)

    def __ror__(self, other: Union['BaseValidator', 'OperandHolder']) -> 'OperandHolder':
        """
        This method is used to create the OR operator.

        Parameters
        ----------
        other: BaseValidator
            The other operand.

        Returns
        -------
        OperandHolder
            The resultant operand holder.
        """
        return OperandHolder(OR, other, self)

    def __invert__(self) -> 'SingleOperandHolder':
        """
        This method is used to create the NOT operator.

        Returns
        -------
        SingleOperandHolder
            The resultant operand holder.
        """
        return SingleOperandHolder(NOT, self)

    def is_compatible(self: Union['OperandHolder', 'SingleOperandHolder'],
                      other: Union['OperandHolder', 'SingleOperandHolder']) -> bool:
        """
        This method is used to check if the two operands are compatible.

        Parameters
        ----------
        other: Union['OperandHolder', 'SingleOperandHolder']
            The other operand.

        Returns
        -------
        bool
            The result of the compatibility check.
        """
        # TODO: fix pyeada dependency
        if expr is None:
            return True

        if isinstance(self, OperandHolder):
            self_boolean_expression = expr(str(self))
        else:
            class_copy = deepcopy(self)
            self_boolean_expression = expr(str(class_copy()))
        if isinstance(other, OperandHolder):
            other_boolean_expression = expr(str(other))
        else:
            class_copy = deepcopy(other)
            other_boolean_expression = expr(str(class_copy()))

        if self_boolean_expression.equivalent(other_boolean_expression):
            return True

        else:
            all_solutions_other = list(other_boolean_expression.satisfy_all())
            all_solutions_self = list(self_boolean_expression.satisfy_all())

            for solutions_self in all_solutions_self:
                true_elements_self = [key for key, value in solutions_self.items() if value == 1]
                for solution_other in all_solutions_other:
                    true_elements_other = [key for key, value in solution_other.items() if value == 1]
                    if sorted(true_elements_self) == sorted(true_elements_other):
                        return True

        return False


class SingleOperandHolder(OperationHolderMixin):
    """
    This class is used to create a single operand holder.
    """

    def __init__(self, operator_class: Any,
                 op1_class: Union['BaseValidator', 'OperationHolderMixin', 'OperandHolder', 'SingleOperandHolder']):
        """
        This method is used to initialize the class SingleOperandHolder.

        Parameters
        ----------
        operator_class: Any
            Example: NOT
        op1_class: 'BaseValidator' | 'OperationHolderMixin'
            The operand holder.
        """
        self.operator_class = operator_class
        self.op1_class = op1_class()

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        This method is used to validate the operands.

        Parameters
        ----------
        x: Any
            The x of the data.
        y: Any
            The y of the data.

        Returns
        -------
        bool
            The result of the validation.
        """
        op1 = self.op1_class.validate(x, y)
        return self.operator_class(op1).operate()

    def __call__(self, *args, **kwargs) -> Union['BaseValidator', 'OperationHolderMixin']:
        return self

    def __str__(self):
        return f"{self.operator_class.string_repr()} ({str(self.op1_class)})"


class OperandHolder(OperationHolderMixin):
    """
    This class is used to create an operand holder.
    """

    def __init__(self,
                 operator_class: Any,
                 op1_class: Union['BaseValidator', 'OperationHolderMixin', 'OperandHolder', 'SingleOperandHolder'],
                 op2_class: Union['BaseValidator', 'OperationHolderMixin', 'OperandHolder', 'SingleOperandHolder']):
        """
        This method is used to initialize the class OperandHolder.

        Parameters
        ----------
        operator_class: Any
            Example: AND
        op1_class: OperandHolder | BaseValidator
            The first operand holder.
        op2_class:  OperandHolder | BaseValidator
            The second operand holder.
        """
        self.operator_class = operator_class
        self.op1_class = op1_class()
        self.op2_class = op2_class()

    @staticmethod
    def _get_operand_classes(operand: Union['BaseValidator', 'OperationHolderMixin', 'OperandHolder']) -> List[Any]:
        """
        Get operand classes given one operand

        Parameters
        ----------
        operand: OperandHolder
            operand
        Returns
        -------
        list
            List of operand classes.
        """
        operand_classes = []
        if isinstance(operand, OperandHolder):
            operand_classes.extend(operand.get_all_operand_classes())
        else:
            operand_classes.append(operand.__class__)
        return operand_classes

    def get_all_operand_classes(self) -> List[Any]:
        """
        Get all operand classes in a given expression

        Returns
        -------
        list
            List of operand classes.
        """
        operand_classes = []
        operand_classes.extend(self._get_operand_classes(self.op1_class))
        operand_classes.extend(self._get_operand_classes(self.op2_class))
        return operand_classes

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        This method is used to validate the operands.

        Parameters
        ----------
        x: Any
            The x of the data.
        y: Any
            The y of the data.

        Returns
        -------
        bool
            The result of the validation.
        """
        op1 = self.op1_class.validate(x, y)
        op2 = self.op2_class.validate(x, y)
        return self.operator_class(op1, op2).operate()

    def __call__(self, *args, **kwargs) -> Union['BaseValidator', 'OperationHolderMixin']:
        return self

    def __str__(self):
        return f"({str(self.op1_class)}) {self.operator_class.string_repr()} ({str(self.op2_class)})"
