from typing import Any

from omnia.generics.validation.boolean_operators.operand_holders import OperationHolderMixin


class BaseValidatorMetaclass(OperationHolderMixin, type):
    pass


class BaseValidator(metaclass=BaseValidatorMetaclass):
    """
    A base class from which all validator classes should inherit.
    """

    def __str__(self):
        return self.__class__.__name__

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        This method is used to validate the data.

        Parameters
        ----------
        x: Any
            The x of the data.
        y: Any
            The y of the data.

        Returns
        -------
        bool
            The result of the validation.
        """
