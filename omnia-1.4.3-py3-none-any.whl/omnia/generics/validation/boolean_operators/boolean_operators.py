"""
The AND, OR, and NOT classes are used to create the boolean operators.
These classes have been heavily inspired by the Django REST framework.
All credits go to the Django REST framework team.
More details available at: https://www.django-rest-framework.org/ & https://github.com/encode/django-rest-framework
"""


class AND:
    def __init__(self, op1, op2):
        self.op1 = op1
        self.op2 = op2

    def operate(self):
        return (
                self.op1 and
                self.op2
        )

    def __str__(self):
        return "&"

    @staticmethod
    def string_repr():
        return "&"


class OR:
    def __init__(self, op1, op2):
        self.op1 = op1
        self.op2 = op2

    def operate(self):
        return (
                self.op1 or
                self.op2
        )

    def __str__(self):
        return "|"

    @staticmethod
    def string_repr():
        return "|"


class NOT:
    def __init__(self, op1):
        self.op1 = op1

    def operate(self):
        return not self.op1

    def __str__(self):
        return "~"

    @staticmethod
    def string_repr():
        return "~"
