from aenum import Enum, NoAlias
from typing import Type, Any

from omnia.generics.dataframe import pd
from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasDataFrameBinaryY(Component):
    def run(self, x: Any = None, y: Any = None, not_consider_y: bool = False, **kwargs) -> bool:
        """
        Validate the data. Checks if y is not None and if it is not empty.

        Parameters
        ----------
        x: pd.DataFrame
            The data used to fit the model.
        y: pd.DataFrame
            The target used to fit the model.
        not_consider_y: bool
            If True, the y is not considered in the validation.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_y:
            return True

        elif y is None:
            raise ValueError("y cannot be None")

        elif isinstance(y, pd.Series):
            return ((y.isna()) | (y == 0) | (y == 1)).all()
        else:
            return ((y.isna()) | (y == 0) | (y == 1)).all().all()


class NumpyArrayBinaryY(Component):
    def run(self, x: Any = None, y: Any = None, not_consider_y: bool = False, **kwargs) -> bool:
        """
        Validate the data. Checks if y is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_y: bool
            If True, the y is not considered in the validation.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_y:
            return True

        elif y is None:
            raise ValueError("y cannot be None")
        else:
            return ((y == 0) | (y == 1)).all()


class BinaryY(Tag):
    """
    Tag to check if the data have only binary values.
    """

    class BinaryYEnum(Enum):
        """
        Enum to represent the tag.
        """
        _settings_ = NoAlias
        PANDAS = PandasDataFrameBinaryY
        NUMPY = NumpyArrayBinaryY
        ANY = PandasDataFrameBinaryY

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Return the enumerator.

        Returns
        -------
        Type[Enum]
            The enumerator.
        """
        return self.BinaryYEnum
