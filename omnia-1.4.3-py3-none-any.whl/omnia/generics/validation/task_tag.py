from enum import Enum


class TaskTag(Enum):
    BINARY = "binary"
    MULTICLASS = "multiclass"
    MULTILABEL = "multilabel"
    REGRESSION = "regression"
    MULTITASK_BINARY = "multitask_binary"
    MULTITASK_MULTICLASS = "multitask_multiclass"
    MULTITASK_MULTILABEL = "multitask_multilabel"
    MULTITASK_REGRESSION = "multitask_regression"
    UNDEFINED = None

    @classmethod
    def from_string(cls, tag_string):
        try:
            return cls[tag_string.upper()]
        except KeyError:
            raise ValueError(f"Invalid task tag: {tag_string}. Must be one of {', '.join(cls.__members__)}.")
