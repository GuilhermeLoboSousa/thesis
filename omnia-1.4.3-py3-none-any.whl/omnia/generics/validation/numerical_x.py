from aenum import Enum, NoAlias
from typing import Type

from omnia.generics.dataframe import pd
from omnia.generics.array import np
from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasDataframeNumericalX(Component):

    def run(self, x: pd.DataFrame = None, y: pd.DataFrame = None, not_consider_x: bool = False, **kwargs) -> bool:
        """
        Check whether the x has only numerical values.

        Parameters
        ----------
        x: pd.DataFrame
            The data used to fit the model.
        y: pd.DataFrame
            The target used to fit the model.
        not_consider_x: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        if not_consider_x:
            return True

        elif x is None:
            raise ValueError('x must be provided.')

        if isinstance(x, pd.DataFrame):
            return x.shape[1] == x.select_dtypes(include=np.number).shape[1]
        else:
            raise ValueError('x must be a pandas dataframe.')


class NumpyArrayNumericalX(Component):
    def run(self, x: np.ndarray = None, y: np.ndarray = None,
            not_consider_x: bool = False, **kwargs) -> bool:
        """
        Check whether the x has only numerical values.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_x: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        if not_consider_x:
            return True

        elif x is None:
            ValueError('x must be provided.')

        return np.issubdtype(x.dtype, np.number)


class NumericalX(Tag):
    """
    Tag to check if the data have only numerical values.
    """

    class NumericalXEnumerators(Enum):
        """
        Returns NotAllowNaNEnumerators.
        """
        _settings_ = NoAlias
        PANDAS = PandasDataframeNumericalX
        NUMPY = NumpyArrayNumericalX
        ANY = PandasDataframeNumericalX

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator for NumericalX tag.

        Returns
        -------
        Type['Enum']
            NumericalXEnumerators
        """
        return self.NumericalXEnumerators
