from typing import Callable, Any, List, Type


class TagsProperty:
    """
    Class that represents the list of tags for an estimator or model.
    This is a regular default getter for the tags' property.

    This property will return the tags of the model that will be used to validate the input data for the model.
    This property should be implemented by the child class.
    One should look up the tags in the omnia-generics documentation:
        - https://github.com/omniumai/omnia-generics
        - https://github.com/omniumai/omnia-generics/tree/main/src/omnia/generics/validation/__init__.py

    The descriptor protocol requires the implementation of the following methods:
        __get__(self, instance, owner)
        __set__(self, instance, value)
        __delete__(self, instance)
    Descriptors that only implement __get__ are called non-data descriptors (read-only).
    This is the case of tags' property.
    For more details, see: https://docs.python.org/3/howto/descriptor.html

    Finally, a TagsProperty descriptor can be used to serialize and deserialize tags.

    Parameters
    ----------
    serializer : Callable
        A function that can be used to serialize the parameter value.
    deserializer : Callable
        A function that can be used to deserialize the parameter value.

    Attributes
    ----------
    serializer : Callable
        A function that can be used to serialize the parameter value.
    deserializer : Callable
        A function that can be used to deserialize the parameter value.
    """

    def __init__(self,
                 tags: List[Type] = None,
                 serializer: Callable = None,
                 deserializer: Callable = None):
        """
        Initializes a tags' property at the class level.

        Parameters
        ----------
        tags : List[Type]
            The list of tags.
        serializer : Callable
            A function that can be used to serialize the parameter value.
        deserializer : Callable
            A function that can be used to deserialize the parameter value.

        """
        if not tags:
            tags = []

        self.tags = tags
        self.serializer = serializer
        self.deserializer = deserializer

    def __set_name__(self, owner, name):
        """
        Sets the name of the property as tags.

        Parameters
        ----------
        owner : Any
            The class that owns the parameter.
        name : str
            The name of the parameter.
        """
        self.name = name

    def __get__(self, instance, owner) -> Any:
        """
        Retrieves the value of the tags' property.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the tags.
        owner : Any
            The class that owns the tags.

        Returns
        -------
        Any
            The value of the tags.

        """
        if instance is None:
            return self

        if self.name not in instance.__dict__:
            instance.__dict__[self.name] = self.tags.copy()

        return instance.__dict__[self.name]

    def serialize(self, instance) -> Any:
        """
        Serializes the tags' property value after retrieving it from the instance.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the tags' property.

        Returns
        -------
        Any
            The serialized tags' property.
        """
        value = self.__get__(instance, None)
        if self.serializer is None:
            return value

        return self.serializer(value)

    def deserialize(self, instance, value) -> Any:
        """
        Deserializes the tags' property and sets it.

        Parameters
        ----------
        instance : Any
            The instance of the class that owns the tags' property.
        value : Any
            The serialized tags' property.

        Returns
        -------
        Any
            The deserialized tags' property.
        """
        if self.deserializer is not None:
            value = self.deserializer(value)

        instance.__dict__[self.name] = value
