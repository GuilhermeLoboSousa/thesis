from aenum import Enum, NoAlias

import numpy as np
from typing import Any, Type

from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasDataframeNotAllowNaN(Component):
    """
    Concrete Decorators call the wrapped object and alter its result in some
    way.
    """

    def run(self, x: Any = None, y: Any = None, **kwargs) -> bool:
        """
        Parameters
        ----------
        x : Any
            The x.
        y : Any
            The labels.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if x is None:
            return not y.isnull().values.any()
        if y is None:
            return not x.isnull().values.any()
        else:
            return all([not y.isnull().values.any(), not x.isnull().values.any()])


class NumpyArrayNotAllowNaN(Component):
    """
    Concrete Decorators call the wrapped object and alter its result in some
    way.
    """

    def run(self, x: np.ndarray = None, y: np.ndarray = None, **kwargs) -> bool:
        """
        Validate the data.

        Parameters
        ----------
        x : Any
            The x.
        y : Any
            The labels.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if x is None:
            return not np.isnan(y).any()
        if y is None:
            return not np.isnan(x).any()
        else:
            return all([not np.isnan(y).any(), not np.isnan(x).any()])


class NotAllowNaN(Tag):
    """
    Concrete Decorators call the wrapped object and alter its result in some
    way.
    """

    class NotAllowNaNEnumerators(Enum):
        """
        Returns NotAllowNaNEnumerators.
        """
        _settings_ = NoAlias
        PANDAS = PandasDataframeNotAllowNaN
        NUMPY = NumpyArrayNotAllowNaN

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Get the enumerator.
        """
        return self.NotAllowNaNEnumerators
