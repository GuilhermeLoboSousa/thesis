from enum import Enum


class DataTag(Enum):
    TEXT = "text"
    TABULAR = "tabular"
    MATRIX = "matrix"
    UNDEFINED = None
