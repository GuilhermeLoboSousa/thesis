from abc import abstractmethod
from typing import Any, Type
from enum import Enum

from omnia.generics.validation.commons._generic_enumerators import identify_datatype
from omnia.generics.validation.commons.decorator_component import TagsDecorator


class Tag(TagsDecorator):
    """
    Abstract class for tags.
    A Tag performs data validation.
    It is used to validate data before it is passed to an estimator, transformer, or model.
    All tags must implement the validate method and inherit from this class.
    """

    @property
    @abstractmethod
    def enumerator(self) -> Type['Enum']:
        """
        Abstract method to get the enumerator of the tag.
        All tags implement this method.
        The enumerator is used to serialize and deserialize the tag.

        Returns
        -------
        int
            The enumerator of the tag.
        """

    def validate(self, x: Any = None, y: Any = None) -> bool:
        """
        Abstract method to validate data before it is passed to an estimator, transformer, or model.
        All tags implement this method.
        The validation method must perform fast and straightforward checks to the data.
        It should return a boolean value indicating whether the data is valid or not.

        Parameters
        ----------
        x : Any, optional
            The data used to fit the model.
        y : Any, optional
            The target used to fit the model.

        Returns
        -------
        bool
            True if the value is valid, False otherwise.
        """
        x_component = identify_datatype(x).get_component(self.enumerator)
        y_component = identify_datatype(y).get_component(self.enumerator)

        if x_component is None and y_component is None:
            raise ValueError("The tag cannot be applied to the data.")

        self._x_y_tags = (x_component, y_component)

        return self.run(x, y)
