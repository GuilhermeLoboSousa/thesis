from aenum import Enum
from typing import Type, Any

from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasAndNumpyIsX2D(Component):

    def run(self, x: Any = None, y: Any = None, not_consider_x=False, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_x: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_x:
            return True
        elif x is None:
            raise ValueError("x cannot be None")
        else:
            return x.ndim == 2


class IsX2D(Tag):
    class IsX2DEnumerator(Enum):
        NUMPY = PandasAndNumpyIsX2D
        PANDAS = PandasAndNumpyIsX2D
        ANY = PandasAndNumpyIsX2D

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.IsX2DEnumerator


class PandasAndNumpyIsY2D(Component):

    def run(self, x: Any = None, y: Any = None, not_consider_y=False, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_y: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_y:
            return True
        elif y is None:
            raise ValueError("y cannot be None")
        else:
            return y.ndim == 2


class IsY2D(Tag):
    class IsY2DEnumerator(Enum):
        NUMPY = PandasAndNumpyIsY2D
        PANDAS = PandasAndNumpyIsY2D

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.IsY2DEnumerator
