import numpy as np
from aenum import Enum
from typing import Type, Any

from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class NumpyArrayIsX3D(Component):
    def run(self, x: Any = None, y: Any = None, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if x is None:
            raise ValueError("x cannot be None")
        else:
            return x.ndim == 3


class IsX3D(Tag):
    class IsX3DEnumerator(Enum):
        NUMPY = NumpyArrayIsX3D

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.IsX3DEnumerator
