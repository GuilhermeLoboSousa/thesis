from aenum import Enum
from typing import Type, Any

from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasAndNumpyIsX1D(Component):
    def run(self, x: Any = None, y: Any = None, not_consider_x=False, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_x: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_x:
            return True
        elif x is None:
            raise ValueError("x cannot be None")
        else:
            if x.ndim == 1:
                return True
            elif x.ndim == 2:  # for cases where x is a pandas dataframe and the shape is (<any value>, 1)
                return x.shape[1] == 1


class IsX1D(Tag):
    class IsX1DEnumerator(Enum):
        NUMPY = PandasAndNumpyIsX1D
        PANDAS = PandasAndNumpyIsX1D
        ANY = PandasAndNumpyIsX1D

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.IsX1DEnumerator


class PandasAndNumpyIsY1D(Component):

    def run(self, x: Any = None, y: Any = None, not_consider_y=False, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_y: bool
            If True, the x is not considered in the validation.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """
        if not_consider_y:
            return True
        elif y is None:
            raise ValueError("y cannot be None")
        else:
            return y.ndim == 1


class IsY1D(Tag):
    class IsY1DEnumerator(Enum):
        NUMPY = PandasAndNumpyIsY1D
        PANDAS = PandasAndNumpyIsY1D
        ANY = PandasAndNumpyIsY1D

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.IsY1DEnumerator
