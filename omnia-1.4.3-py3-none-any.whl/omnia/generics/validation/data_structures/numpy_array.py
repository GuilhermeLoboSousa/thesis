from aenum import Enum
from typing import Type

import numpy as np

from omnia.generics.validation.tag import Tag


class IsNumpyArrayX(Tag):

    def __init__(self):
        """
        Tags that are concrete components have to be initialized.

        The enumerator has to be initialized here as in below.
        The code below is equivalent to:
            class IsNumpyArrayEnumerator(Enum):
                NUMPY = IsNumpyArrayX

        The difference is that the enumerator is initialized here to access the self.__class__.
        """
        self._enumerator: Type['Enum'] = Enum('IsNumpyArrayXEnumerator', {'ANY': self.__class__})

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self._enumerator

    def run(self, x: np.ndarray = None, y: np.ndarray = None, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        if x is None:
            raise ValueError("x cannot be None")
        else:
            return isinstance(x, np.ndarray)


class IsNumpyArrayY(Tag):

    def __init__(self):
        """
        Tags that are concrete components have to be initialized.

        The enumerator has to be initialized here as in below.
        The code below is equivalent to:
            class IsNumpyArrayEnumerator(Enum):
                NUMPY = IsNumpyArrayX

        The difference is that the enumerator is initialized here to access the self.__class__.
        """
        self._enumerator: Type['Enum'] = Enum('IsNumpyArrayYEnumerator', {'ANY': self.__class__})

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self._enumerator

    def run(self, x: np.ndarray = None, y: np.ndarray = None, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        kwargs: dict
            The kwargs.

        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        if y is None:
            raise ValueError("y cannot be None")
        else:
            return isinstance(y, np.ndarray)
