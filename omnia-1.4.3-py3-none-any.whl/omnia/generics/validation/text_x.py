from typing import Any, Type, Union

import numpy as np
from aenum import Enum

from omnia.generics import pd
from omnia.generics.validation.commons.decorator_component import Component
from omnia.generics.validation.tag import Tag


class PandasTextX(Component):
    def run(self, x: Union[pd.Series, pd.DataFrame] = None, y: Union[pd.Series, pd.DataFrame] = None,
            not_consider_x=False, **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: Union[pd.Series, pd.DataFrame]
            The data used to fit the model.
        y: Union[pd.Series, pd.DataFrame]
            The target used to fit the model.
        not_consider_x: bool
            If True, x is not considered.
        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        def is_str_or_nan(val: Any):
            """
            Parameters
            ----------
            val : Any
                Value to validate.
            Returns
            -------
            bool
                True if the value is a string or a NaN, False otherwise.
            """
            return isinstance(val, str) or pd.isnull(val)

        if not_consider_x:
            return True

        if x is None:
            raise ValueError('x cannot be None')

        if isinstance(x, pd.Series):
            x_type = x.apply(lambda val: is_str_or_nan(val))
        else:
            x_type = x.applymap(lambda val: is_str_or_nan(val))
        return x_type.values.all()


class NumpyArrayTextX(Component):
    def run(self, x: np.ndarray = None, y: np.ndarray = None,
            not_consider_x=False,
            **kwargs) -> bool:
        """
        Validate the data. Checks if x is not None and if it is not empty.

        Parameters
        ----------
        x: np.ndarray
            The data used to fit the model.
        y: np.ndarray
            The target used to fit the model.
        not_consider_x: bool
            If True, x is not considered.

        kwargs: dict
            The kwargs.
        Returns
        -------
        bool
            True if the data is valid, False otherwise.
        """

        def is_str_or_nan(val: Any):
            """
            Parameters
            ----------
            val : Any
                Value to validate.
            Returns
            -------
            bool
                True if the value is a string or a NaN, False otherwise.
            """
            return isinstance(val, str) or np.isnan(val)

        if x is None:
            raise ValueError("x cannot be None")
        else:
            x_type = np.vectorize(is_str_or_nan)(x)
            return x_type.all()


class TextX(Tag):
    class TextXEnumerator(Enum):
        NUMPY = NumpyArrayTextX
        PANDAS = PandasTextX

    @property
    def enumerator(self) -> Type['Enum']:
        """
        Enumerator property.

        Returns
        -------
        Type['Enum']
            The enumerator.
        """
        return self.TextXEnumerator
