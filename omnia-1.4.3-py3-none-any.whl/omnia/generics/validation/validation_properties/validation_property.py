from typing import Any, Union, Type

from omnia.generics.validation.boolean_operators.base_validator import BaseValidator
from omnia.generics.validation.boolean_operators.operand_holders import OperandHolder


class ValidationProperty:
    input_tag: Union[OperandHolder, BaseValidator, Type[Any]]
    output_tag: Union[OperandHolder, BaseValidator, Type[Any]]

    def __init__(self,
                 input_tag: Union[OperandHolder, BaseValidator, Type[Any]] = None,
                 output_tag: Union[OperandHolder, BaseValidator, Type[Any]] = None):
        """
        This method is used to initialize the class.

        Parameters
        ----------
        input_tag: Union[OperandHolder, BaseValidator]
            The input_tag
        output_tag: Union[OperandHolder, BaseValidator]
            The output_tag
        """

        self.input_tag = input_tag
        self.output_tag = output_tag

    def validate_input(self, x: Any = None, y: Any = None) -> bool:
        """
        This method is used to validate the data.

        Parameters
        ----------
        x: Any
            The x of the data.
        y: Any
            The y of the data.

        Returns
        -------
        bool
            The result of the validation.
        """
        if self.input_tag:
            return self.input_tag().validate(x, y)
        else:
            return True

    def validate_output(self, x: Any = None, y: Any = None) -> bool:
        """
        This method is used to validate the data.

        Parameters
        ----------
        x: Any
            The x of the data.
        y: Any
            The y of the data.

        Returns
        -------
        bool
            The result of the validation.
        """
        if self.output_tag:
            return self.output_tag().validate(x, y)
        else:
            return True

    def input_is_equivalent(self, previous_output: Union[OperandHolder, BaseValidator]) -> bool:
        """
        This method is used to validate the previous output.

        Parameters
        ----------
        previous_output: Union[OperandHolder, BaseValidator]
            The previous output.

        Returns
        -------
        bool
            The result of the validation.
        """
        return self.input_tag.is_compatible(previous_output)
