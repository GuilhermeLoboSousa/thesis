from abc import abstractmethod

from typing import Any, Tuple, Optional

from omnia.generics.validation.boolean_operators.base_validator import BaseValidator


class Component(BaseValidator):
    """
    The base Component interface defines operations that can be altered by
    decorators.
    """

    @abstractmethod
    def run(self, x: Any = None, y: Any = None, not_consider_x: bool = False, not_consider_y: bool = False) -> bool:
        """
        Validate the data.
        """


class TagsDecorator(Component):
    _x_y_tags: Tuple[Optional[Component], Optional[Component]] = (None, None)

    @property
    def x_y_tags(self) -> Tuple[Optional[Component], Optional[Component]]:
        """
        The Decorator delegates all work to the wrapped component.
        """
        return self._x_y_tags

    def run(self, x: Any = None, y: Any = None, **kwargs) -> bool:
        """
        Validate the data.

        Parameters
        ----------
        x : Any, optional
            The data used to fit the model.
        y : Any, optional
            The target used to fit the model.
        """
        x_tag, y_tag = self.x_y_tags

        if self.x_y_tags != (None, None):

            if x_tag is None:
                # uses the y tag
                return y_tag.run(x, y)

            elif y_tag is None:
                # only uses the x tag
                return x_tag.run(x, y)

            elif x_tag.__class__ != y_tag.__class__:
                # if x and y are of different types, then the validation is done separately

                return all([x_tag.run(x, None, not_consider_y=True),
                            y_tag.run(None, y, not_consider_x=True)])

            else:
                # if x and y are of the same type, then the validation is done together
                return x_tag.run(x, y)

        else:
            # if no tags are defined, it means that the type is not supported by omnia
            return False
