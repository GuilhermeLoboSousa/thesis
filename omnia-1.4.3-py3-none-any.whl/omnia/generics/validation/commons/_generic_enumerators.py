import warnings

from aenum import Enum, NoAlias
import numpy as np
from typing import Any, Type, Union

from omnia.generics import pd

from omnia.generics.validation.commons.decorator_component import Component


class OMNIATypesEnumerators(Enum):
    """
    Generic enumerators. It is used to identify the datatype.
    """
    _settings_ = NoAlias

    PANDAS: list = [pd.DataFrame, pd.Series]
    NUMPY: Any = np.ndarray
    ANY: Any = None

    def get_component(self, enum_class: Type['Enum']) -> Union[Component, None]:
        """
        Get the decorator.
        """
        if self.name not in enum_class.__members__:

            # If the enumerator is another type of data that is not supported by the tag directly,
            # but supports ANY datatype (declared in its enumerator), the tag is returned.
            if OMNIATypesEnumerators.ANY.name in enum_class.__members__:
                return enum_class[OMNIATypesEnumerators.ANY.name].value()

            warnings.warn(f'This tag do not support {self.name}.')
            return

        enumerator = enum_class[self.name]
        if enumerator.value is None:
            return

        return enumerator.value()


def identify_datatype(x) -> 'OMNIATypesEnumerators':
    """
    Identify the datatype.
    """

    for name, signature in OMNIATypesEnumerators.__members__.items():
        if isinstance(OMNIATypesEnumerators[name].value, list):
            for item in OMNIATypesEnumerators[name].value:
                if isinstance(x, item):
                    return signature
        elif x is not None:
            if isinstance(x, OMNIATypesEnumerators[name].value):
                return signature

    return OMNIATypesEnumerators.ANY
