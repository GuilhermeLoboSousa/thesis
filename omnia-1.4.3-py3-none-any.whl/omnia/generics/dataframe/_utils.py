from typing import Union, Optional, Any

from .dataframe import pd


def series_to_dataframe(series: Union[pd.Series, pd.DataFrame, Any]) -> Optional[pd.DataFrame]:
    """
    Convert a pandas.Series to a pandas.DataFrame.
    If the input is already a pandas.DataFrame, it is returned as is.

    Parameters
    ----------
    series : pandas.Series or pandas.DataFrame
        The input series.

    Returns
    -------
    dataframe : pandas.DataFrame or None
        The output dataframe. It returns a new copy.
    """
    if series is None:
        return

    if isinstance(series, pd.DataFrame):
        return series.copy()

    if hasattr(series, "to_frame"):
        return series.to_frame()

    # ignore non series / dataframe types
    return series

