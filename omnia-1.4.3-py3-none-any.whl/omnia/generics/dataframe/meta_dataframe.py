import pandas as pd


class MetaDataFrame(pd.DataFrame):
    """
    MetaDataFrame is a subclass of pandas.DataFrame.
    It is used to store metadata in a regular dataframe.

    It uses the MultiIndex structure to store the metadata, though it does not use the MultiIndex's indexing.
    When using the standard MultiIndex structure, to access a specific column as pd.Series,
    the whole index must be specified. This breaks the regular workflow of accessing a specific column.

    In a MetaDataFrame, data indexing and accessing works as if no MultiIndex is being used. This means that one can
    perform data indexing and accessing by the name or int of the column as a regular dataframe.

    For that, the getitem method is overridden to use both the MultiIndex and SingleIndex.

    To use the MetaDataFrame, one must assign a column label named "name" which will be our regular SingleIndex.

    Credits:
     - https://notes.mikejarrett.ca/storing-metadata-in-pandas-dataframes/
     - Diogo Macedo by letting me know how to use the MultiIndex structure in this way.

    Examples
    --------
    >>> from omnia.generics.array import np
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame({('A', 1, 'description A'): [1, 2, 3], ('B', 2, 'description B'): [4, 5, 6]})
    >>> df.columns.names=['name', 'length', 'description']
    >>> df
    name                    A             B
    length                  1             2
    description description A description B
    0                       1             4
    1                       2             5
    2                       3             6

    >>> df[('A', 1, 'description A')]
    0    1
    1    2
    2    3
    Name: (A, 1, description A), dtype: int64

    >>> df['A']
    length                  1
    description description A
    0                       1
    1                       2
    2                       3

    >>> mdf = pd.MetaDataFrame({('A', 1, 'description A'): [1, 2, 3], ('B', 2, 'description B'): [4, 5, 6]})
    >>> mdf.columns.names=['name', 'length', 'description']
    >>> mdf
    name                    A             B
    length                  1             2
    description description A description B
    0                       1             4
    1                       2             5
    2                       3             6

    >>> mdf['A']
    0    1
    1    2
    2    3
    Name: (A, 1, description A), dtype: int64

    >>> mdf[['A', 'B']]
    name                    A             B
    length                  1             2
    description description A description B
    0                       1             4
    1                       2             5
    2                       3             6

    >>> mdf[('A', 1, 'description A')]
    0    1
    1    2
    2    3
    Name: (A, 1, description A), dtype: int64
    """

    @property
    def _constructor(self):
        # Required so that our new class returns an instance of itself
        return MetaDataFrame

    def _check_is_mi(self, key) -> bool:
        """
        Check if the key is a MultiIndex.

        Parameters
        ----------
        key : str or tuple
            The key to check.

        Returns
        -------
        bool
            True if the key is a MultiIndex, False otherwise.
        """
        return 'name' in self.columns.names and isinstance(self.columns, pd.MultiIndex) and isinstance(key, str)

    def __getitem__(self, key):
        # special method called by the indexing operator
        # Check whether the current instance is using a MultiIndex,
        # there is a level called NAME, and the input key is a string (not a list)
        if self._check_is_mi(key):

            # get the whole MultiIndex key
            keys = [x for x in self.columns if x[0] == key]

            if len(keys) == 1:
                key = keys[0]

            # name-based keys must be unique
            elif len(keys) > 1:
                raise ValueError('name level column labels must be unique')

        # Now 'key' is a tuple if MultiIndex is to be used or 'key' is string.
        # Calling the parent class
        return super().__getitem__(key)

    def __unicode__(self):
        if self._check_is_mi('fake_key'):
            new_df = self.copy()
            new_df.columns = self.columns.get_level_values('name')
            return new_df.__unicode__()

        return super().__unicode__()

    def _repr_html_(self):
        if self._check_is_mi('fake_key'):
            new_df = self.copy()
            new_df.columns = self.columns.get_level_values('name')
            return new_df._repr_html_()

        return super()._repr_html_()


if __name__ == '__main__':
    import doctest

    doctest.testmod()
