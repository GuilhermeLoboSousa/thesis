def _f_cls(cls) -> str:
    return f"{cls.__module__}.{cls.__name__}"


def light() -> dict:
    """
    Returns a search space for a light preset.
    This search space contains only the ProteinStandardizer, performance descriptors (PHYSICO_CHEMICAL_DESCRIPTORS,
    AMINO_ACID_COMPOSITION_DESCRIPTORS, PSEUDO_AMINO_ACID_COMPOSITION_DESCRIPTORS, CTD_DESCRIPTORS,
    MODLAMP_CORRELATION_DESCRIPTORS) with default parameters, and some of the most relevant models.

    Returns
    -------
    search_space : dict
        search space for a light preset for pipeline optimization.
    """
    search_space = dict()
    search_space['standardizer'] = {
        '_type': 'choice',
        '_value':
            ["omnia.proteins.ProteinStandardizer",
             "omnia.generics.utils.function_transformer.PassthroughTransformer"]
    }

    search_space['featurizer'] = {
        '_type': 'choice',
        '_value': [{'_name': "omnia.proteins.ProteinDescriptor",
                    'preset': {
                        "_type": "choice",
                        '_value': ['performance']}
                    },
                   {'_name': "omnia.proteins.NLFEncoder"},
                   ]
    }

    search_space['model'] = {'_type': 'choice',
                             '_value': [['omnia.generics.RandomForestModel',
                                         'omnia.generics.MultilayerPerceptronNN',
                                         'omnia.generics.CatBoostModel',
                                         'omnia.generics.KNNModel',
                                         'omnia.generics.LGBModel',
                                         'omnia.generics.XGBoostModel',
                                         'omnia.generics.SupportVectorMachineModel']]}
    return search_space


def medium() -> dict:
    """
    Returns a search space for a medium preset.
    This search space contains some standardizers, some featurizers, the StandardScaler, and all the available models.

    Returns
    -------
    search_space : dict
        search space for a medium preset for pipeline optimization.
    """
    search_space = dict()
    search_space['standardizer'] = {'_type': 'choice',
                                    '_value': ["omnia.proteins.ProteinStandardizer",
                                               "omnia.generics.utils.function_transformer.PassthroughTransformer"]}

    search_space['featurizer'] = {'_type': 'choice',
                                  '_value': [{'_name': "omnia.proteins.ProteinDescriptor",
                                              'preset': {"_type": "choice", '_value': ['performance']}},
                                             {'_name': "omnia.proteins.NLFEncoder"},
                                             {'_name': "omnia.proteins.Esm2Encoder",
                                              'pretrained_model': {"_type": "choice", '_value': ['650M']}}
                                             ]
                                  }

    search_space['scaler'] = {'_type': 'choice',
                              '_value': ["sklearn.preprocessing.StandardScaler",
                                         "omnia.generics.utils.function_transformer.PassthroughTransformer"]}

    search_space['model'] = {'_type': 'choice',
                             '_value': [['omnia.generics.RandomForestModel',
                                         'omnia.generics.MultilayerPerceptronNN',
                                         'omnia.generics.CatBoostModel',
                                         'omnia.generics.KNNModel',
                                         'omnia.generics.LGBModel',
                                         'omnia.generics.LinearModel',
                                         'omnia.generics.FastAINN',
                                         'omnia.generics.VowpalWabbitModel',
                                         'omnia.generics.XGBoostModel',
                                         'omnia.generics.XTModel',
                                         'omnia.generics.SupportVectorMachineModel']]}
    return search_space


def heavy() -> dict:
    """
    Returns a search space for a heavy preset.
    This search space contains all the available standardizers, featurizers and standardizers.

    Returns
    -------
    search_space : dict
        search space for a heavy preset for pipeline optimization.
    """
    search_space = dict()
    search_space['standardizer'] = {'_type': 'choice',
                                    '_value': ["omnia.proteins.ProteinStandardizer",
                                               "omnia.generics.utils.function_transformer.PassthroughTransformer"]}

    search_space['featurizer'] = {'_type': 'choice',
                                  '_value': [{'_name': "omnia.proteins.ProteinDescriptor",
                                              'preset': {"_type": "choice", '_value': ['performance']}},
                                             {'_name': "omnia.proteins.NLFEncoder"},
                                             {'_name': "omnia.proteins.Esm2Encoder",
                                              'pretrained_model': {"_type": "choice", '_value': ['650M']}},
                                             {'_name': "omnia.proteins.ProtbertEncoder"}
                                             ]
                                  }

    search_space['scaler'] = {'_type': 'choice',
                              '_value': ["sklearn.preprocessing.MinMaxScaler",
                                         "sklearn.preprocessing.StandardScaler",
                                         "omnia.generics.utils.function_transformer.PassthroughTransformer"]}

    search_space['model'] = {'_type': 'choice',
                             '_value': [['omnia.generics.RandomForestModel',
                                         'omnia.generics.MultilayerPerceptronNN',
                                         'omnia.generics.CatBoostModel',
                                         'omnia.generics.KNNModel',
                                         'omnia.generics.LGBModel',
                                         'omnia.generics.LinearModel',
                                         'omnia.generics.FastAINN',
                                         'omnia.generics.VowpalWabbitModel',
                                         'omnia.generics.XGBoostModel',
                                         'omnia.generics.XTModel',
                                         'omnia.generics.SupportVectorMachineModel']]}
    return search_space
