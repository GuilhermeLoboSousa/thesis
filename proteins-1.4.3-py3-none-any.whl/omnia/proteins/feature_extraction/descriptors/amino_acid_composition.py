from collections import Counter
from itertools import product

from omnia.generics import np
from ._constants import AA_ALPHABET, N_CODONS, AA_CATEGORIES, AA_GROUP
from ._utils import Descriptor


class AminoAcidCompositionDescriptor(Descriptor):
    """
    A descriptor that returns the Amino Acid Composition of the sequence.
    """

    def __call__(self, sequence: str, **kwargs):
        """
        Calculates the Amino Acid Composition of the sequence.

        Parameters
        ----------
        sequence : str
            The sequence to calculate the isoelectric point for.

        kwargs

        Returns
        -------
        list of float
            The Amino Acid Composition of the sequence.
        """
        counts = Counter(sequence)
        return [round(counts.get(aa, 0) / len(sequence) * 100, 3) for aa in AA_ALPHABET]

    def get_features_out(self, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        return [f"N_{aa}" for aa in AA_ALPHABET]


class GroupAminoAcidComposition(Descriptor):
    """
    A descriptor that returns the frequency of each aminoacid group of the sequence.
    """

    def __call__(self, sequence: str, **kwargs):
        """
        Calculates the Group Aminoacid Composition oh the sequence.

        Parameters
        ----------
        sequence : str
            The sequence to calculate the Group Aminoacid Composition for.

        kwargs

        Returns
        -------
        list of float
            The Group Aminoacid Composition of the sequence.
        """
        # Count occurrences of each amino acid
        each_aa = Counter(sequence)

        total_length = len(sequence)
        code = [(sum(each_aa[aa] for aa in amino_acids) / total_length) for amino_acids in AA_CATEGORIES.values()]
        return code

    def get_features_out(self, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        return list(AA_CATEGORIES.keys())


class DipeptideCompositionDescriptor(Descriptor):
    """
    A descriptor that returns the Dipeptide Composition of the sequence.
    """

    def __call__(self, sequence: str, **kwargs):
        """
        Calculates the Dipeptide Composition of the sequence.

        Parameters
        ----------
        sequence : str
            The sequence to calculate the Dipeptide Composition for.

        kwargs

        Returns
        -------
        list of float
            The Dipeptide Composition of the sequence.
        """
        counts = {a + b: 0 for a, b in product(AA_ALPHABET, AA_ALPHABET)}

        for a, b in zip(sequence, sequence[1:]):
            counts[a + b] += 1

        return [round(cnt / (len(sequence) - 1) * 100, 3) for cnt in counts.values()]

    def get_features_out(self, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        return [f'{aa_1}{aa_2}' for aa_1, aa_2 in product(AA_ALPHABET, AA_ALPHABET)]


class CompositionKSpacedAminoacidPairs(Descriptor):
    """
    A descriptor that return the frequency of aminoacid pairs of the sequence separated by any k residues.
    """

    def __call__(self, sequence: str, gap: int = 1, **kwargs):
        """
        Calculates the frequency of aminoacid pairs separated by any k residues
        
        Parameters
        ----------
        sequence : str
            The sequence to calculate the Composition of K-Spaced Aminoacid Pairs.
        gap : int
            The number of residues among the amino acids that are taken into account.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of float
            The Composition of K-Spaced Aminoacid Pairs of the sequence.
        """
        seq_length = len(sequence)
        if gap < 0:
            raise ValueError(f"gap must be a positive integer. Got {gap} instead.")
        if seq_length < gap + 2:
            raise ValueError(f"sequence length must be greater than gap + 2. Got {seq_length} instead.")

        aaPairs = [aa1 + aa2 for aa1 in AA_ALPHABET for aa2 in AA_ALPHABET]

        code = []
        for g in range(gap + 1):
            myDict = {pair: 0 for pair in aaPairs}
            sum_pairs = 0
            for index1 in range(seq_length - g - 1):
                pair = sequence[index1] + sequence[index1 + g + 1]
                myDict[pair] += 1
                sum_pairs += 1

            # normalization
            code.extend([myDict[pair] / sum_pairs if sum_pairs > 0 else 0 for pair in aaPairs])
        return code

    def get_features_out(self, gap: int = 1, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        gap: int
            The number of residues among the amino acids that are taken into account.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        features = [f"{aa1}{aa2}.gap{g}" for g in range(gap + 1) for aa1 in AA_ALPHABET for aa2 in AA_ALPHABET]
        return features


class DipeptideDeviationExpectedMean(Descriptor):
    """
    A descriptor that return the Dipeptide Deviation from Expected Mean feature vector.
    """

    def __call__(self, sequence: str, **kwargs):
        """
        Calculates the Dipeptide Deviation from Expected Mean feature vector of the sequence.

        Parameters
        ----------
        sequence : str
            The sequence to calculate the Dipeptide Deviation from Expected Mean for.

        kwargs

        Returns
        -------
        list of float
            The Dipeptide Deviation from Expected Mean feature vector of the sequence.
        """
        diPeptides = [aa1 + aa2 for aa1 in AA_ALPHABET for aa2 in AA_ALPHABET]

        myTM = np.array([(N_CODONS[pair[0]] / 61) * (N_CODONS[pair[1]] / 61) for pair in diPeptides])

        AADict = {AA_ALPHABET[i]: i for i in range(len(AA_ALPHABET))}

        code = np.zeros(400)
        for j in range(len(sequence) - 1):
            code[AADict[sequence[j]] * 20 + AADict[sequence[j + 1]]] += 1

        total_pairs = len(sequence) - 1
        if total_pairs != 0:
            code /= total_pairs

        if len(sequence) > 1:
            myTV = np.array([(myTM[j] * (1 - myTM[j]) / total_pairs) for j in range(len(myTM))])
            code = (code - myTM) / np.sqrt(myTV)

        return code.tolist()

    def get_features_out(self, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        return [f"DDE_{aa1}_{aa2}" for aa1 in AA_ALPHABET for aa2 in AA_ALPHABET]


class TripeptideCompositionDescriptor(Descriptor):
    """
    A descriptor that returns the Tripeptide Composition of the sequence.
    """

    def __call__(self, sequence: str, **kwargs):
        """
        Calculates the Tripeptide Composition of the sequence.

        Parameters
        ----------
        sequence : str
            The sequence to calculate the Tripeptide Composition for.

        kwargs

        Returns
        -------
        list of float
            The Tripeptide Composition of the sequence.
        """
        counts = {(a, b, c): 0 for a, b, c in product(AA_ALPHABET, AA_ALPHABET, AA_ALPHABET)}

        for a, b, c in zip(sequence, sequence[1:], sequence[2:]):
            counts[(a, b, c)] += 1

        return [round(cnt / (len(sequence) - 2) * 100, 3) for cnt in counts.values()]

    def get_features_out(self, **kwargs):
        """
        Returns the names of the features that the descriptor will return.

        Parameters
        ----------
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        return [f'{aa_1}{aa_2}{aa_3}' for aa_1, aa_2, aa_3 in product(AA_ALPHABET, AA_ALPHABET, AA_ALPHABET)]


class ConjountTriad(Descriptor):
    """
    A descriptor that returns not only the numbers of 3 continuos aminoacid units, but also considers the continuous 
    aminoacid unit that are separated by k residues.
    """

    def __call__(self, sequence: str, gap: int = 1, **kwargs):
        """
            Calculates the Conjount k-spaced Triad of the sequence.

            Parameters
            ----------
            sequence : str
                The sequence to calculate the Tripeptide Composition for.
            
            gap : int
                The number of residues among the amino acids that are taken into account.

            kwargs

            Returns
            -------
            list of float
                The Conjount k-spaced Triad of the sequence.
        """
        seq_length = len(sequence)
        if len(sequence) < 2 * gap + 3:
            raise ValueError(f"sequence length must be greater than 2 * gap + 3. Got {seq_length} instead.")

        AADict = {aa: group for group, aas in AA_GROUP.items() for aa in aas}
        myGroups = sorted(set(AADict.values()))

        features = [f1 + '.' + f2 + '.' + f3 for f1 in myGroups for f2 in myGroups for f3 in myGroups]

        res = []
        AADict_sequence = [AADict[aa] for aa in sequence]
        for g in range(gap + 1):
            myDict = {f: 0 for f in features}
            for i in range(seq_length - 2 * g - 2):
                fea = AADict_sequence[i] + '.' + AADict_sequence[i + g + 1] + '.' + AADict_sequence[i + 2 * g + 2]
                myDict[fea] += 1

            maxValue, minValue = max(myDict.values()), min(myDict.values())
            res.extend([(myDict[f] - minValue) / maxValue for f in features])
        return res

    def get_features_out(self, gap: int = 1, **kwargs):
        """
        Returns the names of the features that the descriptor will return.
        
        Parameters
        ----------
        gap: int
            The number of residues among the amino acids that are taken into account.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        list of str
            The names of the features that the descriptor will return.
        """
        myGroups = sorted(AA_GROUP.keys())
        features = [f1 + '.' + f2 + '.' + f3 for f1 in myGroups for f2 in myGroups for f3 in myGroups]
        return [f + '.gap' + str(g) for g in range(gap + 1) for f in features]
