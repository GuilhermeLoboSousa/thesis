from typing import Tuple, List

from autogluon.common.space import Categorical

from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter, EstimatedParameter
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.multiprocessing import JoblibMultiprocessing
from .descriptors._utils import Descriptor
from .descriptors.presets import DESCRIPTORS_PRESETS
from omnia.generics.validation.data_tag import DataTag


class ProteinDescriptor(Transformer,
                        name='ProteinDescriptor',
                        category='feature_extraction',
                        register=True):
    """
    It calculates several protein descriptors based on input protein sequences
    The ProteinDescriptor operates only over pandas DataFrame.
    Some descriptors require the preprocessing of the protein sequences to the 20 standard amino acids.

    Parameters
    ----------
    preset: str, optional (default='performance')
        The preset of the custom standardizer. Available presets are:
        - 'performance': Preset to obtain the protein descriptors which usually work better in ML and DL applications.
            The protein descriptors include psychochemical, aac, paac, autocorrelation and CTD descriptors.
        - 'all': Preset to obtain the all the descriptors available.
        - 'psycho-chemical': Preset to obtain the basic psychochemical descriptors.
        - 'aac': Preset to obtain the amino acid composition descriptors.
        - 'paac': Preset to obtain the pseudo amino acid composition descriptors.
        - 'auto-correlation': Preset to obtain the autocorrelation descriptors.
        - 'composition-transition-distribution': Preset to obtain the CTD descriptors.
        - 'seq-order': Preset to obtain the quasi-sequence-order and sequence-order-copeling descriptors.
        - 'modlamp-correlation': Preset to obtain the modlamp correlation descriptors.
        - 'modlamp-all': Preset to obtain all descriptors from modlamp.

    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> from omnia.proteins.feature_extraction import ProteinDescriptor
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = ProteinDescriptor(preset='all')
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """
    # transformer parameters
    preset: str = Parameter(default='performance',
                            tunable=True,
                            space=Categorical('performance',
                                              'all',
                                              'physico-chemical',
                                              'aac',
                                              'paac',
                                              'auto-correlation',
                                              'composition-transition-distribution',
                                              'seq-order',
                                              'modlamp-correlation',
                                              'modlamp-all')
                            )

    n_jobs: int = Parameter(default=1, tunable=False)

    descriptors: List[Descriptor] = EstimatedParameter()

    _output_type = DataTag.TABULAR
    tags = TagsProperty([TextX, NotAllowNaN])

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'ProteinDescriptor':
        """
        Fit the transformer to the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame, optional (default=None)
            The target data

        Returns
        -------
        self: ProteinDescriptor
            The fitted transformer.

        """
        if self.preset not in DESCRIPTORS_PRESETS:
            raise ValueError(f'Preset {self.preset} is not available.')

        self.descriptors = [descriptor() for descriptor in DESCRIPTORS_PRESETS[self.preset]]

        self.instances = list(x.index)
        self.features = [feature for descriptor in self.descriptors
                         for feature in descriptor.get_features_out()]
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame, optional (default=None)
            The target data

        Returns
        -------
        x: pd.DataFrame
            The transformed input data.
        y: pd.DataFrame
            The transformed target data.
        """
        copied_index = list(x.index)
        sequences = x.iloc[:, 0].to_list()

        x = [[] for _ in sequences]
        for descriptor in self.descriptors:
            mp = JoblibMultiprocessing(process=descriptor, n_jobs=self.n_jobs)
            instances = mp.run(items=sequences)

            for i, instance in enumerate(instances):
                x[i].extend(instance)
        x = pd.DataFrame(x, index=copied_index, columns=self.features)
        return x, y


if __name__ == '__main__':
    import doctest

    doctest.testmod()
