from typing import Tuple

from autogluon.common.space import Categorical

from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.multiprocessing import JoblibMultiprocessing


class ProteinStandardizer(Transformer,
                          name='ProteinStandardizer',
                          category='standardization',
                          register=True):
    """
    It transforms the protein sequences by replacing the following aminoacids
    by the closest amino acid residue available in the sequence:
        - Asparagine (B) -> Asparagine (N)
        - Glutamine(Z) -> Glutamine (Q)
        - Selenocysteine (U) -> Cysteinen(C)
        - Pyrrolysine (O) -> Lysine (K)

    It also removes the ambiguous amino acid (X) and replaces the ambiguous amino acid (J) by Isoleucine (I).

    The ProteinStandardizer operates only over pandas DataFrame.

    Parameters
    ----------
    B: str, optional (default='N')
        One-letter aminoacid code to replace Asparagine (B). Default amino acid is Asparagine (N), it can also
        be replaced for any amino acid of the 20 standard amino acids.

    Z   : str, optional (default='Q')
        One-letter aminoacid code to replace Glutamine(Z). Default amino acid is Glutamine (Q), it can also
        be replaced for any amino acid of the 20 standard amino acids.

    U: str, optional (default='C')
        One-letter aminoacid code to replace Selenocysteine (U). Default amino acid is Cysteine (C), it can also
        be replaced for any amino acid of the 20 standard amino acids.

    O: str, optional (default='K')
        One-letter aminoacid code to replace Pyrrolysine (O). Default amino acid is Lysine (K), it can also
        be replaced for any amino acid of the 20 standard amino acids.

    J: str, optional (default='I')
        One-letter aminoacid code to replace ambiguous aminoacid (J). Default amino acid is Isoleucine (I), it can also
        be replaced by Leucine (L).

    X: str, optional (default='')
        One-letter aminoacid code to replace ambiguous aminoacid (X). Default it is removed, it can also
        be replaced for any amino acid of the 20 standard amino acids.

    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSBTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDJVSPRHEGERIRSOGDMYV']], columns=['Sequences'])
    >>> protd = ProteinStandardizer()
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """

    tags = TagsProperty([TextX, NotAllowNaN])

    # transformer parameters
    B: str = Parameter(default='N',
                       tunable=False)
    Z: str = Parameter(default='Q',
                       tunable=False)
    U: str = Parameter(default='C',
                       tunable=False)
    O: str = Parameter(default='K',
                       tunable=False)
    J: str = Parameter(default='I',
                       tunable=True,
                       space=Categorical('I', 'L'))
    X: str = Parameter(default='',
                       tunable=False)
    n_jobs: int = Parameter(default=1, tunable=False)

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'ProteinStandardizer':
        """
        Fit the transformer.

        Parameters
        ----------
        x : pd.DataFrame
            Input data.
        y : pd.DataFrame, optional (default=None)
            Target data.

        Returns
        -------
        self : ProteinStandardizer
            Fitted transformer.
        """
        self.features = list(x.columns)
        self.instances = list(x.index)
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the input data.

        Parameters
        ----------

        x : pd.DataFrame
            Input data.
        y : pd.DataFrame, optional (default=None)
            Target data.

        Returns
        -------
        x : pd.DataFrame
            Transformed input data.
        y : pd.DataFrame
            Transformed target data.
        """

        mp = JoblibMultiprocessing(process=self._protein_preprocessing, n_jobs=self.n_jobs)
        res = mp.run(items=x[self.features[0]])

        return pd.DataFrame(res, index=x.index, columns=self.features), y

    def _protein_preprocessing(self, sequence: str) -> str:
        """
        Preprocess a protein sequence.

        Parameters
        ----------
        sequence : str
            Protein sequence.

        Returns
        -------
        sequence : str
            Preprocessed protein sequence.
        """
        replace_dict = {'B': self.B, 'Z': self.Z, 'U': self.U, 'O': self.O, 'J': self.J, 'X': self.X}
        for key, value in replace_dict.items():
            sequence = sequence.replace(key, value)
        return sequence


if __name__ == '__main__':
    import doctest

    doctest.testmod()
