from typing import Tuple

from autogluon.common.space import Categorical

from omnia.generics import Transformer
from omnia.generics.array import np
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.multiprocessing import JoblibMultiprocessing
from omnia.generics.validation.data_tag import DataTag
from omnia.proteins.encoding._constants import BLOSUM_50, BLOSUM_62


class BlosumEncoder(Transformer,
                    name='BlosumEncoder',
                    category='encoding',
                    register=True):
    """
    It encodes protein sequences with a given BLOSUM substitution matrix.

    BLOSUM is a substitution matrix that specifies the similarity of one amino acid to another by means of a score.
    This score reflects the frequency of substitutions found from studying protein sequence conservation
    in large databases of related proteins.
    The number 62 refers to the percentage identity at which sequences are clustered in the analysis.
    It is possible to get 50 to get 50 % identity.
    Encoding a peptide this way means we provide the column from the blosum matrix corresponding to the amino acid
    at each position of the sequence. This produces 24 * seq_len matrix.

    The ProteinBlosum operates only over pandas DataFrame. Depending on the blosum used, it may require different
    preprocessing of protein sequences. For blosum62, protein sequences can not include the amino acid such as J, U, O.
    For blosum50, protein sequences can not include the amino acid such as U, O.

    Parameters
    ----------
    blosum : str, optional (default='blosum62')
        Blosum matrix to be used to encode the protein sequence.
        By default, 'blosum62' is used, 'blosum50' also available.

    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> from omnia.proteins.encoding import BlosumEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = BlosumEncoder(blosum='blosum50')
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x.iloc[0, 0].shape
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """

    tags = TagsProperty([TextX, NotAllowNaN])

    # transformer parameters
    blosum = Parameter(default="blosum62",
                       tunable=True,
                       space=Categorical("blosum62", "blosum50"))

    n_jobs: int = Parameter(default=1, tunable=False)

    _output_type = DataTag.MATRIX

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'BlosumEncoder':
        """
        It fits the BlosumEncoder.

        Parameters
        ----------
        x : pd.DataFrame
            Dataframe containing the protein sequences to be encoded.
        y : pd.DataFrame, optional (default=None)
            Dataframe containing the target values.

        Returns
        -------
        self
        """
        if self.blosum == "blosum62":
            self._blosum = BLOSUM_62

        elif self.blosum == "blosum50":
            self._blosum = BLOSUM_50

        else:
            ValueError(f'{self.blosum} is not a valid blosum.')

        self.features = list(x.columns)
        self.instances = list(x.index)
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        It encodes the protein sequences with a given BLOSUM substitution matrix.

        Parameters
        ----------
        x : pd.DataFrame
            Dataframe containing the protein sequences to be encoded.
        y : pd.DataFrame, optional (default=None)
            Dataframe containing the target values.

        Returns
        -------
        encoded_x : pd.DataFrame
            DataFrame containing the encoded protein sequences.
        encoded_y : pd.DataFrame
            DataFrame containing the target values.
        """

        mp = JoblibMultiprocessing(process=self._protein_blosum, n_jobs=self.n_jobs)
        res = mp.run(items=x[self.features[0]])

        return pd.DataFrame({self.features[0]: res}, index=x.index), y

    def _protein_blosum(self, sequence: str) -> np.ndarray:
        """
        It encodes a protein sequence with a given BLOSUM substitution matrix.

        Parameters
        ----------
        sequence : str
            Protein sequence to be encoded.

        Returns
        -------
        encoded_sequence : np.ndarray
            Encoded sequence.
        """
        return np.array([np.array(self._blosum[aa]) for aa in sequence])


if __name__ == '__main__':
    import doctest

    doctest.testmod()
