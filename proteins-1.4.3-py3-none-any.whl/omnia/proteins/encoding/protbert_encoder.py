import warnings
from typing import Tuple

import torch
from transformers import AutoTokenizer, AutoModel
from joblib import Parallel, delayed

from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.array import np
from omnia.generics.parameter import Parameter
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.validation.data_tag import DataTag


class ProtbertEncoder(Transformer,
                      name='ProtbertEncoder',
                      category='encoding',
                      register=True):
    """
    It encodes protein sequences with the embedding layer of the pre-trained model ProtBert.
    The ProtbertEncoder operates only over pandas DataFrame.

    Parameters
    ----------
    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> from omnia.proteins.encoding import PaddedOneHotEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = ProtbertEncoder()
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """
    tags = TagsProperty([TextX, NotAllowNaN])

    max_seq_len: int = Parameter(default=600, tunable=False)

    n_jobs: int = Parameter(default=1, tunable=False)

    _output_type = DataTag.MATRIX

    def pad_or_truncate_sequences(self, x: pd.DataFrame) -> pd.DataFrame:
        """
        It pads or truncates the sequences to the maximum sequence length.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.

        Returns
        -------
        x: pd.DataFrame
            The padded or truncated input data.
        """
        def pad_or_truncate(seq):
            return seq[:self.max_seq_len].ljust(self.max_seq_len, "#")

        x.iloc[:, 0] = x.iloc[:, 0].apply(pad_or_truncate)
        return x

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None):
        """
        Loads the ProtBert model and tokenizer.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The output data.

        Returns
        -------
        self: ProtbertEncoder
            The fitted transformer.
        """
        x = self.pad_or_truncate_sequences(x)
        self.tokenizer = AutoTokenizer.from_pretrained("Rostlab/prot_bert", do_lower_case=False,
                                                       pad_toke='#')

        model = AutoModel.from_pretrained("Rostlab/prot_bert")

        # TODO: check if it is possible to use the GPU
        device = torch.device('cpu')
        self.model = model.to(device)
        self.model = model.eval()

        self.features = list(x.columns)
        self.instances = list(x.index)

        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The output data.

        Returns
        -------
        x: pd.DataFrame
            The transformed input data.
        y: pd.DataFrame
            The transformed output data.
        """
        x = self.pad_or_truncate_sequences(x)
        if self.n_jobs != 1:
            warnings.warn('Multiprocessing is not available for this transformer. Using only one core')
        res = Parallel(n_jobs=1)(
            delayed(self._protein_protbert)(seq) for seq in x.iloc[:, 0])
        x = np.stack(res)
        return x, y

    def _protein_protbert(self, sequence: str) -> np.ndarray:
        """
        It encodes a protein sequence with the ProtBert embedding layer.

        Parameters
        ----------
        sequence : str
            The protein sequence to be encoded.

        Returns
        -------
        encoder features: np.array
            The encoded sequence by ProtBert embedding.
        """
        sequence = ' '.join([char for char in sequence])
        encoded_input = self.tokenizer(sequence, return_tensors='pt', add_special_tokens=True)
        with torch.no_grad():
            output = self.model(**encoded_input)
        tensor = output['last_hidden_state'].detach().numpy()

        return tensor[0][1:tensor[0].shape[0]-1, :]


if __name__ == '__main__':
    import doctest

    doctest.testmod()
