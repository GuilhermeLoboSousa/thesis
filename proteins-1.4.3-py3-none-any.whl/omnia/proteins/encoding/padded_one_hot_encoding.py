from typing import Tuple, Dict

from autogluon.common.space import Categorical, Int

from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation.data_tag import DataTag

try:
    import tensorflow as tf
except ImportError:
    tf = None


from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.array import np
from omnia.generics.parameter import Parameter, EstimatedParameter
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.multiprocessing import JoblibMultiprocessing


class PaddedOneHotEncoder(Transformer,
                          name='PaddedOneHotEncoder',
                          category='encoding',
                          register=True):
    """
    It encodes protein sequences with the one hot encoding and padded to a specif sequence length.
    The ProteinPaddedOneHot operates only over pandas DataFrame.

    Parameters
    ----------
    seq_len : int, optional (default 1000)
        The maximum length for all sequences.
    alphabet : str, optional (default "XARNDCEQGHILKMFPSTWYV")
        The alphabet of aminoacids to be used. It is important to choose the appropriated alphabet based on the sequence
         preprocessing.
    padding_truncating: str, optional (default "post")
        'pre' or 'post' pad either before or after each sequence, also removes values from sequences larger than seq_len.

    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.
    --------
    >>> from omnia.proteins.encoding import PaddedOneHotEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = PaddedOneHotEncoder(seq_len = 700) #ADD PRESET NAMES
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """

    tags = TagsProperty([TextX, NotAllowNaN])

    # transformer parameters
    seq_len: int = Parameter(default=1000,
                             tunable=True,
                             space=Int(0, 9999, default=1000))
    alphabet: str = Parameter(default="XARNDCEQGHILKMFPSTWYV",
                              tunable=True,
                              space=Categorical("XARNDCEQGHILKMFPSTWYV",
                                                "XARNDCEQGHILKMFPSTWYVBZUO",
                                                "XARNDCEQGHILKMFPSTWYVBZUOJ"))
    padding_truncating: str = Parameter(default="post",
                                        tunable=True,
                                        space=Categorical("post", "pre"))

    n_jobs: int = Parameter(default=1, tunable=False)

    char_to_int: Dict[str, int] = EstimatedParameter()

    _output_type = DataTag.MATRIX

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'PaddedOneHotEncoder':
        """
        It fits the transformer.

        Parameters
        ----------
        x : pd.DataFrame
            The input dataframe.
        y : pd.DataFrame
            The target dataframe.

        Returns
        -------
        self
        """
        # check if tensorflow is installed
        if tf is None:
            raise RuntimeError("Tensorflow is not installed. Please install tensorflow to use this transformer.")

        self.char_to_int = dict((c, i) for i, c in enumerate(self.alphabet))

        self.features = list(x.columns)
        self.instances = list(x.index)
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        It encodes the input dataframe.

        Parameters
        ----------
        x : pd.DataFrame
            The input dataframe.
        y : pd.DataFrame
            The target dataframe.

        Returns
        -------
        x : pd.DataFrame
            The encoded dataframe.
        y : pd.DataFrame
            The target dataframe.
        """
        mp = JoblibMultiprocessing(process=self._protein_hot_encoding, n_jobs=self.n_jobs)
        res = mp.run(items=x[self.features[0]])

        return pd.DataFrame({self.features[0]: res}, index=x.index), y

    def _protein_hot_encoding(self, sequence: str) -> np.ndarray:
        """
        It encodes a protein sequence with the one hot encoding.

        Parameters
        ----------
        sequence : str
            The protein sequence to be encoded.

        Returns
        -------
        encoded_sequence : np.ndarray
            The encoded sequence.
        """
        integer_encoded = [self.char_to_int[char] for char in sequence]
        list_of_sequences_length = tf.keras.preprocessing.sequence.pad_sequences([integer_encoded],
                                                                                 maxlen=self.seq_len,
                                                                                 dtype='int16',
                                                                                 padding=self.padding_truncating,
                                                                                 truncating=self.padding_truncating,
                                                                                 value=0)

        integer_padded = np.append(list_of_sequences_length[0], [len(self.char_to_int) - 1])
        hot_enc = tf.keras.utils.to_categorical(integer_padded)

        return hot_enc[:len(hot_enc) - 1]


if __name__ == '__main__':
    import doctest

    doctest.testmod()
