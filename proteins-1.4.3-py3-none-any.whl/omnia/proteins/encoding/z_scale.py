from typing import Tuple

from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.array import np
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.parameter import Parameter
from omnia.generics.multiprocessing import JoblibMultiprocessing
from omnia.generics.validation.data_tag import DataTag
from omnia.proteins.encoding._constants import ZS


class ZScaleEncoder(Transformer,
                    name='ZScaleEncoder',
                    category='encoding',
                    register=True):
    """
    It encodes protein sequences using the Z scale.
    The ZScaleEncoder operates only over pandas DataFrame. This encoding requires the preprocessing of the protein
    sequences to the 20 standard amino acids.

    This method encodes which amino acid of the sequence into a Z-scales. Each Z scale represent an amino-acid property:
        Z1: Lipophilicity
        Z2: Steric properties (Steric bulk/Polarizability)
        Z3: Electronic properties (Polarity / Charge)
        Z4 and Z5: They relate electronegativity, heat of formation, electrophilicity and hardness.

    Parameters
    ----------
    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.
    --------
    >>> from omnia.proteins.encoding.z_scale_encoding import ZScaleEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = ZScaleEncoder() #ADD PRESET NAMES
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """

    tags = TagsProperty([TextX, NotAllowNaN])

    # transformer parameters

    n_jobs: int = Parameter(default=1, tunable=False)

    _output_type = DataTag.TABULAR

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'ZScaleEncoder':
        """
        Fit the transformer to the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The target data.

        Returns
        -------
        ZScaleEncoder
            The fitted transformer.
        """
        self.features = list(x.columns)
        self.instances = list(x.index)
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The target data.

        Returns
        -------
        Tuple[pd.DataFrame, pd.DataFrame]
            The transformed input data and the transformed target data.
        """
        mp = JoblibMultiprocessing(process=self._protein_zscale, n_jobs=self.n_jobs)
        res = mp.run(items=x[self.features[0]])
        return pd.DataFrame({self.features[0]: res}, index=x.index), y

    @staticmethod
    def _protein_zscale(sequence: str) -> np.ndarray:
        """
        It encodes the protein sequence using the Z scale.

        Parameters
        ----------
        sequence : str
            The protein sequence to be encoded.

        Returns
        -------
        encoded_sequence : np.ndarray
            The encoded sequence.

        """
        return np.array([np.array(ZS[aa]) for aa in sequence])


if __name__ == '__main__':
    import doctest

    doctest.testmod()
