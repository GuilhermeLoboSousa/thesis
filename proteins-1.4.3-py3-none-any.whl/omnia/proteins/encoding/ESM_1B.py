from copy import deepcopy
from typing import Tuple

from autogluon.common.space import Categorical, Int

import torch
import esm

from omnia.generics import Transformer, np
from omnia.generics.dataframe import pd
from omnia.generics.parameter import Parameter
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.validation.data_tag import DataTag


class Esm1bEncoder(Transformer,
                   name='Esm_1bEncoder',
                   category='encoding',
                   register=True):
    """
    It encodes protein sequences with the embedding layer of the pre-trained model ESM-1B.
    The Esm1bEncoder operates only over pandas DataFrame.

    Parameters
    ----------
    preset: str, optional (default='representations')
        The possible output from esm1b model. Available presets are:
            - 'representations': Preset to obtain the transformer representation of the protein sequences. This preset
            creats a 1280 x length of sequence matrix as an output for each sequence. More information can be acessed in
            https://github.com/facebookresearch/esm
            - 'features': Preset to obtain the input features to the transformers layers. This preset creats a
            33 x length of sequence matrix as an output for each sequence.
    two_dimensional_embeddings: bool, optional (default=False)
        Wheter to generate embeddings as a matrix of length of sequence x embedding size (True) or to generate a vector
        of embedding size with the mean of every sequence position (False).
    batch_size: int, optional (default=16)
        The batch size to be used in the encoding process. Higher batch sizes can lead to OOM issues.
    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> from omnia.proteins.encoding import Esm1bEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = Esm1bEncoder()
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """

    tags = TagsProperty([TextX, NotAllowNaN])

    preset: str = Parameter(default='representations',
                            tunable=False,
                            space=Categorical('representations', 'features'))
    two_dimensional_embeddings: bool = Parameter(default=False,
                                                 tunable=False,
                                                 space=Int(0, 1))

    max_seq_len: int = Parameter(default=600, tunable=False)

    batch_size: int = Parameter(default=8,
                                tunable=False)

    n_jobs: int = Parameter(default=1, tunable=False)

    _output_type = None

    def pad_or_truncate_sequences(self, x: pd.DataFrame) -> pd.DataFrame:
        """
        It pads or truncates the sequences to the maximum sequence length.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.

        Returns
        -------
        x: pd.DataFrame
            The padded or truncated input data.
        """

        def pad_or_truncate(seq):
            if '<pad>' in seq:
                return seq
            # Truncate the sequence if it's longer than max_seq_len
            if len(seq) > self.max_seq_len:
                return seq[:self.max_seq_len]
            # Pad the sequence if it's shorter than max_seq_len
            else:
                padding = "<pad>" * (self.max_seq_len - len(seq))
                return seq + padding

        x = deepcopy(x)
        x.iloc[:, 0] = x.iloc[:, 0].apply(pad_or_truncate)
        return x

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'Esm1bEncoder':
        """
        Fit the Esm1bEncoder. It loads the pre-trained model and the batch converter.

        Parameters
        ----------
        x : dataframe
            The dataframe with the column to be encoded.
        y : dataframe, optional
            The dataframe with the target column.

        Returns
        -------
        encoder: a fitted Esm1bEncoder
        """
        if self.preset not in ['representations', 'features']:
            raise ValueError('The preset must be either representations or features.')

        model, alphabet = esm.pretrained.esm1b_t33_650M_UR50S()

        if torch.cuda.is_available():
            self.device = torch.device('cuda')
        else:
            self.device = torch.device('cpu')

        self.model = model.to(self.device)
        self.model = model.eval()
        self.batch_converter = alphabet.get_batch_converter()

        if self.two_dimensional_embeddings:
            self.features = list(x.columns)
        else:
            n_features = {'representations': 1280, 'features': 33}
            self.features = [f'esm_{i}' for i in range(1, n_features[self.preset] + 1)]

        self.instances = list(x.index)
        self._output_type = DataTag.MATRIX if self.two_dimensional_embeddings else DataTag.TABULAR
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        It encodes the protein sequences with the esm_1b embedding.

        Parameters
        ----------
        x : dataframe
            The dataframe with the column to be encoded.
        y : dataframe, optional
            The dataframe with the target column.

        Returns
        -------
        encoded_x: dataframe
            The dataframe with the encoded sequences.
        encoded_y: dataframe
            The dataframe with the target column.

        """
        x = self.pad_or_truncate_sequences(x)
        # TODO: multiprocessing will be available at the omnia-generics package level
        features = self._protein_esm_1b(x.iloc[:, 0])  # expects a single column with the sequences
        if self.two_dimensional_embeddings:
            x = np.stack(features)
        else:
            x = pd.DataFrame(features, columns=self.features)
        return x, y

    def _protein_esm_1b(self, x: pd.DataFrame) -> list:
        """
        It encodes a protein sequence with the esm_1b embedding layer.

        Parameters
        ----------
        x : dataframe
            The dataframe with the column to be encoded.

        Returns
        -------
        encoder features: list
            The encoded sequences by esm_1b embedding.
        """

        feature = []
        sequences = [(str(seq_index), x.loc[seq_index]) for seq_index in x.index]

        for index in range(0, len(sequences), self.batch_size):
            representations = {}
            if index + self.batch_size <= len(sequences):
                seq = sequences[index: index + self.batch_size]
            else:
                seq = sequences[index: len(sequences)]

            batch_labels, batch_strs, batch_tokens = self.batch_converter(seq)
            with torch.no_grad():
                # Extract per-residue representations
                results = self.model(batch_tokens.to(self.device),
                                     repr_layers=[33],
                                     need_head_weights=False,
                                     return_contacts=False)
            representations['representations'] = results["representations"][33]
            representations['features'] = results["logits"]

            if self.two_dimensional_embeddings:
                for seq_num in range(len(representations[self.preset])):
                    seq_emd = representations[self.preset][seq_num].cpu().detach().numpy()
                    feature.append(seq_emd)
            else:
                for i, (_, seq_rep) in enumerate(seq):
                    seq_emd = representations[self.preset][i, 1:len(seq_rep) + 1].mean(0).cpu().detach().numpy()
                    feature.append(seq_emd)

        return feature


if __name__ == '__main__':
    import doctest

    doctest.testmod()
