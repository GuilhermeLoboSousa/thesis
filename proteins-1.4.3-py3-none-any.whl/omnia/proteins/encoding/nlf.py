from typing import Tuple

from omnia.generics import Transformer
from omnia.generics.dataframe import pd
from omnia.generics.array import np
from omnia.generics.utils.cache import cache_transform
from omnia.generics.validation import TagsProperty, TextX, NotAllowNaN
from omnia.generics.parameter import Parameter
from omnia.generics.multiprocessing import JoblibMultiprocessing
from omnia.proteins.encoding._constants import NLF
from omnia.generics.validation.data_tag import DataTag


try:
    import tensorflow as tf
except ImportError:
    tf = None


class NLFEncoder(Transformer,
                 name='NLFEncoder',
                 category='encoding',
                 register=True):
    """
    It encodes protein sequences using the Fisher Transform.
    The ProteinNLF operates only over pandas DataFrame.

    Method that takes many physicochemical properties and transforms them using a Fisher Transform (similar to a PCA)
    creating a smaller set of features that can describe the amino acid just as well.
    There are 19 transformed features.
    This method of encoding is detailed by Nanni and Lumini in their paper:
    L. Nanni and A. Lumini, “A new encoding technique for peptide classification,”
    Expert Syst. Appl., vol. 38, no. 4, pp. 3185–3191, 2011
    This function just receives 20aa letters, therefore preprocessing is required.

    Parameters
    ----------
    max_seq_len: int, optional (default 750)
        Maximum length of the sequence. If the sequence is longer than this value, it will be truncated.
    truncation_type: str, optional (default 'post')
        Truncating type. It can be 'pre', 'post' or 'middle'.
    padding_type: str, optional (default 'post')
        Padding type. It can be 'pre' or 'post'.
    n_jobs: int, optional (default 1)
        Number of CPU cores to be used.

    Examples
    --------
    >>> from from omnia.proteins.encoding import NLFEncoder
    >>> from omnia.generics.dataframe import pd
    >>> df = pd.DataFrame([['MSYKPIAPAPSSTPGSSTPGPGTPVPTGSVPSPSGSVPG'], ['MTSLADLPVDVSPRHEGERIRSGDMYV']], columns=['Sequences'])
    >>> protd = NLFEncoder()
    >>> protd.fit(df)
    >>> transformed_x, transformed_y = protd.transform(df)
    >>> transformed_x
    >>> transformed_x, _ = protd.fit_transform(df)
    >>> transformed_x
    """
    max_seq_len: int = Parameter(default=600, tunable=False)
    truncation_type: str = Parameter(default="post", tunable=False)
    padding_type: str = Parameter(default="post", tunable=False)
    n_jobs: int = Parameter(default=1, tunable=False)

    tags = TagsProperty([TextX, NotAllowNaN])

    _output_type = DataTag.MATRIX

    def _fit(self, x: pd.DataFrame, y: pd.DataFrame = None) -> 'NLFEncoder':
        """
        Fit the transformer to the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The output data.

        Returns
        -------
        self: NLFEncoder
            The fitted transformer.
        """
        if tf is None:
            raise RuntimeError("Tensorflow is not installed. Please install tensorflow to use this transformer.")
        
        self.features = list(x.columns)
        self.instances = list(x.index)
        return self

    @cache_transform
    def _transform(self, x: pd.DataFrame, y: pd.DataFrame = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Transform the data.

        Parameters
        ----------
        x: pd.DataFrame
            The input data.
        y: pd.DataFrame
            The output data.

        Returns
        -------
        x: pd.DataFrame
            The transformed input data.
        y: pd.DataFrame
            The transformed output data.
        """
        mp = JoblibMultiprocessing(process=self._nlf_encoding, n_jobs=self.n_jobs)
        res = mp.run(items=x[self.features[0]])

        return np.stack(res), y

    def _nlf_encoding(self, sequence: str) -> np.ndarray:
        """
        It encodes protein sequences using the Fisher Transform and applies padding.

        Parameters
        ----------
        sequence : str
            Protein sequence.

        Returns
        -------
        encoded_sequence : np.ndarray
            Encoded sequence with padding.
        """
        # Apply truncation to the sequence
        if len(sequence) > self.max_seq_len:
            if self.truncation_type == 'middle':
                half_len = self.max_seq_len//2
                sequence = sequence[:half_len] + sequence[-half_len:]
            elif self.truncation_type == 'pre':
                sequence = sequence[-self.max_seq_len:]
            else:  # 'post'
                sequence = sequence[:self.max_seq_len]

        # Now apply the NLF encoding
        encoded_sequence = [np.array(NLF[aa]) for aa in sequence]

        # Use pad_sequences for padding
        padded_sequence = tf.keras.preprocessing.sequence.pad_sequences([encoded_sequence],
                                                                        maxlen=self.max_seq_len, dtype='float32',
                                                                        padding=self.padding_type, value=0.0)

        return padded_sequence[0]


if __name__ == '__main__':
    import doctest

    doctest.testmod()
