from abc import abstractmethod
from typing import Union, List, Tuple

from hyperopt import hp
from optuna import Trial

from omnia.generics import presets as generics_presets
from omnia.generics import search_space_register, Step

from omnia.proteins.feature_extraction import ProteinDescriptor
from omnia.proteins.encoding import NLFEncoder, Esm2Encoder, ProtbertEncoder
from omnia.generics.model import Model
from omnia.proteins.standardization.protein_standardizer import ProteinStandardizer


from omnia.generics.utils.function_transformer import PassthroughTransformer
from omnia.generics.validation.data_tag import DataTag
from omnia.generics.validation.task_tag import TaskTag
from omnia.generics.prediction.predictor import Predictor
from omnia.generics import Transformer


def _f_cls(cls) -> str:
    """
    Get the full class name.

    Parameters
    ----------
    cls: class
        Class to get the full name of.

    Returns
    -------
    str
        Full class name.
    """
    return f"{cls.__module__}.{cls.__name__}"


class _ProteinsPresetBase:

    def __init__(self: Union['LightSearchSpace', 'MediumSearchSpace', 'HeavySearchSpace'], *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.standardizer = Step(
            name='standardizer',
            type_='choice',
            nni_params=self._standardizer_nni_value,
            hp_params=self._standardizer_hp_value,
            )

        self.featurizer = Step(
            name='featurizer',
            type_='choice',
            nni_params=self._featurizer_nni_value,
            hp_params=self._featurizer_hp_value,
            )

    def nni_search_space(self: Union['LightSearchSpace', 'MediumSearchSpace', 'HeavySearchSpace']):
        return {**self.standardizer.to_nni(), **self.featurizer.to_nni(), **self.predictor.to_nni()}

    def hp_search_space(self: Union['LightSearchSpace', 'MediumSearchSpace', 'HeavySearchSpace']):
        standardizer = self.standardizer.to_hp(idx=0)
        featurizer = self.featurizer.to_hp(idx=1)
        predictor = self.predictor.to_hp(idx=2)
        return {**standardizer, **featurizer, **predictor}

    @staticmethod
    @abstractmethod
    def get_standardizer(trial, **kwargs) -> ProteinStandardizer:
        """
        Get the standardizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinStandardizer
            The standardizer.
        """
        ...

    @staticmethod
    @abstractmethod
    def get_featurizer(trial, **kwargs) -> Transformer:
        """
        Get the featurizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinDescriptor, NLFEncoder, Esm2Encoder, ProtbertEncoder
            The featurizer.
        """
        ...

    @staticmethod
    @abstractmethod
    def get_predictor(trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                      hpo: bool = False, autostack: bool = False, hyperparameter_tune_kwargs: bool = False,
                      bagging_stacking: bool = False, **kwargs) -> Union[Model, Predictor]:
        """
        Get the predictor for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Union[Model, Predictor]
            The predictor or model for the pipeline.
        """
        ...

    @abstractmethod
    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps for the pipeline.
        """
        ...


@search_space_register
class LightSearchSpace(_ProteinsPresetBase, generics_presets.LightSearchSpace):
    name = 'omnia.proteins.light'
    
    _standardizer_nni_value = [_f_cls(ProteinStandardizer), 'passthrough']
    _standardizer_hp_value = hp.choice(
        'standardizer',
        [
            {
                'name': ProteinStandardizer.name
            },
            {
                'name': 'passthrough'
            }
        ]
    )

    _featurizer_nni_value = [
        {'_name': _f_cls(ProteinDescriptor), 'preset': {'_type': 'choice', '_value': ['performance']}},
        {'_name': _f_cls(NLFEncoder)} 
    ]

    _featurizer_hp_value = hp.choice(
        'featurizer',
        [
            {
                'name': ProteinDescriptor.name,
                'preset': hp.choice(f'{ProteinDescriptor.name}.preset', ['performance'])
            },
            {
                'name': NLFEncoder.name
            }
        ]
    )

    @staticmethod
    def get_standardizer(trial, **kwargs) -> ProteinStandardizer:
        """
        Get the standardizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinStandardizer
            The standardizer.
        """
        return ProteinStandardizer()

    @staticmethod
    def get_featurizer(trial, **kwargs) -> Union[ProteinStandardizer, NLFEncoder, Esm2Encoder]:
        """
        Get the featurizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinDescriptor, NLFEncoder, Esm2Encoder
            The featurizer.
        """
        featurizers = {ProteinDescriptor.name: ProteinDescriptor, NLFEncoder.name: NLFEncoder,
                       Esm2Encoder.name: Esm2Encoder}
        featurizer = trial.suggest_categorical('featurizer', list(featurizers.keys()))
        if featurizer == Esm2Encoder.name:
            two_dimensional_embeddings = trial.suggest_categorical('two_dimensional_embeddings', [True, False])
            preset = trial.suggest_categorical('preset', ["representations", "features"])
            p_model = trial.suggest_categorical('pretrained_model', ['8M', '35M'])
            feat = featurizers[featurizer](preset=preset, pretrained_model=p_model,
                                           two_dimensional_embeddings=two_dimensional_embeddings)
            feat._output_type = DataTag.MATRIX if two_dimensional_embeddings else DataTag.TABULAR
            return feat
        return featurizers[featurizer]()

    @staticmethod
    def get_predictor(trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                      hpo: bool = False, autostack: bool = True, hyperparameter_tune_kwargs: bool = False,
                      bagging_stacking: bool = False, **kwargs) -> Union[Model, Predictor]:
        """
        Get the predictor for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Union[Model, Predictor]
            The predictor or model for the pipeline.
        """
        if input_type.value in [DataTag.TABULAR.value, DataTag.MATRIX.value]:
            return generics_presets.OmniaPresetBase.get_predictor(trial, task_type, n_tasks, n_classes, input_type,
                                                                  False, True, False, False, **kwargs)
        raise ValueError(f'Invalid input type: {input_type} for proteins preset.')

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  hpo: bool = False, autostack: bool = False, hyperparameter_tune_kwargs: bool = False,
                  bagging_stacking: bool = False, **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps for the pipeline.
        """
        standardizer = ('standardizer', self.get_standardizer(trial, **kwargs))
        featurizer = ('featurizer', self.get_featurizer(trial, **kwargs))
        if featurizer[1]._output_type == DataTag.TABULAR:
            input_type = DataTag.TABULAR
            scale = True
            select = True
        elif featurizer[1]._output_type == DataTag.MATRIX:
            input_type = DataTag.MATRIX
            scale = False
            select = False
        else:
            raise ValueError(f'Invalid output type: {featurizer[1]._output_type} for proteins preset.')

        imputer, _, scaler, selector, predictor = self._get_steps(trial, task_type, n_tasks, n_classes, input_type,
                                                                  hpo=False, autostack=False,
                                                                  hyperparameter_tune_kwargs=False,
                                                                  bagging_stacking=False, impute=False, scale=scale,
                                                                  select=select, **kwargs)
        return [standardizer, featurizer, imputer, scaler, selector, predictor]


@search_space_register
class MediumSearchSpace(_ProteinsPresetBase, generics_presets.MediumSearchSpace):
    name = 'omnia.proteins.medium'
    
    _standardizer_nni_value = [_f_cls(ProteinStandardizer), 'passthrough']
    _standardizer_hp_value = hp.choice(
        'standardizer',
        [
            {
                'name': ProteinStandardizer.name
            },
            {
                'name': 'passthrough'
            }
        ]
    )

    _featurizer_nni_value = [
        {'_name': _f_cls(ProteinDescriptor), 'preset': {'_type': 'choice', '_value': ['performance']}},
        {'_name': _f_cls(NLFEncoder)},
        {'_name': _f_cls(Esm2Encoder), 'pretrained_model': {'_type': 'choice', '_value': ['650M']}}
        ]

    _featurizer_hp_value = hp.choice(
        'featurizer',
        [
            {
                'name': ProteinDescriptor.name,
                'preset': hp.choice(f'{ProteinDescriptor.name}.preset', ['performance'])
            },
            {
                'name': NLFEncoder.name
            },
            {
                'name': Esm2Encoder.name,
                'pretrained_model':  hp.choice(f'{Esm2Encoder.name}.pretrained_model', ['650M'])
            }
        ]
    )

    @staticmethod
    def get_standardizer(trial, **kwargs) -> ProteinStandardizer:
        """
        Get the standardizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinStandardizer
            The standardizer.
        """
        return ProteinStandardizer()

    @staticmethod
    def get_featurizer(trial, **kwargs) -> Union[ProteinStandardizer, NLFEncoder, Esm2Encoder]:
        """
        Get the featurizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinDescriptor, NLFEncoder, Esm2Encoder
            The featurizer.
        """
        featurizers = {ProteinDescriptor.name: ProteinDescriptor,
                       NLFEncoder.name: NLFEncoder,
                       Esm2Encoder.name: Esm2Encoder}
        featurizer = trial.suggest_categorical('featurizer', list(featurizers.keys()))
        if featurizer == Esm2Encoder.name:
            two_dimensional_embeddings = trial.suggest_categorical('two_dimensional_embeddings', [False, True])
            preset = trial.suggest_categorical('preset', ["representations", "features"])
            p_model = trial.suggest_categorical('pretrained_model', ['35M', '150M', '650M'])
            feat = featurizers[featurizer](preset=preset, pretrained_model=p_model,
                                           two_dimensional_embeddings=two_dimensional_embeddings)
            feat._output_type = DataTag.MATRIX if two_dimensional_embeddings else DataTag.TABULAR
            return feat
        return featurizers[featurizer]()

    @staticmethod
    def get_predictor(trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                      hpo: bool = False, autostack: bool = True, hyperparameter_tune_kwargs: bool = False,
                      bagging_stacking: bool = False, **kwargs) -> Union[Model, Predictor]:
        """
        Get the predictor for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Union[Model, Predictor]
            The predictor or model for the pipeline.
        """
        if input_type.value in [DataTag.TABULAR.value, DataTag.MATRIX.value]:
            return generics_presets.OmniaPresetBase.get_predictor(trial, task_type, n_tasks, n_classes, input_type,
                                                                  False, True, False, False, **kwargs)
        raise ValueError(f'Invalid input type: {input_type} for proteins preset.')

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  hpo: bool = False, autostack: bool = True, hyperparameter_tune_kwargs: bool = False,
                  bagging_stacking: bool = False, **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps for the pipeline.
        """
        standardizer = ('standardizer', self.get_standardizer(trial, **kwargs))
        featurizer = ('featurizer', self.get_featurizer(trial, **kwargs))
        if featurizer[1]._output_type == DataTag.TABULAR:
            input_type = DataTag.TABULAR
            scale = True
            select = True
        elif featurizer[1]._output_type == DataTag.MATRIX:
            input_type = DataTag.MATRIX
            scale = False
            select = False
        else:
            raise ValueError(f'Invalid output type: {featurizer[1]._output_type} for proteins preset.')

        imputer, _, scaler, selector, predictor = self._get_steps(trial, task_type, n_tasks, n_classes, input_type,
                                                                  hpo=False, autostack=False,
                                                                  hyperparameter_tune_kwargs=False,
                                                                  bagging_stacking=False, impute=False, scale=scale,
                                                                  select=select, **kwargs)
        return [standardizer, featurizer, imputer, scaler, selector, predictor]


@search_space_register
class HeavySearchSpace(_ProteinsPresetBase, generics_presets.HeavySearchSpace):
    name = 'omnia.proteins.heavy'
    
    _standardizer_nni_value = [_f_cls(ProteinStandardizer), 'passthrough']
    _standardizer_hp_value = hp.choice(
        'standardizer',
        [
            {
                'name': ProteinStandardizer.name
            },
            {
                'name': 'passthrough'
            }
        ]
    )

    _featurizer_nni_value = [
            {'_name': _f_cls(ProteinDescriptor), 'preset': {'_type': 'choice', '_value': ['performance']}},
            {'_name': _f_cls(NLFEncoder)},
            {'_name': _f_cls(Esm2Encoder), 'pretrained_model': {'_type': 'choice', '_value': ['650M']}},
            {'_name': _f_cls(ProtbertEncoder)}
            ]
    
    _featurizer_hp_value = hp.choice(
        'featurizer',
        [
            {
                'name': ProteinDescriptor.name,
                'preset': hp.choice(f'{ProteinDescriptor.name}.preset', ['performance'])
            },
            {
                'name': NLFEncoder.name
            },
            {
                'name': Esm2Encoder.name,
                'pretrained_model':  hp.choice(f'{Esm2Encoder.name}.pretrained_model', ['650M'])
            },
            {
                'name': ProtbertEncoder.name
            }
        ]
    )

    @staticmethod
    def get_standardizer(trial, **kwargs) -> ProteinStandardizer:
        """
        Get the standardizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinStandardizer
            The standardizer.
        """
        return ProteinStandardizer()

    @staticmethod
    def get_featurizer(trial, **kwargs) -> Union[ProteinStandardizer, NLFEncoder, Esm2Encoder, ProtbertEncoder]:
        """
        Get the featurizer for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        ProteinDescriptor, NLFEncoder, Esm2Encoder, ProtbertEncoder
            The featurizer.
        """
        featurizers = {ProteinDescriptor.name: ProteinDescriptor,
                       NLFEncoder.name: NLFEncoder,
                       Esm2Encoder.name: Esm2Encoder,
                       ProtbertEncoder.name: ProtbertEncoder}
        featurizer = trial.suggest_categorical('featurizer', list(featurizers.keys()))
        if featurizer == Esm2Encoder.name:
            two_dimensional_embeddings = trial.suggest_categorical('two_dimensional_embeddings', [False, True])
            preset = trial.suggest_categorical('preset', ["representations", "features"])
            p_model = trial.suggest_categorical('pretrained_model', ['150M', '650M', '3B'])
            feat = featurizers[featurizer](preset=preset, pretrained_model=p_model,
                                           two_dimensional_embeddings=two_dimensional_embeddings)
            feat._output_type = DataTag.MATRIX if two_dimensional_embeddings else DataTag.TABULAR
            return feat
        return featurizers[featurizer]()

    @staticmethod
    def get_predictor(trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                      hpo: bool = False, autostack: bool = True, hyperparameter_tune_kwargs: bool = False,
                      bagging_stacking: bool = False, **kwargs) -> Union[Model, Predictor]:
        """
        Get the predictor for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        Union[Model, Predictor]
            The predictor or model for the pipeline.
        """
        if input_type.value in [DataTag.TABULAR.value, DataTag.MATRIX.value]:
            return generics_presets.OmniaPresetBase.get_predictor(trial, task_type, n_tasks, n_classes, input_type,
                                                                  False, True, False, False, **kwargs)
        raise ValueError(f'Invalid input type: {input_type} for proteins preset.')

    def get_steps(self, trial: Trial, task_type: TaskTag, n_tasks: int, n_classes: int, input_type: DataTag,
                  hpo: bool = False, autostack: bool = True, hyperparameter_tune_kwargs: bool = False,
                  bagging_stacking: bool = False, **kwargs) -> List[Tuple[str, object]]:
        """
        Get the steps for the pipeline.

        Parameters
        ----------
        trial: Trial
            The trial object.
        task_type: TaskTag
            The task type.
        n_tasks: int
            The number of tasks.
        n_classes: int
            The number of classes.
        input_type: DataTag
            The input type.
        hpo: bool
            Whether to perform hyperparameter optimization for the TabularPredictor.
        autostack: bool
            Whether to use autostacking for the TabularPredictor.
        hyperparameter_tune_kwargs: bool
            Whether to use hyperparameter_tune_kwargs for the TabularPredictor.
        bagging_stacking: bool
            Whether to use bagging and stacking for the TabularPredictor.
        kwargs: dict
            Additional keyword arguments.

        Returns
        -------
        List[Tuple[str, object]]
            The steps for the pipeline.
        """
        standardizer = ('standardizer', self.get_standardizer(trial, **kwargs))
        featurizer = ('featurizer', self.get_featurizer(trial, **kwargs))
        if featurizer[1]._output_type == DataTag.TABULAR:
            input_type = DataTag.TABULAR
            scale = True
            select = True
        elif featurizer[1]._output_type == DataTag.MATRIX:
            input_type = DataTag.MATRIX
            scale = False
            select = False
        else:
            raise ValueError(f'Invalid output type: {featurizer[1]._output_type} for proteins preset.')

        imputer, _, scaler, selector, predictor = self._get_steps(trial, task_type, n_tasks, n_classes, input_type,
                                                                  hpo=False, autostack=False,
                                                                  hyperparameter_tune_kwargs=False,
                                                                  bagging_stacking=False, impute=False, scale=scale,
                                                                  select=select, **kwargs)
        return [standardizer, featurizer, imputer, scaler, selector, predictor]
